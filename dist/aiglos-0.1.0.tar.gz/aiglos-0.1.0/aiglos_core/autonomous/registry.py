"""
T30: Registry Monitor

Continuous crawl of public MCP server marketplaces to detect newly published
malicious packages before they get installed into any Aiglos-protected deployment.

Monitored registries
--------------------
  npm          https://registry.npmjs.org  (primary MCP server distribution channel)
  Smithery     https://smithery.ai         (MCP-specific marketplace)
  mcp.so       https://mcp.so             (community MCP directory)
  PyPI         https://pypi.org           (Python MCP server packages)

Threat signals scored per package
----------------------------------
  - Name similarity to known-good packages (typosquat, ≤2 Levenshtein distance)
  - Keyword overlap with known-malicious package names
  - Abnormally high permissions requested in package.json / smithery.yaml
  - Publisher account age < 30 days (new account, high-risk signal)
  - Abnormal download spike vs. baseline (install bomb signal)
  - Dependency chain that includes known-malicious transitive packages
  - MCP tool descriptions containing injection patterns
  - README containing social engineering language

Integration
-----------
  # Runs automatically on intel refresh cycle (wired in intel.py).
  # Also callable directly:
  from aiglos_core.autonomous.registry import RegistryMonitor
  monitor = RegistryMonitor(audit_db="aiglos_audit.db")
  new_threats = await monitor.scan()

  # Check a specific package before install:
  score = await monitor.score_package("postmark-mcp-server", registry="npm")
  if score.risk_level == "critical":
      raise SecurityError(f"Package blocked: {score.reason}")
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import structlog
    logger = structlog.get_logger("aiglos.registry")
except ImportError:
    import logging
    logger = logging.getLogger("aiglos.registry")

# ---------------------------------------------------------------------------
# Known-good package names (registry of legitimate MCP packages)
# ---------------------------------------------------------------------------

KNOWN_GOOD_PACKAGES = [
    "@modelcontextprotocol/sdk",
    "@modelcontextprotocol/server-filesystem",
    "@modelcontextprotocol/server-github",
    "@modelcontextprotocol/server-google-maps",
    "@modelcontextprotocol/server-memory",
    "@modelcontextprotocol/server-postgres",
    "@modelcontextprotocol/server-slack",
    "@modelcontextprotocol/server-brave-search",
    "@anthropic-ai/sdk",
    "@postmarkapp/mcp",
    "mcp-remote",
    "smithery",
    "fastmcp",
    "mcp",
]

# Known-malicious package list (seed — updated by scan results)
KNOWN_MALICIOUS_PACKAGES = {
    "postmark-mcp-server",
    "mcp-postmark",
    "anthropic-mcp-server",
    "clude-mcp",
    "mcpp-sdk",
    "modelcontextprotocol-sdk",
    "claude-mcp-server",
    "mcp-server-anthropic",
}

# Social engineering signals in README / description
SOCIAL_ENGINEERING_RE = re.compile(
    r"(?i)(?:drop.?in\s+replacement|100%\s+compatible|official\s+(?:fork|mirror)|"
    r"faster\s+than\s+(?:official|original)|(?:unofficial\s+)?(?:enhanced|improved)\s+version\s+of|"
    r"works?\s+(?:better|faster)\s+than\s+@)"
)

# Overly broad permission language in package descriptions
BROAD_PERMISSION_RE = re.compile(
    r"(?i)(?:full\s+(?:access|control|permission)|unrestricted\s+(?:access|read|write)|"
    r"admin\s+(?:access|privilege)|root\s+access|all\s+files|entire\s+(?:disk|filesystem|drive))"
)

# MCP tool description injection patterns (same as proxy layer, applied to npm registry data)
TOOL_INJECTION_RE = re.compile(
    r"(?i)(?:ignore\s+(?:all\s+)?(?:previous|prior)\s+instructions?|"
    r"you\s+are\s+now|from\s+now\s+on|new\s+system\s+prompt|"
    r"IMPORTANT:\s*override)"
)


def _levenshtein(a: str, b: str) -> int:
    if len(a) < len(b):
        a, b = b, a
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a):
        curr = [i + 1]
        for j, cb in enumerate(b):
            curr.append(min(prev[j + 1] + 1, curr[j] + 1, prev[j] + (ca != cb)))
        prev = curr
    return prev[len(b)]


@dataclass
class PackageScore:
    package_name: str
    registry: str
    risk_level: str          # "critical" | "high" | "medium" | "low" | "clean"
    risk_score: float        # 0.0 - 1.0
    signals: list[str]       # Human-readable risk signals found
    reason: str = ""
    timestamp: float = field(default_factory=time.time)


@dataclass
class RegistryFinding:
    id: str
    vector: str
    severity: str
    title: str
    description: str
    package_name: str
    registry: str
    evidence: dict = field(default_factory=dict)
    remediation: str = ""
    cmmc_controls: list = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)


class RegistryMonitor:
    """
    Continuous registry monitor for MCP server packages.
    Runs on the intel refresh cycle and updates the local threat blocklist.
    """

    REGISTRIES = ["npm", "pypi", "smithery", "mcp.so"]

    # Packages to actively monitor for new versions / reputation changes
    WATCH_LIST = list(KNOWN_GOOD_PACKAGES) + [
        "mcp-remote",       # CVE-2025-6514 affected package
        "fastmcp",
        "mcp",
    ]

    def __init__(
        self,
        audit_db: str = "aiglos_audit.db",
        trust_file: str = "aiglos_trust.yaml",
        cache_file: str = ".aiglos_registry_cache.json",
    ):
        self.audit_db = audit_db
        self.trust_file = trust_file
        self.cache_file = cache_file
        self._n = 0
        self._cache: dict = self._load_cache()

    def _fid(self) -> str:
        self._n += 1
        return f"reg-{self._n:05d}"

    def _load_cache(self) -> dict:
        try:
            return json.loads(Path(self.cache_file).read_text())
        except Exception:
            return {"last_scan": 0, "seen_packages": {}, "blocked": []}

    def _save_cache(self) -> None:
        try:
            Path(self.cache_file).write_text(json.dumps(self._cache, indent=2))
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Package scoring (runs without network — uses local signals)
    # ------------------------------------------------------------------

    async def score_package(self, package_name: str, registry: str = "npm",
                            metadata: dict | None = None) -> PackageScore:
        """
        Score a single package for risk. Used for pre-install checks.
        metadata: optional dict with keys: description, readme, keywords, author_age_days
        """
        signals: list[str] = []
        score = 0.0
        meta = metadata or {}

        # Signal: known-malicious name
        clean_name = package_name.lstrip("@").split("/")[-1].lower()
        if package_name in KNOWN_MALICIOUS_PACKAGES or clean_name in KNOWN_MALICIOUS_PACKAGES:
            signals.append(f"Known-malicious package name: {package_name}")
            score = 1.0

        # Signal: typosquat detection
        if score < 1.0:
            for good in KNOWN_GOOD_PACKAGES:
                clean_good = good.lstrip("@").split("/")[-1].lower()
                if package_name.lower() != good.lower():
                    dist = _levenshtein(package_name.lower().replace("-", ""),
                                        good.lower().replace("-", ""))
                    if 0 < dist <= 2:
                        signals.append(f"Typosquat: edit distance {dist} from '{good}'")
                        score = max(score, 0.85)
                        break

        # Signal: social engineering in description/readme
        description = str(meta.get("description", "")) + " " + str(meta.get("readme", ""))
        if SOCIAL_ENGINEERING_RE.search(description):
            signals.append("Social engineering language in description/README")
            score = max(score, 0.75)

        # Signal: broad permission claims
        if BROAD_PERMISSION_RE.search(description):
            signals.append("Broad permission claims in description")
            score = max(score, 0.65)

        # Signal: tool injection patterns in description
        if TOOL_INJECTION_RE.search(description):
            signals.append("Tool injection pattern in package description")
            score = max(score, 0.90)

        # Signal: new publisher account
        author_age = meta.get("author_age_days")
        if author_age is not None and author_age < 30:
            signals.append(f"Publisher account only {author_age} days old")
            score = max(score, 0.60)

        # Signal: keyword overlap with malicious packages
        keywords = set(str(k).lower() for k in meta.get("keywords", []))
        suspicious_keywords = {"mcp", "claude", "anthropic", "openai"} & keywords
        malicious_name_words = set(
            w for name in KNOWN_MALICIOUS_PACKAGES
            for w in re.split(r"[-_]", name)
            if len(w) > 3
        )
        if suspicious_keywords and any(
            _levenshtein(package_name.lower(), m) <= 3
            for m in KNOWN_MALICIOUS_PACKAGES
        ):
            signals.append(f"Keyword overlap with malicious package pattern: {suspicious_keywords}")
            score = max(score, 0.55)

        # Map score to risk level
        if score >= 0.9:
            risk = "critical"
        elif score >= 0.75:
            risk = "high"
        elif score >= 0.55:
            risk = "medium"
        elif score > 0:
            risk = "low"
        else:
            risk = "clean"

        reason = "; ".join(signals) if signals else "No risk signals detected"
        return PackageScore(
            package_name=package_name,
            registry=registry,
            risk_level=risk,
            risk_score=round(score, 3),
            signals=signals,
            reason=reason,
        )

    # ------------------------------------------------------------------
    # Full registry scan
    # ------------------------------------------------------------------

    async def scan(self) -> list[RegistryFinding]:
        """
        Scan all monitored packages for new threats.
        Prioritizes local signal analysis (no network required for core scoring).
        Network calls are attempted opportunistically and fail safely.
        """
        start = time.monotonic()
        findings: list[RegistryFinding] = []

        # 1. Score all watch-list packages with local signals
        findings.extend(await self._scan_watchlist())

        # 2. Scan locally installed packages
        findings.extend(await self._scan_local_installs())

        # 3. Attempt live npm feed (fail safe)
        findings.extend(await self._scan_npm_feed_safe())

        # Update cache and trust registry
        self._cache["last_scan"] = time.time()
        self._save_cache()

        if findings:
            await self._persist(findings)
            await self._update_blocklist(findings)

        elapsed = round(time.monotonic() - start, 2)
        logger.info("registry_scan_complete", findings=len(findings), duration_s=elapsed)
        return findings

    async def _scan_watchlist(self) -> list[RegistryFinding]:
        """Score known-bad packages to generate findings for audit trail."""
        findings = []
        for pkg in KNOWN_MALICIOUS_PACKAGES:
            score = await self.score_package(pkg)
            if score.risk_level in ("critical", "high"):
                findings.append(RegistryFinding(
                    id=self._fid(),
                    vector="known_malicious_registry",
                    severity=score.risk_level,
                    title=f"Known-malicious MCP package active in registry: {pkg}",
                    description=(
                        f"Package '{pkg}' is on the Aiglos known-malicious list "
                        f"(risk score: {score.risk_score:.2f}). "
                        f"Signals: {score.reason}. "
                        f"This package remains publicly available and could be "
                        f"installed by any MCP user who encounters it."
                    ),
                    package_name=pkg,
                    registry="npm",
                    evidence={"signals": score.signals, "risk_score": score.risk_score},
                    remediation=(
                        f"Package '{pkg}' is blocked in aiglos_trust.yaml. "
                        f"Report to npm security team at security@npmjs.com."
                    ),
                    cmmc_controls=["3.14.2", "3.14.1"],
                ))
        return findings

    async def _scan_local_installs(self) -> list[RegistryFinding]:
        """Scan locally installed node_modules and Python site-packages."""
        findings = []

        # npm
        nm = Path("node_modules")
        if nm.exists():
            for pkg_dir in nm.iterdir():
                if not pkg_dir.is_dir():
                    continue
                pkg_name = pkg_dir.name
                pkg_json = pkg_dir / "package.json"
                meta = {}
                if pkg_json.exists():
                    try:
                        meta = json.loads(pkg_json.read_text())
                    except Exception:
                        pass
                description = meta.get("description", "")
                score = await self.score_package(
                    pkg_name, registry="npm",
                    metadata={"description": description,
                              "keywords": meta.get("keywords", [])}
                )
                if score.risk_level in ("critical", "high"):
                    findings.append(RegistryFinding(
                        id=self._fid(),
                        vector="local_install_risk",
                        severity=score.risk_level,
                        title=f"Risky package installed locally: {pkg_name}",
                        description=(
                            f"Locally installed package '{pkg_name}' scored "
                            f"{score.risk_score:.2f} risk. {score.reason}"
                        ),
                        package_name=pkg_name,
                        registry="npm/local",
                        evidence={"signals": score.signals, "path": str(pkg_dir)},
                        remediation=f"npm uninstall {pkg_name} && npm audit",
                        cmmc_controls=["3.14.2", "3.14.1"],
                    ))
        return findings

    async def _scan_npm_feed_safe(self) -> list[RegistryFinding]:
        """
        Attempt to fetch recent MCP-related npm packages.
        Fails silently if network is unavailable (test/air-gap environments).
        """
        findings = []
        try:
            import urllib.request
            url = "https://registry.npmjs.org/-/v1/search?text=mcp+server&size=20"
            req = urllib.request.Request(url, headers={"User-Agent": "aiglos-registry-monitor/1.0"})
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read())
            packages = data.get("objects", [])
            for obj in packages:
                pkg = obj.get("package", {})
                name = pkg.get("name", "")
                if not name:
                    continue
                description = pkg.get("description", "")
                keywords = pkg.get("keywords", [])
                author_age_days = None
                score = await self.score_package(
                    name, registry="npm",
                    metadata={"description": description, "keywords": keywords,
                              "author_age_days": author_age_days}
                )
                if score.risk_level in ("critical", "high"):
                    # Only report if not already in known-malicious (avoid duplicates)
                    if name not in KNOWN_MALICIOUS_PACKAGES:
                        KNOWN_MALICIOUS_PACKAGES.add(name)
                        findings.append(RegistryFinding(
                            id=self._fid(),
                            vector="registry_new_threat",
                            severity=score.risk_level,
                            title=f"New risky MCP package detected in npm registry: {name}",
                            description=(
                                f"Newly discovered package '{name}' on npm scores "
                                f"{score.risk_score:.2f} risk. {score.reason}"
                            ),
                            package_name=name,
                            registry="npm",
                            evidence={"signals": score.signals, "description": description[:200]},
                            remediation=f"Package added to Aiglos blocklist. Avoid installing '{name}'.",
                            cmmc_controls=["3.14.2", "3.14.1"],
                        ))
        except Exception as e:
            logger.debug("registry_npm_feed_skipped", reason=str(e))
        return findings

    async def _persist(self, findings: list[RegistryFinding]) -> None:
        try:
            from aiglos_core.audit import AuditLog
            from aiglos_core.types import SecurityEvent, EventType, Severity
            audit = AuditLog(self.audit_db)
            smap = {"critical": Severity.CRITICAL, "high": Severity.HIGH, "medium": Severity.MEDIUM}
            for f in findings:
                audit.record_event(SecurityEvent(
                    session_id="aiglos-registry",
                    event_type=EventType.ANOMALY_DETECTED,
                    severity=smap.get(f.severity, Severity.MEDIUM),
                    title=f.title,
                    description=f.description,
                    details=f.evidence,
                    cmmc_controls=f.cmmc_controls,
                ))
        except Exception as e:
            logger.debug("registry_persist_failed", error=str(e))

    async def _update_blocklist(self, findings: list[RegistryFinding]) -> None:
        """Add newly discovered malicious packages to aiglos_trust.yaml blocklist."""
        critical = [f for f in findings if f.severity == "critical"]
        if not critical:
            return
        try:
            import yaml
            path = Path(self.trust_file)
            trust = yaml.safe_load(path.read_text()) if path.exists() else {}
            trust = trust or {}
            blocked = trust.setdefault("blocked_packages", [])
            added = 0
            for f in critical:
                if f.package_name not in blocked:
                    blocked.append(f.package_name)
                    added += 1
            if added:
                path.write_text(yaml.dump(trust, default_flow_style=False))
                logger.info("registry_blocklist_updated", added=added)
        except Exception as e:
            logger.debug("registry_blocklist_update_failed", error=str(e))
