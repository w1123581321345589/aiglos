"""
T29: A2A Protocol Monitor

Agent-to-Agent (A2A) protocol security monitoring. Google's A2A spec
launched April 2025 and is now the primary inter-agent transport in:
  AutoGen, CrewAI, LangGraph, OpenAI Swarm, Google ADK, Vertex AI Agents

The attack surface is architecturally invisible to the MCP proxy layer —
A2A calls happen orchestrator-to-subagent, bypassing Aiglos entirely
unless explicitly wired into the A2A transport.

Three A2A-specific threat classes
----------------------------------
1. Orchestrator Impersonation
   A malicious agent claims to be the trusted orchestrator by forging
   its Agent Card identity fields. Without cryptographic verification,
   subagents accept instructions from imposters.
   Detection: Agent Card fingerprint registry + signature verification.

2. Task Hijacking via Artifact Injection
   An agent returns a Task result containing embedded instructions that
   modify the next agent's behavior (indirect prompt injection at the
   A2A artifact layer rather than the MCP tool layer).
   Detection: Pattern scan on all A2A Task artifacts and Part payloads.

3. Capability Escalation
   An agent advertises broader skills in its Agent Card than it actually
   has authorization for — requesting sensitive capabilities on behalf
   of the orchestrator without explicit delegation.
   Detection: Capability allowlist enforcement per registered agent identity.

Wire-in
-------
  # In your A2A transport wrapper:
  from aiglos_core.autonomous.a2a import A2AMonitor, A2AEvent
  monitor = A2AMonitor(audit_db="aiglos_audit.db")

  # On each A2A task dispatch:
  event = A2AEvent(
      orchestrator_id="agent-123",
      target_agent_id="agent-456",
      task_type="research",
      payload=task_dict,
      agent_card=card_dict,
  )
  verdict = await monitor.evaluate(event)
  if not verdict.allowed:
      raise SecurityError(verdict.reason)

  # Autonomous hunt cycle (called from ThreatHunter module 7):
  findings = await monitor.scan()
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import structlog
    logger = structlog.get_logger("aiglos.a2a")
except ImportError:
    import logging
    logger = logging.getLogger("aiglos.a2a")

# ---------------------------------------------------------------------------
# A2A artifact injection patterns (indirect prompt injection at task layer)
# ---------------------------------------------------------------------------

ARTIFACT_INJECTION_PATTERNS = [
    re.compile(r"(?i)ignore\s+(?:all\s+)?(?:previous|prior|above)\s+instructions?"),
    re.compile(r"(?i)you\s+are\s+now\s+(?:a|an|the)\s+\w"),
    re.compile(r"(?i)from\s+now\s+on[,\s]"),
    re.compile(r"(?i)new\s+(?:system\s+)?(?:prompt|instruction|directive)\s*:"),
    re.compile(r"(?i)<\s*/?(?:system|instruction|override)\s*>"),
    re.compile(r"[\u200b\u200c\u200d\u200e\u200f\ufeff]"),   # zero-width steganography
    re.compile(r"(?i)ORCHESTRATOR\s+OVERRIDE"),
    re.compile(r"(?i)agent\s+card\s+update\s*:"),            # card spoofing signal
]

# Capabilities that require explicit delegation (never auto-granted to subagents)
HIGH_RISK_CAPABILITIES = {
    "file_system_write", "shell_execution", "code_execution",
    "network_egress", "credential_access", "database_write",
    "email_send", "webhook_post", "llm_orchestration",
    "agent_spawn", "memory_write", "tool_registration",
}


@dataclass
class A2AEvent:
    """Represents a single A2A task dispatch event."""
    orchestrator_id: str
    target_agent_id: str
    task_type: str
    payload: dict = field(default_factory=dict)
    agent_card: dict = field(default_factory=dict)
    session_id: str = ""
    timestamp: float = field(default_factory=time.time)
    card_signature: str = ""      # Optional cryptographic signature of agent card
    delegation_token: str = ""    # Optional capability delegation proof


@dataclass
class A2AVerdict:
    """Real-time verdict for an A2A event."""
    allowed: bool
    reason: str = ""
    severity: str = "medium"
    cmmc_controls: list = field(default_factory=list)
    finding_id: str = ""


@dataclass
class A2AFinding:
    id: str
    vector: str
    severity: str
    title: str
    description: str
    orchestrator_id: str
    target_agent_id: str
    evidence: dict = field(default_factory=dict)
    remediation: str = ""
    cmmc_controls: list = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)


class A2AMonitor:
    """
    Monitors Agent-to-Agent protocol traffic for security threats.
    Provides both real-time evaluation and autonomous scan modes.
    """

    def __init__(
        self,
        audit_db: str = "aiglos_audit.db",
        trusted_agent_registry: dict[str, str] | None = None,
        capability_allowlist: dict[str, set] | None = None,
    ):
        self.audit_db = audit_db
        # agent_id -> card_fingerprint (SHA-256 of known-good Agent Card JSON)
        self._trusted_registry: dict[str, str] = trusted_agent_registry or {}
        # agent_id -> allowed capabilities
        self._capability_allowlist: dict[str, set] = capability_allowlist or {}
        self._n = 0

    def _fid(self) -> str:
        self._n += 1
        return f"a2a-{self._n:05d}"

    def register_agent(self, agent_id: str, agent_card: dict, allowed_capabilities: set | None = None) -> str:
        """Register a trusted agent and return its card fingerprint."""
        card_str = json.dumps(agent_card, sort_keys=True)
        fingerprint = hashlib.sha256(card_str.encode()).hexdigest()
        self._trusted_registry[agent_id] = fingerprint
        if allowed_capabilities is not None:
            self._capability_allowlist[agent_id] = allowed_capabilities
        return fingerprint

    # ------------------------------------------------------------------
    # Real-time evaluation
    # ------------------------------------------------------------------

    async def evaluate(self, event: A2AEvent) -> A2AVerdict:
        """Evaluate an A2A task dispatch in real time."""

        # 1. Orchestrator identity verification
        if event.orchestrator_id in self._trusted_registry:
            expected_fp = self._trusted_registry[event.orchestrator_id]
            if event.agent_card:
                card_str = json.dumps(event.agent_card, sort_keys=True)
                actual_fp = hashlib.sha256(card_str.encode()).hexdigest()
                if actual_fp != expected_fp:
                    return A2AVerdict(
                        allowed=False,
                        reason=(
                            f"Agent Card fingerprint mismatch for orchestrator "
                            f"'{event.orchestrator_id}'. Expected {expected_fp[:12]}... "
                            f"got {actual_fp[:12]}... Possible orchestrator impersonation."
                        ),
                        severity="critical",
                        cmmc_controls=["3.5.1", "3.5.3", "3.13.8"],
                    )

        # 2. Artifact injection scan
        payload_str = json.dumps(event.payload)
        for pat in ARTIFACT_INJECTION_PATTERNS:
            if pat.search(payload_str):
                return A2AVerdict(
                    allowed=False,
                    reason=(
                        f"A2A task payload from '{event.orchestrator_id}' to "
                        f"'{event.target_agent_id}' contains artifact injection pattern. "
                        f"Indirect prompt injection via A2A artifact layer detected."
                    ),
                    severity="critical",
                    cmmc_controls=["3.14.2", "3.13.1"],
                )

        # 3. Capability escalation check
        card_capabilities = set()
        skills = event.agent_card.get("skills", [])
        for skill in skills:
            card_capabilities.update(skill.get("capabilities", []))
            card_capabilities.add(skill.get("id", ""))

        high_risk_requested = card_capabilities & HIGH_RISK_CAPABILITIES
        if high_risk_requested:
            allowed = self._capability_allowlist.get(event.orchestrator_id, set())
            unauthorized = high_risk_requested - allowed
            if unauthorized and not event.delegation_token:
                return A2AVerdict(
                    allowed=False,
                    reason=(
                        f"Agent '{event.orchestrator_id}' is requesting high-risk "
                        f"capabilities {unauthorized} for target '{event.target_agent_id}' "
                        f"without a delegation token. Capability escalation blocked."
                    ),
                    severity="high",
                    cmmc_controls=["3.1.1", "3.1.2", "3.5.3"],
                )

        return A2AVerdict(allowed=True, reason="A2A event cleared")

    # ------------------------------------------------------------------
    # Autonomous scan (reads audit DB for historical A2A events)
    # ------------------------------------------------------------------

    async def scan(self) -> list[A2AFinding]:
        """Scan audit DB for A2A anomalies."""
        findings: list[A2AFinding] = []
        try:
            import sqlite3
            conn = sqlite3.connect(self.audit_db)
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT * FROM tool_calls WHERE tool_name LIKE '%a2a%' "
                "OR tool_name LIKE '%agent%task%' OR tool_name LIKE '%dispatch%' "
                "ORDER BY timestamp DESC LIMIT 500"
            ).fetchall()
            conn.close()
        except Exception as e:
            logger.debug("a2a_scan_db_failed", error=str(e))
            return findings

        for row in rows:
            d = dict(row)
            args_str = d.get("arguments", "") or ""
            result_str = d.get("result", "") or ""
            combined = args_str + " " + result_str

            for pat in ARTIFACT_INJECTION_PATTERNS:
                if pat.search(combined):
                    findings.append(A2AFinding(
                        id=self._fid(),
                        vector="artifact_injection",
                        severity="critical",
                        title="A2A artifact injection in historical task payload",
                        description=(
                            f"Historical A2A task in session "
                            f"{d.get('session_id', '?')[:8]} contains artifact "
                            f"injection pattern. Indirect prompt injection via the "
                            f"A2A task/artifact layer."
                        ),
                        orchestrator_id=d.get("session_id", "unknown"),
                        target_agent_id=d.get("tool_name", "unknown"),
                        evidence={"session_id": d.get("session_id"), "tool": d.get("tool_name")},
                        remediation=(
                            "Scan all A2A task artifacts before forwarding to subagents. "
                            "Enable Aiglos A2AMonitor real-time evaluation in your A2A transport."
                        ),
                        cmmc_controls=["3.14.2", "3.13.1"],
                    ))
                    break

        if findings:
            await self._persist(findings)
        logger.info("a2a_scan_complete", findings=len(findings), events_scanned=len(rows))
        return findings

    async def _persist(self, findings: list[A2AFinding]) -> None:
        try:
            from aiglos_core.audit import AuditLog
            from aiglos_core.types import SecurityEvent, EventType, Severity
            audit = AuditLog(self.audit_db)
            smap = {"critical": Severity.CRITICAL, "high": Severity.HIGH, "medium": Severity.MEDIUM}
            for f in findings:
                audit.record_event(SecurityEvent(
                    session_id=f.orchestrator_id,
                    event_type=EventType.ANOMALY_DETECTED,
                    severity=smap.get(f.severity, Severity.HIGH),
                    title=f.title,
                    description=f.description,
                    details=f.evidence,
                    cmmc_controls=f.cmmc_controls,
                ))
        except Exception as e:
            logger.debug("a2a_persist_failed", error=str(e))
