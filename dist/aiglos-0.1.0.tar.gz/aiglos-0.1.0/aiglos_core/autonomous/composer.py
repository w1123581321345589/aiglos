"""
T32: Skill Composition Analyzer

Static analysis of registered MCP tool combinations at session start.
Detects dangerous capability compositions before the agent runs —
not after a suspicious tool call has already happened.

The core insight
----------------
Individual tools can each be innocuous while their combination creates
a dangerous capability:

  read_file + send_email         = exfiltration pipeline
  list_directory + http_post     = filesystem reconnaissance + exfil
  execute_code + network_request = RCE with command-and-control
  read_memory + write_file       = cross-session data harvesting
  search_web + read_clipboard    = PII harvesting pipeline
  git_commit + email_send        = source code exfiltration

None of these tool pairs trigger individual anomaly detection.
The analyzer catches them at composition time.

How it works
------------
Each registered tool is mapped to a capability taxonomy:
  READ_FS, WRITE_FS, EXECUTE_CODE, NETWORK_EGRESS, NETWORK_INGRESS,
  EMAIL_SEND, MEMORY_READ, MEMORY_WRITE, CREDENTIAL_ACCESS,
  SPAWN_PROCESS, SPAWN_AGENT, CLIPBOARD_ACCESS, BROWSER_CONTROL

Dangerous compositions are defined as pairs or triples of capabilities
whose combination exceeds the authorized scope of the session's goal.
The analyzer scores each combination against the Goal Integrity Engine
(T6) authorized objective.

Integration
-----------
  from aiglos_core.autonomous.composer import SkillComposer

  composer = SkillComposer(audit_db="aiglos_audit.db")

  # At session start, analyze registered tools:
  result = await composer.analyze_session(
      session_id="sess-123",
      registered_tools=list_of_tool_dicts,
      authorized_goal="Summarize the weekly sales report",
  )
  if result.risk_level == "critical":
      # Block session or require human approval
      raise SecurityError(result.summary())

  # Wire into ThreatHunter as module 8:
  findings = await composer.scan()
"""

from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import Any

try:
    import structlog
    logger = structlog.get_logger("aiglos.composer")
except ImportError:
    import logging
    logger = logging.getLogger("aiglos.composer")


# ---------------------------------------------------------------------------
# Capability taxonomy
# ---------------------------------------------------------------------------

class Cap(str, Enum):
    READ_FS        = "read_fs"
    WRITE_FS       = "write_fs"
    EXECUTE_CODE   = "execute_code"
    SPAWN_PROCESS  = "spawn_process"
    NETWORK_EGRESS = "network_egress"
    NETWORK_INGRESS = "network_ingress"
    EMAIL_SEND     = "email_send"
    MEMORY_READ    = "memory_read"
    MEMORY_WRITE   = "memory_write"
    CREDENTIAL_ACCESS = "credential_access"
    SPAWN_AGENT    = "spawn_agent"
    CLIPBOARD      = "clipboard"
    BROWSER        = "browser"
    DATABASE_READ  = "database_read"
    DATABASE_WRITE = "database_write"
    CALENDAR       = "calendar"
    SLACK_POST     = "slack_post"
    GIT_WRITE      = "git_write"


# Tool name → capability mappings (keyword-based inference)
TOOL_CAPABILITY_MAP: dict[str, list[Cap]] = {
    # Filesystem
    "read_file":      [Cap.READ_FS],
    "write_file":     [Cap.WRITE_FS],
    "list_directory": [Cap.READ_FS],
    "delete_file":    [Cap.WRITE_FS],
    "move_file":      [Cap.READ_FS, Cap.WRITE_FS],
    "create_directory": [Cap.WRITE_FS],
    # Code / process
    "execute_code":   [Cap.EXECUTE_CODE],
    "run_terminal":   [Cap.SPAWN_PROCESS, Cap.NETWORK_EGRESS],
    "bash":           [Cap.SPAWN_PROCESS, Cap.EXECUTE_CODE],
    "shell":          [Cap.SPAWN_PROCESS, Cap.EXECUTE_CODE],
    "python_repl":    [Cap.EXECUTE_CODE],
    # Network
    "http_request":   [Cap.NETWORK_EGRESS, Cap.NETWORK_INGRESS],
    "fetch_url":      [Cap.NETWORK_INGRESS],
    "http_post":      [Cap.NETWORK_EGRESS],
    "web_search":     [Cap.NETWORK_INGRESS],
    "browse_web":     [Cap.BROWSER, Cap.NETWORK_INGRESS],
    # Email / messaging
    "send_email":     [Cap.EMAIL_SEND, Cap.NETWORK_EGRESS],
    "gmail_send":     [Cap.EMAIL_SEND, Cap.NETWORK_EGRESS],
    "slack_message":  [Cap.SLACK_POST, Cap.NETWORK_EGRESS],
    "slack_post":     [Cap.SLACK_POST, Cap.NETWORK_EGRESS],
    # Memory
    "memory_add":     [Cap.MEMORY_WRITE],
    "memory_get":     [Cap.MEMORY_READ],
    "memory_search":  [Cap.MEMORY_READ],
    "mem_write":      [Cap.MEMORY_WRITE],
    # Credentials
    "get_secret":     [Cap.CREDENTIAL_ACCESS],
    "read_env":       [Cap.CREDENTIAL_ACCESS],
    "keychain_get":   [Cap.CREDENTIAL_ACCESS],
    # Database
    "sql_query":      [Cap.DATABASE_READ],
    "db_write":       [Cap.DATABASE_WRITE],
    "postgres_query": [Cap.DATABASE_READ],
    # Git
    "git_push":       [Cap.GIT_WRITE, Cap.NETWORK_EGRESS],
    "git_commit":     [Cap.GIT_WRITE],
    # Agents
    "spawn_agent":    [Cap.SPAWN_AGENT],
    "create_agent":   [Cap.SPAWN_AGENT],
    # Clipboard / browser
    "read_clipboard": [Cap.CLIPBOARD],
    "browser_action": [Cap.BROWSER, Cap.NETWORK_INGRESS],
    # Calendar
    "create_event":   [Cap.CALENDAR],
    "calendar_write": [Cap.CALENDAR],
}

# Keyword signals for capability inference from tool descriptions
CAP_KEYWORD_SIGNALS: list[tuple[re.Pattern, Cap]] = [
    (re.compile(r"(?i)\b(?:read|open|load|get|fetch)\b.{0,20}\bfile\b"), Cap.READ_FS),
    (re.compile(r"(?i)\b(?:write|save|create|delete|move|copy)\b.{0,20}\bfile\b"), Cap.WRITE_FS),
    (re.compile(r"(?i)\b(?:execute|run|eval|exec)\b.{0,20}\b(?:code|script|command|python|bash)\b"), Cap.EXECUTE_CODE),
    (re.compile(r"(?i)\b(?:http|post|request|curl|fetch)\b.{0,30}\b(?:url|endpoint|api)\b"), Cap.NETWORK_EGRESS),
    (re.compile(r"(?i)\bsend\b.{0,30}\b(?:email|mail|message)\b"), Cap.EMAIL_SEND),
    (re.compile(r"(?i)\b(?:memory|remember|recall|store)\b"), Cap.MEMORY_WRITE),
    (re.compile(r"(?i)\b(?:secret|credential|password|token|api.?key)\b"), Cap.CREDENTIAL_ACCESS),
    (re.compile(r"(?i)\bgit\b.{0,20}\b(?:push|commit|merge)\b"), Cap.GIT_WRITE),
    (re.compile(r"(?i)\b(?:spawn|create|launch)\b.{0,20}\bagent\b"), Cap.SPAWN_AGENT),
    (re.compile(r"(?i)\bclipboard\b"), Cap.CLIPBOARD),
    (re.compile(r"(?i)\bbrowser\b.{0,20}\b(?:navigate|click|open|control)\b"), Cap.BROWSER),
    (re.compile(r"(?i)\b(?:sql|database|postgres|mysql|sqlite)\b"), Cap.DATABASE_READ),
    (re.compile(r"(?i)\bslack\b"), Cap.SLACK_POST),
]


# ---------------------------------------------------------------------------
# Dangerous composition rules
# ---------------------------------------------------------------------------

@dataclass
class CompositionRule:
    id: str
    name: str
    required_caps: frozenset        # All of these must be present
    severity: str
    description: str
    remediation: str
    cmmc_controls: list = field(default_factory=list)


COMPOSITION_RULES: list[CompositionRule] = [
    CompositionRule(
        id="CR-001",
        name="Filesystem Exfiltration Pipeline",
        required_caps=frozenset({Cap.READ_FS, Cap.NETWORK_EGRESS}),
        severity="critical",
        description=(
            "Registered tools include both filesystem read AND network egress capabilities. "
            "This combination enables exfiltration of any readable file to an external endpoint."
        ),
        remediation=(
            "Remove network egress tools from sessions that require filesystem access, "
            "or add REQUIRE_APPROVAL policy rule for tool combinations involving "
            "both READ_FS and NETWORK_EGRESS."
        ),
        cmmc_controls=["3.1.1", "3.13.1", "3.14.2"],
    ),
    CompositionRule(
        id="CR-002",
        name="Email Exfiltration Pipeline",
        required_caps=frozenset({Cap.READ_FS, Cap.EMAIL_SEND}),
        severity="critical",
        description=(
            "Registered tools include both filesystem read AND email send. "
            "Classic data exfiltration vector: read file contents, forward via email."
        ),
        remediation="Separate file-access sessions from email-send sessions.",
        cmmc_controls=["3.1.1", "3.13.1"],
    ),
    CompositionRule(
        id="CR-003",
        name="RCE with Command-and-Control",
        required_caps=frozenset({Cap.EXECUTE_CODE, Cap.NETWORK_EGRESS}),
        severity="critical",
        description=(
            "Registered tools include code execution AND network egress. "
            "An injected prompt can execute arbitrary code and phone home."
        ),
        remediation=(
            "Never register code execution tools alongside unrestricted network egress. "
            "Use sandboxed execution environments for code tools."
        ),
        cmmc_controls=["3.14.2", "3.1.1", "3.13.1"],
    ),
    CompositionRule(
        id="CR-004",
        name="Cross-Session Memory Harvesting",
        required_caps=frozenset({Cap.MEMORY_READ, Cap.WRITE_FS}),
        severity="high",
        description=(
            "Registered tools include memory read AND filesystem write. "
            "Can harvest other users' memories and persist them to disk."
        ),
        remediation="Add session_id isolation to all memory read tools.",
        cmmc_controls=["3.1.1", "3.13.1"],
    ),
    CompositionRule(
        id="CR-005",
        name="Source Code Exfiltration",
        required_caps=frozenset({Cap.GIT_WRITE, Cap.NETWORK_EGRESS}),
        severity="high",
        description=(
            "Git write capability alongside network egress enables source code "
            "exfiltration via git push to an attacker-controlled remote."
        ),
        remediation="Restrict git push to approved remotes via allowlist.",
        cmmc_controls=["3.13.1", "3.14.2"],
    ),
    CompositionRule(
        id="CR-006",
        name="Credential Exfiltration",
        required_caps=frozenset({Cap.CREDENTIAL_ACCESS, Cap.NETWORK_EGRESS}),
        severity="critical",
        description=(
            "Credential access tools combined with network egress enables "
            "direct exfiltration of API keys, passwords, and tokens."
        ),
        remediation=(
            "Credential access tools must never be registered in sessions with "
            "outbound network capability. Use secrets managers with audit trails."
        ),
        cmmc_controls=["3.13.10", "3.5.3", "3.14.2"],
    ),
    CompositionRule(
        id="CR-007",
        name="Agentic Escalation Chain",
        required_caps=frozenset({Cap.SPAWN_AGENT, Cap.CREDENTIAL_ACCESS}),
        severity="high",
        description=(
            "Agent spawning with credential access enables an agent to create "
            "sub-agents pre-loaded with stolen credentials."
        ),
        remediation=(
            "Delegation tokens are required before any spawned agent can "
            "inherit credential access. Enable T33 Cross-Vendor Identity Bridge."
        ),
        cmmc_controls=["3.5.1", "3.5.3", "3.13.8"],
    ),
    CompositionRule(
        id="CR-008",
        name="Database Exfiltration Pipeline",
        required_caps=frozenset({Cap.DATABASE_READ, Cap.NETWORK_EGRESS}),
        severity="critical",
        description=(
            "Database read combined with network egress enables bulk "
            "exfiltration of database contents to external endpoints."
        ),
        remediation="Isolate database access sessions from network egress tools.",
        cmmc_controls=["3.1.1", "3.13.1"],
    ),
    CompositionRule(
        id="CR-009",
        name="Clipboard PII Harvesting",
        required_caps=frozenset({Cap.CLIPBOARD, Cap.NETWORK_EGRESS}),
        severity="high",
        description=(
            "Clipboard read combined with network egress enables silent "
            "harvesting of clipboard contents (passwords, PII) to external endpoints."
        ),
        remediation="Remove clipboard access from sessions with network egress.",
        cmmc_controls=["3.1.1", "3.13.1"],
    ),
    CompositionRule(
        id="CR-010",
        name="Browser Session Hijacking",
        required_caps=frozenset({Cap.BROWSER, Cap.MEMORY_WRITE}),
        severity="high",
        description=(
            "Browser control combined with memory write enables session cookie "
            "harvesting and persistence across agent sessions."
        ),
        remediation="Isolate browser control sessions from memory write tools.",
        cmmc_controls=["3.13.10", "3.5.3"],
    ),
]


@dataclass
class CompositionResult:
    session_id: str
    tools_analyzed: int
    capabilities_detected: list[str]
    rules_triggered: list[CompositionRule]
    risk_level: str      # "critical" | "high" | "medium" | "clean"
    duration_s: float = 0.0

    def summary(self) -> str:
        if not self.rules_triggered:
            return f"Composition clean: {self.tools_analyzed} tools, no dangerous combinations."
        names = [r.name for r in self.rules_triggered]
        return (
            f"COMPOSITION RISK [{self.risk_level.upper()}]: "
            f"{len(self.rules_triggered)} dangerous combination(s) detected "
            f"across {self.tools_analyzed} tools: {', '.join(names)}"
        )


@dataclass
class CompositionFinding:
    id: str
    rule: CompositionRule
    severity: str
    session_id: str
    capabilities_detected: list[str]
    tools_involved: list[str]
    evidence: dict = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)


class SkillComposer:
    """
    Analyzes registered tool combinations for dangerous capability compositions.
    Runs at session start (static analysis) and as autonomous hunt module 8.
    """

    def __init__(self, audit_db: str = "aiglos_audit.db"):
        self.audit_db = audit_db
        self._n = 0

    def _fid(self) -> str:
        self._n += 1
        return f"comp-{self._n:05d}"

    def infer_capabilities(self, tool: dict) -> set[Cap]:
        """Infer capabilities from a tool definition dict."""
        caps: set[Cap] = set()
        name = tool.get("name", "").lower().replace("-", "_")
        description = tool.get("description", "") + " " + str(tool.get("inputSchema", ""))

        # Direct name lookup
        if name in TOOL_CAPABILITY_MAP:
            caps.update(TOOL_CAPABILITY_MAP[name])

        # Partial name match
        for tool_key, tool_caps in TOOL_CAPABILITY_MAP.items():
            if tool_key in name or name in tool_key:
                caps.update(tool_caps)

        # Description-based inference
        for pat, cap in CAP_KEYWORD_SIGNALS:
            if pat.search(description):
                caps.add(cap)

        return caps

    async def analyze_session(
        self,
        session_id: str,
        registered_tools: list[dict],
        authorized_goal: str = "",
    ) -> CompositionResult:
        """
        Analyze a session's registered tools for dangerous capability compositions.
        Call at session start before any tools are invoked.
        """
        start = time.monotonic()

        # Build capability map across all tools
        all_caps: set[Cap] = set()
        tool_cap_map: dict[str, set[Cap]] = {}
        for tool in registered_tools:
            tool_name = tool.get("name", "unknown")
            caps = self.infer_capabilities(tool)
            tool_cap_map[tool_name] = caps
            all_caps.update(caps)

        # Check each composition rule
        triggered: list[CompositionRule] = []
        for rule in COMPOSITION_RULES:
            if rule.required_caps.issubset(all_caps):
                triggered.append(rule)

        # Goal-based suppression: if the authorized goal explicitly requires
        # a dangerous combination, reduce severity (but still log)
        if authorized_goal:
            triggered = self._apply_goal_context(triggered, authorized_goal)

        # Determine overall risk level
        if any(r.severity == "critical" for r in triggered):
            risk = "critical"
        elif any(r.severity == "high" for r in triggered):
            risk = "high"
        elif triggered:
            risk = "medium"
        else:
            risk = "clean"

        elapsed = round(time.monotonic() - start, 4)
        result = CompositionResult(
            session_id=session_id,
            tools_analyzed=len(registered_tools),
            capabilities_detected=[c.value for c in all_caps],
            rules_triggered=triggered,
            risk_level=risk,
            duration_s=elapsed,
        )

        # Persist findings for non-clean results
        if triggered:
            await self._persist(session_id, triggered, tool_cap_map)
            logger.warning("composition_risk_detected",
                           session_id=session_id[:8], risk=risk,
                           rules=[r.id for r in triggered])
        else:
            logger.info("composition_clean", session_id=session_id[:8],
                        tools=len(registered_tools), caps=len(all_caps))

        return result

    def _apply_goal_context(
        self, triggered: list[CompositionRule], goal: str
    ) -> list[CompositionRule]:
        """
        Suppress false positives when the authorized goal explicitly requires
        a flagged combination (e.g., goal = "email the sales report" legitimately
        requires READ_FS + EMAIL_SEND).
        """
        goal_lower = goal.lower()
        suppressed = []
        for rule in triggered:
            # CR-002: email + file read — suppress if goal mentions emailing a report
            if rule.id == "CR-002" and any(
                kw in goal_lower for kw in ("email", "send", "forward", "share")
            ):
                logger.info("composition_goal_suppressed", rule=rule.id, goal=goal[:60])
                continue
            # CR-005: git + network — suppress if goal mentions deploying or pushing
            if rule.id == "CR-005" and any(
                kw in goal_lower for kw in ("deploy", "push", "publish", "release")
            ):
                logger.info("composition_goal_suppressed", rule=rule.id, goal=goal[:60])
                continue
            suppressed.append(rule)
        return suppressed

    async def _persist(
        self,
        session_id: str,
        rules: list[CompositionRule],
        tool_cap_map: dict[str, set[Cap]],
    ) -> None:
        try:
            from aiglos_core.audit import AuditLog
            from aiglos_core.types import SecurityEvent, EventType, Severity
            audit = AuditLog(self.audit_db)
            smap = {"critical": Severity.CRITICAL, "high": Severity.HIGH, "medium": Severity.MEDIUM}
            for rule in rules:
                involved_tools = [
                    t for t, caps in tool_cap_map.items()
                    if caps & rule.required_caps
                ]
                audit.record_event(SecurityEvent(
                    session_id=session_id,
                    event_type=EventType.POLICY_VIOLATION,
                    severity=smap.get(rule.severity, Severity.HIGH),
                    title=f"Dangerous skill composition: {rule.name}",
                    description=rule.description,
                    details={"rule_id": rule.id, "tools": involved_tools[:10]},
                    cmmc_controls=rule.cmmc_controls,
                ))
        except Exception as e:
            logger.debug("composer_persist_failed", error=str(e))

    async def scan(self) -> list[CompositionFinding]:
        """
        Autonomous scan: reads recent sessions from audit DB and scores
        the tool combinations observed in each session.
        """
        findings: list[CompositionFinding] = []
        try:
            import sqlite3
            conn = sqlite3.connect(self.audit_db)
            conn.row_factory = sqlite3.Row

            # Get distinct tool names per session from recent tool calls
            rows = conn.execute(
                "SELECT session_id, GROUP_CONCAT(DISTINCT tool_name) as tools "
                "FROM tool_calls GROUP BY session_id ORDER BY MAX(timestamp) DESC LIMIT 100"
            ).fetchall()
            conn.close()

            for row in rows:
                d = dict(row)
                session_id = d.get("session_id", "")
                tools_str = d.get("tools", "") or ""
                tool_names = [t.strip() for t in tools_str.split(",") if t.strip()]
                tool_dicts = [{"name": n, "description": ""} for n in tool_names]

                result = await self.analyze_session(session_id, tool_dicts)
                for rule in result.rules_triggered:
                    findings.append(CompositionFinding(
                        id=self._fid(),
                        rule=rule,
                        severity=rule.severity,
                        session_id=session_id,
                        capabilities_detected=result.capabilities_detected,
                        tools_involved=tool_names,
                        evidence={"rule_id": rule.id, "tools": tool_names[:10]},
                    ))

        except Exception as e:
            logger.debug("composer_scan_failed", error=str(e))

        return findings
