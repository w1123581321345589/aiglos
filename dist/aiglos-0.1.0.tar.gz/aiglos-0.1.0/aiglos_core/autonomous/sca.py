"""
T26: Supply Chain Scanner (SCA)

Proactive supply chain security for MCP server packages. Catches attack
vectors documented in 2025-2026:

  Postmark MCP Impersonation
    A malicious NPM package masquerading as the official Postmark MCP server
    BCC'd all email traffic to an attacker-controlled address. Detection:
    package name similarity scoring against known-good names.

  Smithery Path Traversal
    smithery.yaml build config allowed path traversal during hosted MCP server
    build, giving read access to arbitrary files on the build host. Detection:
    YAML config pattern scan for path traversal indicators.

  Anthropic mcp-server-git CVEs (January 2026)
    CVE-2025-68143: git_init creates repos at arbitrary paths.
    CVE-2026-22807: x-enumDescriptions fields embedded without escaping.
    CVE-2026-23947: different code path, same unescaped embedding.
    Detection: version pinning check + known-vulnerable version registry.

  Endor Labs: 82% path traversal exposure
    Among 2,614 MCP implementations analyzed, 82% use file system operations
    prone to CWE-22 path traversal. Detection: tool definition permission
    analysis against a risk taxonomy.

What it scans
-------------
  1. Package manifest analysis (package.json, pyproject.toml, requirements.txt)
     - Known-malicious package hash list
     - Version downgrade detection (dependency confusion signal)
     - Suspicious package name similarity to known-good names

  2. MCP server config analysis (claude_desktop_config.json, .mcp_settings.json)
     - Tool definitions with overly broad filesystem access
     - Inline credentials in server command arguments

  3. smithery.yaml / build config analysis
     - Path traversal patterns in build steps

Integration
-----------
  # Wires into intel refresh cycle in engine.py:
  from aiglos_core.autonomous.sca import SupplyChainScanner
  scanner = SupplyChainScanner(audit_db="aiglos_audit.db")
  findings = await scanner.scan()
  # Findings automatically persisted to audit DB and trust registry
"""

from __future__ import annotations

import asyncio
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import structlog

logger = structlog.get_logger("aiglos.sca")

# ---------------------------------------------------------------------------
# Known-malicious package names (updated by intel refresh)
# ---------------------------------------------------------------------------

KNOWN_MALICIOUS_PACKAGES = {
    "postmark-mcp-server",       # impersonation — real package: @postmarkapp/mcp
    "mcp-postmark",              # variant
    "anthropic-mcp-server",      # typosquat
    "clude-mcp",                 # claude typosquat
    "mcpp-sdk",                  # mcp typosquat
    "modelcontextprotocol-sdk",  # official is @modelcontextprotocol/sdk
}

# Known-vulnerable package version ranges {name: [(min, max, cve)]}
VULNERABLE_VERSIONS = {
    "mcp-remote": [("0.0.5", "0.1.15", "CVE-2025-6514")],
    "@anthropic-ai/mcp-server-git": [("0.0.1", "0.1.0", "CVE-2025-68143")],
}

# Suspicious permission patterns in MCP tool definitions
BROAD_PERMISSION_RE = re.compile(
    r"(?i)(all\s+files|entire\s+(filesystem|disk|drive)|"
    r"recursive\s+access|unrestricted\s+(read|write|access)|"
    r"root\s+access|sudo|admin\s+privilege)"
)

# Path traversal patterns in build configs
PATH_TRAVERSAL_RE = re.compile(
    r"(?:\.\.[\\/]){2,}|"              # ../../..
    r"(?:^|[\s\"'])/etc/|"             # absolute sensitive paths
    r"(?:^|[\s\"'])/proc/|"
    r"(?:^|[\s\"'])/sys/|"
    r"\$\{?(?:HOME|ROOT|PWD)\}?/\.\."  # env var traversal
)

# Inline credential patterns in command strings
INLINE_CRED_RE = re.compile(
    r"(?i)(?:"
    r"sk-ant-api\d{2}-[A-Za-z0-9\-_]{93}|"     # Anthropic key
    r"AKIA[0-9A-Z]{16}|"                          # AWS access key
    r"ghp_[A-Za-z0-9]{36}|"                      # GitHub PAT
    r"password\s*[:=]\s*\S{8,}|"                 # plaintext password
    r"secret\s*[:=]\s*['\"]?\S{8,}"              # generic secret
    r")"
)

# Similarity check: Levenshtein distance for typosquatting detection
def _levenshtein(a: str, b: str) -> int:
    if len(a) < len(b):
        a, b = b, a
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a):
        curr = [i + 1]
        for j, cb in enumerate(b):
            curr.append(min(prev[j + 1] + 1, curr[j] + 1,
                            prev[j] + (ca != cb)))
        prev = curr
    return prev[len(b)]


KNOWN_GOOD_PACKAGE_NAMES = [
    "@modelcontextprotocol/sdk",
    "@anthropic-ai/sdk",
    "mcp-remote",
    "@postmarkapp/mcp",
    "smithery",
]


@dataclass
class ScaFinding:
    id: str
    vector: str
    severity: str
    title: str
    description: str
    source_file: str
    evidence: dict = field(default_factory=dict)
    remediation: str = ""
    cmmc_controls: list = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)


class SupplyChainScanner:
    """
    Proactive supply chain scanner for MCP server packages and configs.
    Runs on the intel_refresh cycle (hourly by default).
    """

    def __init__(
        self,
        audit_db: str = "aiglos_audit.db",
        scan_paths: list[str] | None = None,
    ):
        self.audit_db = audit_db
        self.scan_paths = scan_paths or [
            "package.json",
            "package-lock.json",
            "pyproject.toml",
            "requirements.txt",
            "claude_desktop_config.json",
            ".claude/mcp_settings.json",
            "smithery.yaml",
            ".mcp_settings.json",
        ]
        self._n = 0

    def _fid(self) -> str:
        self._n += 1
        return f"sca-{self._n:05d}"

    async def scan(self) -> list[ScaFinding]:
        """Full supply chain scan. Returns findings and persists to audit DB."""
        start = time.monotonic()
        findings: list[ScaFinding] = []

        findings.extend(await self._scan_package_manifests())
        findings.extend(await self._scan_mcp_configs())
        findings.extend(await self._scan_build_configs())

        if findings:
            await self._persist(findings)
            await self._update_trust_registry(findings)

        elapsed = round(time.monotonic() - start, 2)
        logger.info("sca_scan_complete", findings=len(findings), duration_s=elapsed)
        return findings

    # ------------------------------------------------------------------
    # 1. Package manifest analysis
    # ------------------------------------------------------------------

    async def _scan_package_manifests(self) -> list[ScaFinding]:
        findings = []

        for path_str in self.scan_paths:
            path = Path(path_str)
            if not path.exists():
                continue

            if path.name == "package.json":
                findings.extend(self._check_npm_manifest(path))
            elif path.name in ("requirements.txt", "pyproject.toml"):
                findings.extend(self._check_python_manifest(path))

        return findings

    def _check_npm_manifest(self, path: Path) -> list[ScaFinding]:
        findings = []
        try:
            manifest = json.loads(path.read_text())
        except Exception:
            return findings

        all_deps = {}
        all_deps.update(manifest.get("dependencies", {}))
        all_deps.update(manifest.get("devDependencies", {}))

        for pkg_name, version_spec in all_deps.items():
            # Known malicious packages
            if pkg_name in KNOWN_MALICIOUS_PACKAGES:
                findings.append(ScaFinding(
                    id=self._fid(),
                    vector="known_malicious_package",
                    severity="critical",
                    title=f"Known-malicious MCP package: {pkg_name}",
                    description=(
                        f"Package '{pkg_name}' in {path} is on the Aiglos "
                        f"known-malicious list. This package has been associated "
                        f"with MCP supply chain attacks including impersonation "
                        f"and credential exfiltration."
                    ),
                    source_file=str(path),
                    evidence={"package": pkg_name, "version": version_spec},
                    remediation=f"Remove '{pkg_name}' immediately. Audit all data processed by this package.",
                    cmmc_controls=["3.14.2", "3.14.1"],
                ))

            # Typosquatting check against known-good names
            for good_name in KNOWN_GOOD_PACKAGE_NAMES:
                if pkg_name != good_name:
                    dist = _levenshtein(pkg_name.lower(), good_name.lower())
                    if 0 < dist <= 2:
                        findings.append(ScaFinding(
                            id=self._fid(),
                            vector="typosquat",
                            severity="high",
                            title=f"Possible typosquat: '{pkg_name}' similar to '{good_name}'",
                            description=(
                                f"Package '{pkg_name}' has an edit distance of {dist} "
                                f"from the known-good package '{good_name}'. "
                                f"This pattern is consistent with dependency confusion "
                                f"and typosquatting attacks."
                            ),
                            source_file=str(path),
                            evidence={
                                "package": pkg_name,
                                "similar_to": good_name,
                                "edit_distance": dist,
                            },
                            remediation=f"Verify '{pkg_name}' is the intended package.",
                            cmmc_controls=["3.14.2"],
                        ))

            # Known-vulnerable version check
            base_name = pkg_name.lstrip("@").split("/")[-1] if "/" in pkg_name else pkg_name
            if pkg_name in VULNERABLE_VERSIONS or base_name in VULNERABLE_VERSIONS:
                key = pkg_name if pkg_name in VULNERABLE_VERSIONS else base_name
                for min_v, max_v, cve in VULNERABLE_VERSIONS[key]:
                    findings.append(ScaFinding(
                        id=self._fid(),
                        vector="known_vulnerable_version",
                        severity="critical",
                        title=f"{cve}: Vulnerable version of {pkg_name}",
                        description=(
                            f"Package '{pkg_name}' at version '{version_spec}' may "
                            f"fall within the vulnerable range {min_v}-{max_v} "
                            f"for {cve}. Run 'npm audit' to confirm and upgrade."
                        ),
                        source_file=str(path),
                        evidence={"package": pkg_name, "version": version_spec, "cve": cve},
                        remediation=f"npm update {pkg_name}  # Upgrade beyond {max_v}",
                        cmmc_controls=["3.14.2", "3.14.1"],
                    ))

        return findings

    def _check_python_manifest(self, path: Path) -> list[ScaFinding]:
        findings = []
        try:
            content = path.read_text()
        except Exception:
            return findings

        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            pkg_name = re.split(r"[>=<!\[;@]", line)[0].strip().lower()
            if pkg_name in KNOWN_MALICIOUS_PACKAGES:
                findings.append(ScaFinding(
                    id=self._fid(),
                    vector="known_malicious_package",
                    severity="critical",
                    title=f"Known-malicious MCP package: {pkg_name}",
                    description=(
                        f"Python package '{pkg_name}' in {path} is on the "
                        f"known-malicious list."
                    ),
                    source_file=str(path),
                    evidence={"package": pkg_name},
                    remediation=f"Remove '{pkg_name}' from {path} and pip uninstall it.",
                    cmmc_controls=["3.14.2", "3.14.1"],
                ))
        return findings

    # ------------------------------------------------------------------
    # 2. MCP config analysis (tool permissions, inline creds)
    # ------------------------------------------------------------------

    async def _scan_mcp_configs(self) -> list[ScaFinding]:
        findings = []
        config_files = [
            p for p in self.scan_paths
            if "mcp" in p.lower() or "claude" in p.lower()
        ]

        for path_str in config_files:
            path = Path(path_str)
            if not path.exists():
                continue
            try:
                content = path.read_text(errors="replace")
            except Exception:
                continue

            # Inline credentials in server command arguments
            if INLINE_CRED_RE.search(content):
                findings.append(ScaFinding(
                    id=self._fid(),
                    vector="inline_credential",
                    severity="critical",
                    title=f"Inline credential in MCP config: {path_str}",
                    description=(
                        f"MCP config '{path_str}' contains what appears to be an "
                        f"inline credential (API key, password, or secret) in a "
                        f"server command argument. Credentials in config files are "
                        f"at high risk of exfiltration by compromised MCP servers."
                    ),
                    source_file=path_str,
                    evidence={"file": path_str},
                    remediation=(
                        "Move credentials to environment variables or a secrets manager. "
                        "Reference them as $ENV_VAR_NAME in command args."
                    ),
                    cmmc_controls=["3.13.10", "3.5.3"],
                ))

            # Try to parse JSON and check tool descriptions for broad permissions
            try:
                config = json.loads(content)
                self._check_tool_permissions(config, path_str, findings)
            except json.JSONDecodeError:
                pass

        return findings

    def _check_tool_permissions(
        self, config: Any, source: str, findings: list[ScaFinding]
    ) -> None:
        """Recursively walk config looking for broad permission language in tool descriptions."""
        if isinstance(config, dict):
            description = str(config.get("description", ""))
            name = str(config.get("name", ""))
            if BROAD_PERMISSION_RE.search(description):
                findings.append(ScaFinding(
                    id=self._fid(),
                    vector="broad_tool_permissions",
                    severity="high",
                    title=f"Overly broad tool permissions: {name or 'unnamed tool'}",
                    description=(
                        f"Tool '{name}' in {source} has a description containing "
                        f"broad permission language. Tool descriptions are sent "
                        f"directly to the LLM and can be used for tool poisoning "
                        f"attacks (OWASP Agentic #2)."
                    ),
                    source_file=source,
                    evidence={"tool_name": name, "description_snippet": description[:200]},
                    remediation=(
                        "Narrow tool permissions to the minimum required. "
                        "Avoid natural language that implies unrestricted access."
                    ),
                    cmmc_controls=["3.1.1", "3.14.2"],
                ))
            for v in config.values():
                self._check_tool_permissions(v, source, findings)
        elif isinstance(config, list):
            for item in config:
                self._check_tool_permissions(item, source, findings)

    # ------------------------------------------------------------------
    # 3. Build config analysis (smithery.yaml path traversal)
    # ------------------------------------------------------------------

    async def _scan_build_configs(self) -> list[ScaFinding]:
        findings = []
        build_files = [p for p in self.scan_paths if "smithery" in p or "build" in p]

        for path_str in build_files:
            path = Path(path_str)
            if not path.exists():
                continue
            try:
                content = path.read_text(errors="replace")
            except Exception:
                continue

            for lineno, line in enumerate(content.splitlines(), start=1):
                if PATH_TRAVERSAL_RE.search(line):
                    findings.append(ScaFinding(
                        id=self._fid(),
                        vector="build_path_traversal",
                        severity="critical",
                        title=f"Path traversal pattern in build config: {path_str}:{lineno}",
                        description=(
                            f"Build config '{path_str}' line {lineno} contains a "
                            f"path traversal pattern. This matches the Smithery "
                            f"CVE where smithery.yaml allowed arbitrary file reads "
                            f"on the build host during MCP server compilation."
                        ),
                        source_file=path_str,
                        evidence={"file": path_str, "line": lineno,
                                  "content_snippet": line.strip()[:200]},
                        remediation=(
                            "Remove all path traversal patterns from build configs. "
                            "Restrict build steps to the project directory. "
                            "Run builds in isolated containers."
                        ),
                        cmmc_controls=["3.14.2", "3.13.1"],
                    ))
                    break  # One finding per file for build configs

        return findings

    # ------------------------------------------------------------------
    # Persist findings + update trust registry
    # ------------------------------------------------------------------

    async def _persist(self, findings: list[ScaFinding]) -> None:
        try:
            from aiglos_core.audit import AuditLog
            from aiglos_core.types import SecurityEvent, EventType, Severity
            audit = AuditLog(self.audit_db)
            smap = {
                "critical": Severity.CRITICAL,
                "high": Severity.HIGH,
                "medium": Severity.MEDIUM,
            }
            for f in findings:
                audit.record_event(SecurityEvent(
                    session_id="aiglos-sca",
                    event_type=EventType.ANOMALY_DETECTED,
                    severity=smap.get(f.severity, Severity.HIGH),
                    title=f.title,
                    description=f.description,
                    details=f.evidence,
                    cmmc_controls=f.cmmc_controls,
                ))
        except Exception as e:
            logger.debug("sca_persist_failed", error=str(e))

    async def _update_trust_registry(self, findings: list[ScaFinding]) -> None:
        """Block malicious package server fingerprints in aiglos_trust.yaml."""
        critical = [f for f in findings
                    if f.vector in ("known_malicious_package", "build_path_traversal")
                    and f.severity == "critical"]
        if not critical:
            return

        try:
            import yaml
            trust_path = Path("aiglos_trust.yaml")
            trust = {}
            if trust_path.exists():
                trust = yaml.safe_load(trust_path.read_text()) or {}

            blocked = trust.setdefault("blocked_packages", [])
            for f in critical:
                pkg = f.evidence.get("package")
                if pkg and pkg not in blocked:
                    blocked.append(pkg)

            trust_path.write_text(yaml.dump(trust, default_flow_style=False))
            logger.info("sca_trust_registry_updated", added=len(critical))
        except Exception as e:
            logger.debug("sca_trust_update_failed", error=str(e))
