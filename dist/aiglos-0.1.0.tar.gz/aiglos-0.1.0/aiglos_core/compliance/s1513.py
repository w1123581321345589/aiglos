"""
T28: NDAA Section 1513 Compliance Module

Maps Aiglos capabilities to the AI/ML security framework mandated by
Section 1513 of the National Defense Authorization Act for FY2026.

What Section 1513 requires
--------------------------
The NDAA FY2026 directs DoD to develop and implement a framework for
cybersecurity and physical security of AI/ML technologies acquired by
the Pentagon, to be incorporated into DFARS and CMMC.

Per the statute, the framework will cover "covered AI/ML" defined as:
  - AI/ML acquired by DoD
  - All associated components: source code, model weights
  - Methods, algorithms, data, and software used to develop the AI/ML

The DoD status report to Congress is due June 16, 2026.
Phase 2 CMMC mandatory C3PAO assessments begin November 2026.

Six anticipated control domains (mapped from statute + NIST AI RMF)
-------------------------------------------------------------------
  Domain 1: Model Integrity
    Ensuring AI model weights, versions, and configurations are
    protected against unauthorized modification.

  Domain 2: Runtime Monitoring
    Continuous monitoring of AI/ML systems during operation for
    anomalies, adversarial inputs, and goal drift.

  Domain 3: Access Control
    Authentication and authorization for AI systems, including
    multi-agent trust and minimum-privilege tool access.

  Domain 4: Audit Trail
    Comprehensive, tamper-evident logging of AI-initiated actions
    suitable for forensic investigation.

  Domain 5: Anomaly Detection
    Detection of adversarial inputs, prompt injection, credential
    exfiltration, and behavioral drift.

  Domain 6: Incident Response
    Alerting, blocking, and recovery capabilities for AI security events.

Usage
-----
  from aiglos_core.compliance.s1513 import Section1513Mapper
  mapper = Section1513Mapper(audit_db="aiglos_audit.db")
  report = mapper.build_report()
  print(report.summary())
  print(report.to_json())

  # Extend existing CMMC PDF report:
  mapper.extend_pdf_report(pdf_path="compliance_report.pdf")
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

try:
    import structlog
    logger = structlog.get_logger("aiglos.s1513")
except ImportError:
    import logging
    logger = logging.getLogger("aiglos.s1513")


# ---------------------------------------------------------------------------
# Section 1513 control domain definitions
# ---------------------------------------------------------------------------

@dataclass
class S1513Control:
    """A single Section 1513 control with Aiglos implementation evidence."""
    control_id: str         # e.g. "S1513-2.1"
    domain: str             # One of the six domains
    domain_number: int
    requirement: str        # What the framework requires
    aiglos_module: str      # Which Aiglos task/module satisfies it
    aiglos_evidence: str    # What to look for in the audit DB
    status: str = "ACTIVE"  # ACTIVE | PARTIAL | PLANNED | NOT_APPLICABLE
    notes: str = ""
    cmmc_analogs: list = field(default_factory=list)  # Equivalent CMMC controls


SECTION_1513_CONTROLS: list[S1513Control] = [

    # Domain 1: Model Integrity
    S1513Control(
        control_id="S1513-1.1",
        domain="Model Integrity",
        domain_number=1,
        requirement=(
            "AI/ML model identity (name, version, weights hash) SHALL be "
            "captured and cryptographically bound to each operational session."
        ),
        aiglos_module="T7 — Agent Identity Attestation",
        aiglos_evidence=(
            "attestation.model_identity.model_id, model_version, "
            "system_prompt_hash present in every session attestation document"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.14.2", "3.13.8"],
    ),
    S1513Control(
        control_id="S1513-1.2",
        domain="Model Integrity",
        domain_number=1,
        requirement=(
            "Unauthorized modification of model configuration SHALL be "
            "detected and logged. System prompt changes between sessions "
            "SHALL generate an integrity alert."
        ),
        aiglos_module="T7 — Attestation + T6 — Goal Integrity Engine",
        aiglos_evidence=(
            "SYSTEM_PROMPT_CHANGED events in security_events; "
            "system_prompt_hash delta across sequential sessions"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.14.2", "3.14.6"],
    ),
    S1513Control(
        control_id="S1513-1.3",
        domain="Model Integrity",
        domain_number=1,
        requirement=(
            "Supply chain integrity for AI/ML tool dependencies SHALL be "
            "assessed prior to deployment and on each dependency update."
        ),
        aiglos_module="T26 — Supply Chain Scanner (SCA)",
        aiglos_evidence=(
            "SCA findings in security_events tagged session_id=aiglos-sca; "
            "aiglos_trust.yaml blocked_packages list"
        ),
        status="ACTIVE",
        notes="Closes Postmark/Smithery supply chain vectors. Runs on intel_refresh cycle.",
        cmmc_analogs=["3.14.1", "3.14.2"],
    ),

    # Domain 2: Runtime Monitoring
    S1513Control(
        control_id="S1513-2.1",
        domain="Runtime Monitoring",
        domain_number=2,
        requirement=(
            "AI/ML systems SHALL be continuously monitored during operation "
            "for adversarial inputs, goal drift, and anomalous behavior."
        ),
        aiglos_module="T23 — Autonomous Engine + T24 — Sampling Monitor",
        aiglos_evidence=(
            "Autonomous scan cycle every 5 minutes; "
            "ANOMALY_DETECTED events in security_events; "
            "aiglos_engine_state.json shows uptime and task history"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.14.2", "3.14.6", "3.14.7"],
    ),
    S1513Control(
        control_id="S1513-2.2",
        domain="Runtime Monitoring",
        domain_number=2,
        requirement=(
            "Authorized objectives for AI/ML systems SHALL be registered "
            "prior to deployment. Drift from authorized objectives SHALL "
            "generate a runtime alert."
        ),
        aiglos_module="T6 — Goal Integrity Engine",
        aiglos_evidence=(
            "goal_integrity_score per session; "
            "GOAL_DRIFT events when score drops below threshold; "
            "goal_hash stored at session attestation"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.14.2", "3.1.1"],
    ),
    S1513Control(
        control_id="S1513-2.3",
        domain="Runtime Monitoring",
        domain_number=2,
        requirement=(
            "MCP sampling channel SHALL be monitored for instruction injection, "
            "covert tool invocation, and anomalous resource consumption."
        ),
        aiglos_module="T24 — MCP Sampling Monitor",
        aiglos_evidence=(
            "sampling_monitor module in ThreatHunter.run_full_scan(); "
            "ANOMALY_DETECTED events with source=sampling_monitor"
        ),
        status="ACTIVE",
        notes=(
            "Addresses Unit 42 (Dec 2025) three-vector sampling attack. "
            "No other compliance framework has an explicit sampling control."
        ),
        cmmc_analogs=["3.14.2"],
    ),

    # Domain 3: Access Control
    S1513Control(
        control_id="S1513-3.1",
        domain="Access Control",
        domain_number=3,
        requirement=(
            "AI/ML systems SHALL operate under minimum-privilege access. "
            "Tool permissions SHALL be scoped to the minimum required for "
            "the authorized objective."
        ),
        aiglos_module="T5 — OPA Policy Engine + T26 — SCA (tool permission analysis)",
        aiglos_evidence=(
            "aiglos_policy.yaml rules with BLOCK actions on overprivileged tools; "
            "SCA broad_tool_permissions findings"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.1.1", "3.1.2", "3.1.3"],
    ),
    S1513Control(
        control_id="S1513-3.2",
        domain="Access Control",
        domain_number=3,
        requirement=(
            "OAuth and API credentials used by AI/ML systems SHALL be "
            "protected against exfiltration and unauthorized reuse. "
            "Confused deputy attacks SHALL be detected."
        ),
        aiglos_module="T25 — OAuth Confused Deputy Detector",
        aiglos_evidence=(
            "OAuthConfusedDeputy.scan() findings in security_events; "
            "CVE-2025-6514 pattern detection in config scanner"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.5.1", "3.5.2", "3.13.10"],
    ),
    S1513Control(
        control_id="S1513-3.3",
        domain="Access Control",
        domain_number=3,
        requirement=(
            "Multi-agent AI deployments SHALL implement cryptographic "
            "identity attestation. Trust relationships between agents "
            "SHALL be explicitly declared and verified."
        ),
        aiglos_module="T8 — Trust Fabric (multi-agent attestation)",
        aiglos_evidence=(
            "AGENT_ATTESTED events; trust_fabric.py cryptographic session tokens; "
            "trust registry for MCP server whitelisting"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.5.1", "3.5.3", "3.13.8"],
    ),

    # Domain 4: Audit Trail
    S1513Control(
        control_id="S1513-4.1",
        domain="Audit Trail",
        domain_number=4,
        requirement=(
            "All AI/ML system actions (tool calls, resource access, external "
            "API calls) SHALL be logged with sufficient detail for forensic "
            "reconstruction of any incident."
        ),
        aiglos_module="T3 — Audit Logging (SQLite WAL + structured events)",
        aiglos_evidence=(
            "tool_calls table: session_id, tool_name, arguments, result, timestamp; "
            "security_events table: all anomaly and policy events"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.3.1", "3.3.2"],
    ),
    S1513Control(
        control_id="S1513-4.2",
        domain="Audit Trail",
        domain_number=4,
        requirement=(
            "Audit records SHALL be cryptographically bound to prevent "
            "post-hoc tampering. Session records SHALL be signed by a "
            "verifiable key."
        ),
        aiglos_module="T7 — RSA-2048 signed attestation documents",
        aiglos_evidence=(
            "attestation.signature (RSA-2048); "
            "attestation.document_hash (SHA-256); "
            "event_manifest_hash over all session events"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.3.1", "3.13.8", "3.13.10"],
    ),
    S1513Control(
        control_id="S1513-4.3",
        domain="Audit Trail",
        domain_number=4,
        requirement=(
            "Compliance reports SHALL be generated on demand and SHALL "
            "map observed AI/ML system behavior to applicable NIST 800-171 "
            "and DoD AI/ML framework controls."
        ),
        aiglos_module="T18/T19 — CMMC PDF Reports + T28 — Section 1513 Mapper",
        aiglos_evidence=(
            "aiglos report --format pdf generates CMMC + §1513 readiness report; "
            "ComplianceReport.section_1513_readiness items"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.3.1", "3.3.2"],
    ),

    # Domain 5: Anomaly Detection
    S1513Control(
        control_id="S1513-5.1",
        domain="Anomaly Detection",
        domain_number=5,
        requirement=(
            "Prompt injection attacks against AI/ML systems SHALL be "
            "detected in real time. Detection SHALL cover direct injection, "
            "indirect injection via tool responses, and unicode steganography."
        ),
        aiglos_module="T4 — Proxy Injection Detection + T23 — Hunter injection module",
        aiglos_evidence=(
            "COMMAND_INJECTION, PATH_TRAVERSAL events from proxy; "
            "injection_hunt module findings in autonomous scan"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.14.2", "3.14.6"],
    ),
    S1513Control(
        control_id="S1513-5.2",
        domain="Anomaly Detection",
        domain_number=5,
        requirement=(
            "Credential and sensitive data exfiltration via AI/ML tool calls "
            "SHALL be detected and blocked in real time."
        ),
        aiglos_module="T4 — Credential Scanner (proxy layer)",
        aiglos_evidence=(
            "CREDENTIAL_DETECTED events; blocked_calls count in session security_posture; "
            "regex patterns: Anthropic keys, AWS keys, GitHub PATs, JWTs, Slack tokens"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.13.10", "3.5.3", "3.14.2"],
    ),
    S1513Control(
        control_id="S1513-5.3",
        domain="Anomaly Detection",
        domain_number=5,
        requirement=(
            "Behavioral baselines SHALL be established for AI/ML systems. "
            "Statistically significant deviations SHALL generate alerts."
        ),
        aiglos_module="T12/T13 — Behavioral Baseline + T23 — Trend Analysis",
        aiglos_evidence=(
            "anomaly_score per session; behavioral_trend hunt module; "
            "BEHAVIORAL_ANOMALY events when rolling mean exceeds threshold"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.14.6", "3.14.7"],
    ),
    S1513Control(
        control_id="S1513-5.4",
        domain="Anomaly Detection",
        domain_number=5,
        requirement=(
            "Red team / adversarial testing of AI/ML deployments SHALL be "
            "performed periodically to identify exploitable vulnerabilities "
            "before adversaries do."
        ),
        aiglos_module="T27 — Red Team Probe Mode",
        aiglos_evidence=(
            "aiglos probe generates ProbeReport with VULNERABLE/HARDENED verdicts; "
            "results persisted to audit DB tagged aiglos-probe-*"
        ),
        status="ACTIVE",
        notes=(
            "First compliance framework to mandate AI red teaming at the "
            "tool/MCP layer. No other product has this capability."
        ),
        cmmc_analogs=["3.14.2"],
    ),

    # Domain 6: Incident Response
    S1513Control(
        control_id="S1513-6.1",
        domain="Incident Response",
        domain_number=6,
        requirement=(
            "AI/ML security events SHALL be escalated to human operators "
            "within a defined time window. CRITICAL severity events SHALL "
            "trigger immediate notification."
        ),
        aiglos_module="T15 — Alert Dispatch (webhook/Slack/SIEM)",
        aiglos_evidence=(
            "AlertDispatcher fires on CRITICAL/HIGH severity events; "
            "webhook_url in proxy config; syslog integration"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.6.1", "3.6.2"],
    ),
    S1513Control(
        control_id="S1513-6.2",
        domain="Incident Response",
        domain_number=6,
        requirement=(
            "AI/ML systems involved in a security incident SHALL be "
            "suspendable without disrupting other system operations. "
            "Session termination SHALL be logged."
        ),
        aiglos_module="T23 — Autonomous Engine (SUSPENDED state) + proxy BLOCK action",
        aiglos_evidence=(
            "Engine state machine: RUNNING → SUSPENDED; "
            "POLICY_VIOLATION events with action=BLOCK; "
            "aiglos_engine_state.json state field"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.6.1", "3.1.1"],
    ),
    S1513Control(
        control_id="S1513-6.3",
        domain="Incident Response",
        domain_number=6,
        requirement=(
            "Post-incident forensic capability SHALL allow reconstruction "
            "of the full AI/ML action sequence leading to a security event, "
            "including all tool calls and model outputs."
        ),
        aiglos_module="T3 — Audit Log + T18 — Compliance Report",
        aiglos_evidence=(
            "session_id linkage across tool_calls, attestation, and security_events; "
            "aiglos report --session SESSION_ID generates full session timeline"
        ),
        status="ACTIVE",
        cmmc_analogs=["3.3.1", "3.3.2", "3.6.2"],
    ),
]

# Group controls by domain for reporting
DOMAINS_BY_NUMBER = {
    1: "Model Integrity",
    2: "Runtime Monitoring",
    3: "Access Control",
    4: "Audit Trail",
    5: "Anomaly Detection",
    6: "Incident Response",
}


# ---------------------------------------------------------------------------
# Section 1513 Mapper
# ---------------------------------------------------------------------------

@dataclass
class S1513Score:
    """Readiness score for one Section 1513 domain."""
    domain: str
    domain_number: int
    controls_total: int
    controls_active: int
    controls_partial: int
    controls_planned: int
    score_pct: float
    status: str     # "READY" | "PARTIAL" | "GAP"

    def status_icon(self) -> str:
        return {"READY": "✅", "PARTIAL": "🟡", "GAP": "🔴"}.get(self.status, "⚪")


@dataclass
class S1513Report:
    """Full Section 1513 readiness report."""
    generated_at: float
    controls_total: int
    controls_active: int
    controls_partial: int
    controls_planned: int
    overall_score_pct: float
    domain_scores: list[S1513Score]
    controls: list[S1513Control]
    notes: list[str] = field(default_factory=list)

    def overall_status(self) -> str:
        if self.overall_score_pct >= 90:
            return "READY"
        elif self.overall_score_pct >= 60:
            return "PARTIAL"
        return "GAP"

    def summary(self) -> str:
        lines = [
            f"NDAA FY2026 Section 1513 Readiness Report",
            f"Generated: {time.strftime('%Y-%m-%d %H:%M UTC', time.gmtime(self.generated_at))}",
            f"",
            f"Overall Score: {self.overall_score_pct:.0f}%  [{self.overall_status()}]",
            f"Controls Active: {self.controls_active}/{self.controls_total}",
            f"",
        ]
        for ds in self.domain_scores:
            lines.append(
                f"  {ds.status_icon()} Domain {ds.domain_number}: {ds.domain:<25} "
                f"{ds.score_pct:.0f}% ({ds.controls_active}/{ds.controls_total} active)"
            )
        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {
            "generated_at": self.generated_at,
            "overall_score_pct": self.overall_score_pct,
            "overall_status": self.overall_status(),
            "controls_total": self.controls_total,
            "controls_active": self.controls_active,
            "domain_scores": [
                {
                    "domain": ds.domain,
                    "domain_number": ds.domain_number,
                    "score_pct": ds.score_pct,
                    "status": ds.status,
                    "controls_active": ds.controls_active,
                    "controls_total": ds.controls_total,
                }
                for ds in self.domain_scores
            ],
            "controls": [
                {
                    "control_id": c.control_id,
                    "domain": c.domain,
                    "requirement": c.requirement,
                    "aiglos_module": c.aiglos_module,
                    "aiglos_evidence": c.aiglos_evidence,
                    "status": c.status,
                    "cmmc_analogs": c.cmmc_analogs,
                    "notes": c.notes,
                }
                for c in self.controls
            ],
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)


class Section1513Mapper:
    """
    Maps Aiglos SecurityEvents and session data to NDAA FY2026 §1513 controls.

    Generates a readiness report that can be:
      - Printed to terminal (summary())
      - Exported to JSON
      - Appended to the existing CMMC PDF report (extend_pdf_report())
    """

    def __init__(self, audit_db: str = "aiglos_audit.db"):
        self.audit_db = audit_db

    def build_report(self, adjust_from_db: bool = True) -> S1513Report:
        """
        Build Section 1513 readiness report.

        If adjust_from_db=True, cross-references the live audit DB to downgrade
        controls where no supporting evidence is found.
        """
        controls = list(SECTION_1513_CONTROLS)

        if adjust_from_db:
            self._adjust_from_live_evidence(controls)

        # Score by domain
        domain_scores = []
        for dn, domain_name in DOMAINS_BY_NUMBER.items():
            domain_controls = [c for c in controls if c.domain_number == dn]
            active = sum(1 for c in domain_controls if c.status == "ACTIVE")
            partial = sum(1 for c in domain_controls if c.status == "PARTIAL")
            planned = sum(1 for c in domain_controls if c.status == "PLANNED")
            total = len(domain_controls)
            score = (active + partial * 0.5) / total * 100 if total else 0

            if score >= 90:
                status = "READY"
            elif score >= 50:
                status = "PARTIAL"
            else:
                status = "GAP"

            domain_scores.append(S1513Score(
                domain=domain_name,
                domain_number=dn,
                controls_total=total,
                controls_active=active,
                controls_partial=partial,
                controls_planned=planned,
                score_pct=round(score, 1),
                status=status,
            ))

        all_active = sum(1 for c in controls if c.status == "ACTIVE")
        all_partial = sum(1 for c in controls if c.status == "PARTIAL")
        all_planned = sum(1 for c in controls if c.status == "PLANNED")
        total = len(controls)
        overall_score = (all_active + all_partial * 0.5) / total * 100

        return S1513Report(
            generated_at=time.time(),
            controls_total=total,
            controls_active=all_active,
            controls_partial=all_partial,
            controls_planned=all_planned,
            overall_score_pct=round(overall_score, 1),
            domain_scores=domain_scores,
            controls=controls,
            notes=[
                "Framework is based on NDAA FY2026 §1513 statutory language and "
                "anticipated DoD AI/ML security control domains per NIST AI RMF.",
                "Score will be updated when DoD publishes the final framework "
                "(Congressional status report due June 16, 2026).",
                "CMMC analog mappings reference NIST SP 800-171 Rev 2 control IDs.",
            ],
        )

    def _adjust_from_live_evidence(self, controls: list[S1513Control]) -> None:
        """
        Check whether audit DB has the evidence expected for each control.
        Downgrade status if no evidence found.
        """
        try:
            from aiglos_core.audit import AuditLog
            audit = AuditLog(self.audit_db)
            events = audit.get_recent_events(limit=500)
            event_types = {ev.get("event_type", "") for ev in events}
            session_count = len({ev.get("session_id", "") for ev in events
                                  if ev.get("session_id", "").startswith("sess-") or
                                  len(ev.get("session_id", "")) > 8})

            # If no sessions exist yet, mark runtime controls as PLANNED
            if session_count == 0:
                runtime_controls = {
                    "S1513-2.1", "S1513-2.2", "S1513-2.3",
                    "S1513-5.1", "S1513-5.2", "S1513-5.3",
                }
                for c in controls:
                    if c.control_id in runtime_controls and c.status == "ACTIVE":
                        c.status = "PARTIAL"
                        c.notes += " [No sessions in DB — deploy proxy to activate]"

        except Exception as e:
            logger.debug("s1513_db_adjust_failed", error=str(e))

    def enrich_event(self, event_type: str, details: dict) -> list[str]:
        """
        Given an event type and details, return the Section 1513 control IDs
        that this event provides evidence for.
        """
        mappings = {
            "AGENT_ATTESTED": ["S1513-1.1", "S1513-3.3", "S1513-4.2"],
            "GOAL_DRIFT": ["S1513-2.2", "S1513-5.3"],
            "COMMAND_INJECTION": ["S1513-5.1"],
            "PATH_TRAVERSAL": ["S1513-3.1", "S1513-5.1"],
            "CREDENTIAL_DETECTED": ["S1513-5.2"],
            "POLICY_VIOLATION": ["S1513-3.1", "S1513-6.2"],
            "ANOMALY_DETECTED": ["S1513-2.1", "S1513-5.3"],
            "BEHAVIORAL_ANOMALY": ["S1513-5.3"],
            "ALERT_DISPATCHED": ["S1513-6.1"],
        }
        event_upper = event_type.upper()
        for key, controls in mappings.items():
            if key in event_upper:
                return controls
        return []

    def extend_pdf_report(self, pdf_path: str) -> bool:
        """
        Extend an existing Aiglos compliance PDF with a Section 1513 section.
        Returns True if successful.
        """
        try:
            report = self.build_report()
            path = Path(pdf_path)
            if not path.exists():
                logger.warning("s1513_pdf_not_found", path=pdf_path)
                return False

            # The PDF is generated by aiglos_core.compliance.report_pdf or pdf_report
            # We write the Section 1513 data to a sidecar JSON that the PDF generator
            # picks up on next run.
            sidecar = path.with_suffix(".s1513.json")
            sidecar.write_text(report.to_json())
            logger.info("s1513_sidecar_written", path=str(sidecar))
            return True
        except Exception as e:
            logger.error("s1513_pdf_extend_failed", error=str(e))
            return False
