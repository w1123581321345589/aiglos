# aiglos scan-skill launch copy

## Context

Grok's answer to "how do I check a ClawHub skill for malicious code before downloading":

> Open in VS Code, look for os/exec calls, network requests to unknown domains.
> Upload to VirusTotal.com. Test in a sandbox (VM or Docker) with no sensitive data.
> High-download skills from verified creators are usually safer, but always verify yourself.

This is the comparison. Every version of our copy is a response to this.

---

## Tweets

### Version 1 — The straight contrast (most shareable)

Someone asked Grok how to check a ClawHub skill for malicious code.

Grok said: open it in VS Code. Look for suspicious calls. Upload to VirusTotal. Test in Docker.

We built:

```
aiglos scan-skill solana-wallet-tracker
```

8 signals. 2 seconds.

820 of 10,700 ClawHub skills were malicious. Don't read the source code.
aiglos.dev/scan

---

### Version 2 — The technical credibility version

VirusTotal doesn't know what an AI agent permission scope is.

It can't detect a README that says "paste this in your terminal as a required setup step."
It can't score typosquatting distance from legitimate ClawHub packages.
It can't flag a publisher account that distributed GhostClaw last week.

```
pip install aiglos
aiglos scan-skill <skill-name>
```

T26 + T30. Free. Works on ClawHub, SkillsMP, npm, PyPI.
aiglos.dev/scan

---

### Version 3 — The snarky version

Grok's instructions for checking a ClawHub skill for malware:
- Open in VS Code
- Look for sketchy code
- Upload to VirusTotal
- Test in a sandbox

Skill: solana-wallet-tracker
Lines of code: 847
Obfuscated base64 blobs: 3
Minutes you'd spend reviewing: 20+

Or:

```
aiglos scan-skill solana-wallet-tracker
```

[CRITICAL — 78/100. DO NOT INSTALL.]

2 seconds.

---

### Version 4 — The short punchy one (thread opener or standalone)

Grok says to check ClawHub skills for malware by opening them in VS Code and looking for suspicious calls.

We automated that.

```
aiglos scan-skill <skill-name>
```

Free. Works on any skill from ClawHub, SkillsMP, or npm.
820 confirmed malicious skills and counting.
aiglos.dev/scan

---

### Version 5 — The stat-first version (for LinkedIn / longer format)

820 of 10,700 skills on ClawHub have been confirmed malicious.

The advice floating around: open the file in VS Code, search for os.exec calls, upload to VirusTotal.

The problem: the GhostClaw attack used obfuscated payloads, a fake Keychain prompt, and social engineering in the README. None of that shows up in a grep or a VirusTotal scan.

We built a scanner that catches what manual review misses:
- Typosquatting detection (edit distance from legitimate packages)
- Social engineering language in READMEs
- Suspicious permission scopes in the manifest
- Known-malicious publisher fingerprints
- Community abuse flags from ClawHub, GitHub Issues, and Discord

```
pip install aiglos
aiglos scan-skill solana-wallet-tracker
```

Or scan without installing: aiglos.dev/scan

---

## Tweet 6 — Nemotron Super / context window threat

Nvidia just dropped Nemotron Super. 1M context. 120B params. Open weights.

An agent running this locally can load your entire codebase into one context window, map every secret and auth flow, and exfil it all in a single clean-looking tool call.

Per-call scanners see nothing. The reconnaissance was invisible.

Aiglos 0.2 adds campaign-mode session analysis for exactly this vector.

`pip install aiglos`

---

## HN comment (Agent Safehouse thread or any OpenClaw security thread)

Someone asked Grok how to check a ClawHub skill for malicious code before downloading. The answer was: open it in VS Code, look for suspicious calls, upload to VirusTotal, test in Docker.

That's reasonable advice for traditional packages. It misses most of what made the OpenClaw attacks work.

The GhostClaw npm package passed a source review. The payload was AES-256-GCM encrypted and downloaded at runtime. The malicious ClawHub skills had professional documentation. The attack surface was the README's social engineering language and the permission scope -- neither of which VirusTotal scores.

We spent the last few weeks building T26 (supply chain scanner) and T30 (registry monitor) for exactly this. ClawHub and SkillsMP are now monitored registries with 8 risk signals per package: typosquatting distance, social engineering language in README, known-malicious publisher accounts, version gap anomalies, new-publish anomalies, dependency confusion patterns, suspicious permission scopes, and community flags.

There's a free CLI if you want to use it without touching the runtime SDK:

```
pip install aiglos
aiglos scan-skill solana-wallet-tracker
```

Or the browser version at aiglos.dev/scan if you don't want to install anything.

Exit code is non-zero on HIGH/CRITICAL so it drops into CI: `aiglos scan-skill my-skill || exit 1`

Happy to open-source just the scanner component if that's more useful for the community than the full package.

---

## PR pitch (one paragraph for security journalists who covered ClawHub attacks)

Hi [name] -- you wrote about [ClawHub malicious skills / GhostClaw / OpenClaw security] last month. We built a free scanner for exactly the attack pattern you covered: paste any ClawHub skill name into aiglos.dev/scan and get an 8-signal risk score in 2 seconds. The signal set covers what manual review and VirusTotal miss -- social engineering language in READMEs, permission scope anomalies, typosquatting from legitimate packages, and publisher fingerprints from the post-GhostClaw blocklist. We also have a module-by-module mapping of every OpenClaw CVE to the Aiglos rule that catches it if you want a technical breakdown. Happy to send over.
