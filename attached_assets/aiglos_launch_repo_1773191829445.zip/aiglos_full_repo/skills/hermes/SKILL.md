# Aiglos — Runtime Security for hermes-agent

**Category:** Security  
**Version:** 0.1.0  
**Author:** Aiglos (aiglos.io)  
**License:** MIT (detection engine) / Proprietary (attestation)  
**Install:** `pip install aiglos`

---

## What this skill does

Aiglos is a runtime security monitor for hermes-agent. It intercepts every tool
call before execution, flags or blocks threats in the T1-T36 class library, and
produces a cryptographically signed session artifact at the end of each heartbeat
cycle.

Hermes-specific surfaces covered:

- Terminal tool abuse (shell injection, sudo escalation, credential file reads)
- Memory poisoning (MEMORY.md / USER.md writes with injection payloads)
- SOUL.md / AGENTS.md / SKILL.md prompt injection
- Cron and HEARTBEAT.md tampering
- SSRF via web_fetch and web_extract
- Skill install supply chain without provenance
- Sub-agent delegation audit (delegate_task)
- Batch runner trajectory signing for RL training data integrity
- Fleet coordination abuse via send_message

One import. No config required beyond policy selection.

**NDAA §1513 compliant** when `policy="federal"`.

---

## Why this exists

Hermes-agent's own security documentation describes the exec approval system in
`tools/approval.py` as the primary safeguard against dangerous commands. That
system catches a well-defined list of known-dangerous patterns at install time
and prompts for user approval. Aiglos adds the runtime layer that exec-approvals
does not provide:

- **Continuous monitoring**: every tool call, not just the ones matching a
  pre-defined allowlist
- **Memory and context file integrity**: detects injection payloads in MEMORY.md,
  USER.md, SOUL.md, and AGENTS.md writes
- **Signed audit trail**: HMAC-SHA256 (free) or RSA-2048 (Pro) artifact after
  every heartbeat cycle, suitable for NDAA §1513 submission
- **Batch runner provenance**: sign trajectories before they enter RL training
  to ensure the model learns from clean tool calls, not compromised ones

The exec approval system and Aiglos are complementary. Approval controls which
commands require human sign-off. Aiglos monitors everything that executes within
that policy and signs the record.

---

## Installation

```bash
pip install aiglos
```

Add to your `~/.hermes/SOUL.md` or agent system prompt:

```
## Security Policy
Always import aiglos_hermes at the start of every session.
Before executing any tool call, pass it through the Aiglos guard.
If Aiglos blocks a call, log the event and do not retry without explicit
human approval. Never attempt to write directly to MEMORY.md, cron/, or
SOUL.md without passing the proposed content through the Aiglos check first.
```

---

## Usage

### One-liner attach (recommended)

```python
import aiglos_hermes

# Attach at agent startup
aiglos_hermes.attach(
    agent_name = "hermes",
    policy     = "enterprise",   # enterprise | federal | strict | permissive
    log_path   = "~/.hermes/logs/aiglos.log",
)

# Before every tool call
result = aiglos_hermes.check("terminal", {"command": cmd})
if result.blocked:
    raise RuntimeError(f"Aiglos blocked: {result.reason}")

# At each HEARTBEAT.md wake cycle
aiglos_hermes.on_heartbeat()

# At session end
artifact = aiglos_hermes.close()
print(artifact.summary())
artifact.write("~/.hermes/logs/session.aiglos")
```

### Batch runner integration (trajectory signing)

```python
from aiglos_hermes import HermesGuard

guard = HermesGuard(agent_name="batch", policy="strict")

# ... run your batch_runner trajectory ...

# Sign the trajectory before saving
trajectory = guard.sign_trajectory(trajectory_dict)
# trajectory["_aiglos"] now contains artifact_id, signature, blocked_calls
```

### Multi-agent orchestration

```python
from aiglos_hermes import HermesGuard

# Main agent
hermes = HermesGuard(
    agent_name      = "hermes",
    policy          = "enterprise",
    heartbeat_aware = True,
)

# Sub-agents from delegate_task
ada = hermes.spawn_sub_guard("Ada")

# Each guard checks its own tool calls
r1 = hermes.before_tool_call("web_fetch", {"url": "https://example.com"})
r2 = ada.before_tool_call("read_file", {"path": "~/.hermes/.env"})

# Heartbeat
hermes.on_heartbeat()

# Close rolls up sub-agent stats
artifact = hermes.close_session()
artifact.write("~/.hermes/logs/session.aiglos")
```

---

## Threat classes enforced

| Aiglos ID | Name | Hermes surface | Severity |
|-----------|------|----------------|----------|
| T07 | SHELL_INJECT | terminal tool (curl\|bash, rm -rf, fork bomb) | CRITICAL |
| T13 | SSRF | web_fetch/web_extract to 169.254.x / localhost / RFC-1918 | CRITICAL |
| T30 | SUPPLY_CHAIN | skills_install --force, eval() in skill code | CRITICAL |
| T34 | HEARTBEAT_TAMPER | writes to cron/ or HEARTBEAT.md | CRITICAL |
| T05 | PROMPT_INJECT | SOUL.md / AGENTS.md / SKILL.md payload writes | HIGH |
| T08 | PRIV_ESC | sudo in terminal commands | HIGH |
| T19 | CRED_ACCESS | reads of ~/.hermes/.env, auth.json | HIGH |
| T23 | SUBAGENT_SPAWN | delegate_task calls | HIGH |
| T36 | MEMORY_POISON | MEMORY.md / USER.md injection payloads | HIGH |
| T01 | EXFIL | outbound POST via web_fetch | HIGH |
| T28 | FLEET_COORD | send_message to new recipients | MEDIUM |

Full T1-T36 library: https://github.com/aiglos/aiglos-cves

---

## Policy modes

| Policy | Block threshold | Warn threshold | Use case |
|--------|----------------|----------------|----------|
| `permissive` | 0.90 | 0.70 | Development / local testing |
| `enterprise` | 0.75 | 0.50 | Commercial agent deployments |
| `strict` | 0.50 | 0.30 | High-value data environments |
| `federal` | 0.40 | 0.20 | DoD / NDAA §1513 compliance |

---

## Session artifact

Every session produces a signed JSON artifact:

```json
{
  "schema":           "aiglos-hermes/v1",
  "artifact_id":      "a3f9...",
  "agent_name":       "hermes",
  "session_id":       "abc123",
  "policy":           "enterprise",
  "started_at":       "2026-03-10T09:14:22Z",
  "closed_at":        "2026-03-10T09:47:11Z",
  "heartbeat_n":      3,
  "total_calls":      247,
  "blocked_calls":    4,
  "warned_calls":     2,
  "ndaa_1513_ready":  false,
  "threats":          [...],
  "sub_agents":       ["Ada"],
  "signature":        "sha256:a1b2c3..."
}
```

Pro and Enterprise subscribers receive RSA-2048 signed artifacts.
Required for NDAA §1513 submission.

---

## Pricing

| Tier | Price | Attestation | Compliance |
|------|-------|-------------|------------|
| Free | $0 | HMAC-SHA256 | Local log only |
| Pro | $49/mo | RSA-2048 signed | §1513 PDF report |
| Enterprise | Custom | RSA-2048 + air-gap | CMMC + FedRAMP |

Start free: `pip install aiglos`  
Pro trial (no card): aiglos.io  
Defense brief: will@aiglos.io

---

## Demo

```bash
python aiglos_hermes.py demo
```

Output:

```
aiglos-hermes v0.1.0 -- hermes-agent runtime security middleware

Running demo scan against synthetic hermes tool call sequence...

  ✓ ALLOW  read_file
  ✓ ALLOW  web_fetch
  ✓ ALLOW  terminal
  ✗ BLOCK  terminal                                 [T07]
  ✗ BLOCK  write_file                               [T36]
  ✗ BLOCK  web_fetch                                [T13]
  ✗ BLOCK  read_file                                [T19]
  ✗ BLOCK  write_file                               [T34]
  ⚠ WARN   delegate_task                            [T23]
  ✗ BLOCK  skills_install                           [T30]
  ✗ BLOCK  write_file                               [T05]
  ✓ ALLOW  terminal
  ⚠ WARN   send_message                             [T28]

Aiglos Hermes Artifact  v0.1.0
  Agent       : hermes
  Policy      : enterprise
  Heartbeat # : 1
  Sub-agents  : Ada
  Tool calls  : 15 total / 8 blocked / 2 warned
  Threats     : 8
  Signature   : sha256:d42140295...
  NDAA §1513  : N/A (use policy=federal)
```

---

## Links

- Website: https://aiglos.io
- Docs: https://docs.aiglos.io
- GitHub: https://github.com/aiglos
- CVE library: https://github.com/aiglos/aiglos-cves
- hermes-agent: https://github.com/NousResearch/hermes-agent
- Contact: will@aiglos.io
