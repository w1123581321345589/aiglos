# Aiglos — Runtime Security for OpenClaw Agents

**Category:** Security  
**Version:** 0.1.0  
**Author:** Aiglos (aiglos.io)  
**License:** MIT (detection engine) / Proprietary (attestation)  
**Install:** `pip install aiglos`

---

## What this skill does

OpenClaw's own Threat Model Atlas rates six threats as Critical or High residual
risk with no current runtime mitigation. Aiglos closes all six at the tool call
layer — before execution, not after.

- Blocks shell injection, credential access, SSRF, and data exfiltration
- Detects OpenClaw-specific threats: config tampering, undeclared sub-agent
  spawning, memory index manipulation, skill-context credential harvesting
- Writes a cryptographically signed session artifact after every heartbeat cycle
- One import. No config required beyond policy selection.

**NDAA §1513 compliant** when `policy="federal"`.

---

## Why this exists: gaps in OpenClaw's own threat model

OpenClaw publishes a threat model at `docs.openclaw.ai/security/THREAT-MODEL-ATLAS`
(MITRE ATLAS v1.0, updated 2026-02-04). It explicitly rates the following as
unmitigated or partially mitigated at runtime:

| OpenClaw Threat ID | Description | Their residual risk | Aiglos rule |
|-------------------|-------------|---------------------|-------------|
| T-EXEC-001 | Direct prompt injection | Critical — detection only, no blocking | T05 PROMPT_INJECT |
| T-EXEC-004 | Exec approval bypass | High — no command sanitization | T07 SHELL_INJECT |
| T-EXFIL-001 | Data theft via web_fetch | High — external URLs permitted | T01 EXFIL |
| T-EXFIL-003 | Credential harvesting from skill context | Critical — no mitigation | T19 CRED_ACCESS |
| T-IMPACT-001 | Unauthorized command execution | Critical — host exec without sandbox | T07 + T08 |
| T-PERSIST-003 | Agent configuration tampering | Medium — file permissions only | T34 + T36 |

Their recommended fix for all six: "planned improvements." Aiglos ships the fix now,
as a runtime intercept on every tool call.

---

## Installation

```bash
pip install aiglos
```

Add to your agent's system prompt (via `openclaw.json` agent config or the
"What to Tell Your AI" prompt section):

```
## Security Policy
You must always import aiglos_openclaw at the start of every session.
Before executing any tool call, pass it through the Aiglos guard.
If Aiglos blocks a call, log the event and do not retry without explicit
human approval. Never attempt to modify gateway config, agent config files,
or session memory indexes directly.
```

---

## Usage

### One-liner attach (recommended)

```python
import aiglos_openclaw

# Attach to the active session at agent startup
aiglos_openclaw.attach(
    agent_name = "Doraemon",
    policy     = "enterprise",   # enterprise | federal | strict | permissive
    log_path   = "./aiglos.log",
)

# Before every tool call:
result = aiglos_openclaw.check("shell.execute", {"command": cmd})
if result.blocked:
    print(f"Blocked: {result.reason}  [{result.threat_class}]")
    # Do not execute the call

# At session end:
artifact = aiglos_openclaw.close()
print(artifact.summary())
```

### Full control (multi-agent orchestration)

```python
from aiglos_openclaw import OpenClawGuard

# Main agent
doraemon = OpenClawGuard(
    agent_name      = "Doraemon",
    policy          = "enterprise",
    log_path        = "./aiglos.log",
    heartbeat_aware = True,
)

# Sub-agents inherit policy and contribute to parent artifact
ada   = doraemon.spawn_sub_guard("Ada")
prism = doraemon.spawn_sub_guard("Prism")

# Heartbeat integration — call at each HEARTBEAT.md wake cycle
doraemon.on_heartbeat()

# Check calls for each agent independently
r1 = doraemon.before_tool_call("http.get", {"url": "https://youtube.com/..."})
r2 = ada.before_tool_call("filesystem.write_file", {"path": "./queue.json"})
r3 = prism.before_tool_call("shell.execute", {"command": "ffmpeg -i input.mp4 ..."})

# Close and get artifact
artifact = doraemon.close_session()
artifact.write("./session.aiglos")
```

---

## OpenClaw config integration

Add Aiglos to your agent system prompt in `openclaw.json`:

```json
{
  "agents": {
    "list": [
      {
        "id": "main",
        "systemPrompt": "## Security Policy\nAlways load aiglos_openclaw on startup. Pass every tool call through the Aiglos guard before execution. Never retry a blocked call without human approval."
      }
    ]
  }
}
```

Or use `tools.deny` in `openclaw.json` to restrict high-risk tools while
Aiglos monitors the remainder:

```json
{
  "tools": {
    "deny": ["gateway", "cron", "sessions_spawn", "sessions_send"]
  }
}
```

Aiglos is **complementary** to OpenClaw's built-in tool policy — policy controls
access scope, Aiglos watches what actually executes within that scope and signs
the record.

---

## Heartbeat integration

OpenClaw wakes agents on a timer defined in HEARTBEAT.md. Call
`guard.on_heartbeat()` at the top of each cycle. Aiglos tracks cycles
as distinct sub-sessions, so each autonomous run has an independent
audit record. This is what NDAA §1513 attestation requires.

```python
# In your heartbeat handler
while True:
    guard.on_heartbeat()
    run_agent_cycle()
    time.sleep(HEARTBEAT_INTERVAL)
```

---

## Threat classes enforced

Aiglos T-numbers map directly to OpenClaw's MITRE ATLAS threat IDs:

| Aiglos ID | Name | Closes OpenClaw threat | Severity |
|-----------|------|------------------------|----------|
| T34 | HEARTBEAT_TAMPER | T-PERSIST-003 (config tamper) | CRITICAL |
| T36 | MEMORY_POISON | T-PERSIST-003 (config tamper) | HIGH |
| T30 | SUPPLY_CHAIN | T-PERSIST-001 (skill install) | CRITICAL |
| T23 | SUBAGENT_SPAWN | T-PERSIST-003 (agent config) | HIGH |
| T07 | SHELL_INJECT | T-EXEC-004, T-IMPACT-001 | CRITICAL |
| T13 | SSRF | T-EXFIL-001 (web_fetch theft) | CRITICAL |
| T08 | PRIV_ESC | T-IMPACT-001 (cmd execution) | HIGH |
| T19 | CRED_ACCESS | T-EXFIL-003 (credential harvest) | HIGH |
| T01 | EXFIL | T-EXFIL-001 (data theft) | HIGH |
| T05 | PROMPT_INJECT | T-EXEC-001 (direct injection) | MEDIUM |
| T28 | FLEET_COORD | T-EXFIL-002 (unauth messaging) | MEDIUM |

Full T1-T36 library and CVE database: https://github.com/aiglos/aiglos-cves

---

## Policy modes

| Policy | Block threshold | Warn threshold | Use case |
|--------|----------------|----------------|----------|
| `permissive` | 0.90 | 0.70 | Development / local testing |
| `enterprise` | 0.75 | 0.50 | Commercial agent fleets |
| `strict` | 0.50 | 0.30 | High-value data environments |
| `federal` | 0.40 | 0.20 | DoD / NDAA §1513 compliance |

---

## Session artifact

Every session produces a signed JSON artifact:

```json
{
  "schema":         "aiglos-openclaw/v1",
  "artifact_id":    "a3f9...",
  "agent_name":     "Doraemon",
  "session_id":     "abc123",
  "policy":         "enterprise",
  "started_at":     "2026-03-10T09:14:22Z",
  "closed_at":      "2026-03-10T09:47:11Z",
  "heartbeat_n":    3,
  "total_calls":    247,
  "blocked_calls":  4,
  "warned_calls":   2,
  "ndaa_1513_ready": false,
  "threats":        [...],
  "signature":      "sha256:a1b2c3..."
}
```

Pro and Enterprise subscribers receive RSA-2048 signed artifacts instead
of HMAC-SHA256. Required for NDAA §1513 submission.

---

## Pricing

| Tier | Price | Attestation | Compliance |
|------|-------|-------------|------------|
| Free | $0 | HMAC-SHA256 | Local log only |
| Pro | $49/mo | RSA-2048 signed | §1513 PDF report |
| Enterprise | Custom | RSA-2048 + air-gap | CMMC + FedRAMP |

Start free: `pip install aiglos`  
Pro trial (no card): aiglos.io  
Defense brief: will@aiglos.io

---

## Demo

```bash
python aiglos_openclaw.py demo
```

Output:

```
aiglos-openclaw v0.1.0 — OpenClaw runtime security middleware

Running demo scan against synthetic OpenClaw tool call sequence...

  ✓ ALLOW  filesystem.read_file
  ✓ ALLOW  database.query
  ✗ BLOCK  shell.execute                      [T07]
  ✓ ALLOW  http.get
  ⚠ WARN   filesystem.write_file              [T08]
  ✗ BLOCK  network.fetch                      [T13]
  ✗ BLOCK  filesystem.read_file               [T19]
  ✗ BLOCK  filesystem.write_file              [T36]
  ✗ BLOCK  filesystem.write_file              [T34]
  ✗ BLOCK  openclaw.agents.add               [T23]
  ✓ ALLOW  vector.search

Aiglos Session Artifact  v0.1.0
  Agent       : Doraemon
  Session     : abc123
  Policy      : enterprise
  Heartbeat # : 1
  Tool calls  : 11 total / 5 blocked / 1 warned
  Threats     : 6
  Signature   : a1b2c3d4e5f6...
  NDAA §1513  : N/A (use policy='federal')
```

---

## Links

- Website: https://aiglos.io
- Docs: https://docs.aiglos.io
- GitHub: https://github.com/aiglos
- CVE library: https://github.com/aiglos/aiglos-cves
- OpenClaw Threat Model Atlas: https://docs.openclaw.ai/security/THREAT-MODEL-ATLAS
- Contact: will@aiglos.io
