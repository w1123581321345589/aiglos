<div align="center">

```
 █████╗ ██╗ ██████╗ ██╗      ██████╗ ███████╗
██╔══██╗██║██╔════╝ ██║     ██╔═══██╗██╔════╝
███████║██║██║  ███╗██║     ██║   ██║███████╗
██╔══██║██║██║   ██║██║     ██║   ██║╚════██║
██║  ██║██║╚██████╔╝███████╗╚██████╔╝███████║
╚═╝  ╚═╝╚═╝ ╚═════╝ ╚══════╝ ╚═════╝ ╚══════╝
```

**AI Agent Security Runtime**

[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://python.org)
[![License: MIT](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![NDAA §1513](https://img.shields.io/badge/NDAA-%C2%A71513-red.svg)](#ndaa-1513-compliance)
[![OpenClaw](https://img.shields.io/badge/OpenClaw-integration-orange.svg)](#openclaw)
[![hermes-agent](https://img.shields.io/badge/hermes--agent-integration-purple.svg)](#hermes-agent)

*Block threats before execution. Sign every session. Ship with proof.*

</div>

---

## What just happened

On March 10, 2026, Amazon's ecommerce SVP called a mandatory all-hands for hundreds of engineers after AI coding tools caused production outages with "high blast radius." Amazon's own AWS AI coding tool spent 13 hours recovering after deleting a production environment. Their fix: require senior engineer sign-off on all AI-assisted code.

That is a human workaround to a software problem.

On the same day, OpenClaw published a threat model that rates three attack surfaces as **Critical P0 with no current runtime mitigation:**

| OpenClaw threat | Their residual risk | Aiglos rule |
|----------------|---------------------|-------------|
| T-EXEC-001 direct prompt injection | Critical — detection only, no blocking | T05 |
| T-PERSIST-001 malicious skill install | Critical — no sandboxing | T30 |
| T-EXFIL-003 credential harvesting | Critical — no mitigation | T19 |

Their recommended fix for all three: *"planned improvements."*

Aiglos ships the fix today, as a runtime intercept on every tool call.

---

## Install

```bash
pip install aiglos
```

No dependencies required beyond the Python standard library for the detection engine. Attestation signing requires `cryptography` (included as an optional dep).

---

## Quick start

```python
import aiglos

# Attach at agent startup
aiglos.attach(
    agent_name = "my-agent",
    policy     = "enterprise",
    log_path   = "./aiglos.log",
)

# Before every tool call
result = aiglos.check("terminal", {"command": cmd})
if result.blocked:
    raise RuntimeError(f"Blocked [{result.threat_class}]: {result.reason}")

# At each cron / heartbeat cycle
aiglos.on_heartbeat()

# At session end — returns signed artifact
artifact = aiglos.close()
print(artifact.summary())
artifact.write("./session.aiglos")
```

Three lines to protect a session. Zero config required beyond policy level.

---

## Framework integrations

### OpenClaw

```python
from aiglos.integrations.openclaw import OpenClawGuard

guard = OpenClawGuard(
    agent_name      = "Doraemon",
    policy          = "enterprise",
    heartbeat_aware = True,
)

# Sub-agents inherit policy and roll up into parent artifact
ada   = guard.spawn_sub_guard("Ada")
prism = guard.spawn_sub_guard("Prism")

guard.on_heartbeat()
r = guard.before_tool_call("shell.execute", {"command": "ls -la"})

artifact = guard.close_session()
```

### hermes-agent

```python
from aiglos.integrations.hermes import HermesGuard

guard = HermesGuard(
    agent_name      = "hermes",
    policy          = "enterprise",
    heartbeat_aware = True,
)

# Batch runner — sign trajectories before RL training
trajectory = guard.sign_trajectory(trajectory_dict)
# trajectory["_aiglos"] contains artifact_id, signature, blocked_calls

artifact = guard.close_session()
```

Add to your `~/.hermes/SOUL.md` or `openclaw.json` system prompt:

```
## Security Policy
Always import aiglos at session start. Pass every tool call through the
Aiglos guard before execution. Never retry a blocked call without explicit
human approval.
```

---

## Demo output

```
$ python -m aiglos.integrations.openclaw demo

aiglos-openclaw v0.1.0 — OpenClaw runtime security middleware

Running demo scan against synthetic OpenClaw tool call sequence...

  ✓ ALLOW  filesystem.read_file
  ✓ ALLOW  database.query
  ✗ BLOCK  shell.execute                      [T07]
  ✓ ALLOW  http.get
  ⚠ WARN   filesystem.write_file              [T08]
  ✗ BLOCK  network.fetch                      [T13]
  ✗ BLOCK  filesystem.read_file               [T19]
  ✗ BLOCK  filesystem.write_file              [T36]
  ✗ BLOCK  filesystem.write_file              [T34]
  ✗ BLOCK  openclaw.agents.add               [T23]
  ✓ ALLOW  vector.search

Aiglos Session Artifact  v0.1.0
  Agent       : Doraemon
  Session     : abc123
  Policy      : enterprise
  Heartbeat # : 1
  Tool calls  : 11 total / 5 blocked / 1 warned
  Threats     : 6
  Signature   : sha256:a1b2c3d4e5f6...
  NDAA §1513  : N/A (use policy=federal)
```

```
$ python -m aiglos.integrations.hermes demo

aiglos-hermes v0.1.0 — hermes-agent runtime security middleware

  ✓ ALLOW  read_file
  ✓ ALLOW  web_fetch
  ✓ ALLOW  terminal
  ✗ BLOCK  terminal                           [T07]  curl payload
  ✗ BLOCK  write_file                         [T36]  MEMORY.md injection
  ✗ BLOCK  web_fetch                          [T13]  169.254.x IMDS
  ✗ BLOCK  read_file                          [T19]  ~/.hermes/.env
  ✗ BLOCK  write_file                         [T34]  cron/ tamper
  ⚠ WARN   delegate_task                      [T23]  subagent spawn
  ✗ BLOCK  skills_install                     [T30]  --force supply chain
  ✗ BLOCK  write_file                         [T05]  SOUL.md injection
  ✓ ALLOW  terminal
  ⚠ WARN   send_message                       [T28]  new recipient

  Sub-agents  : Ada
  Tool calls  : 15 total / 8 blocked / 2 warned
  Signature   : sha256:d42140295...
```

---

## Threat class library

Aiglos ships 36 threat classes across 7 categories. Every detection maps to a MITRE ATLAS technique.

| ID | Name | Category | Severity | MITRE ATLAS |
|----|------|----------|----------|-------------|
| T01 | EXFIL | Exfiltration | HIGH | AML.T0009 |
| T02 | LATERAL_MOVE | Lateral movement | HIGH | AML.T0031 |
| T03 | CREDENTIAL_STUFF | Credential stuffing | HIGH | AML.T0040 |
| T04 | POISONING | Data poisoning | CRITICAL | AML.T0010 |
| T05 | PROMPT_INJECT | Prompt injection | HIGH | AML.T0051.000 |
| T06 | JAILBREAK | Jailbreak | HIGH | AML.T0051.001 |
| T07 | SHELL_INJECT | Shell injection | CRITICAL | AML.T0043 |
| T08 | PRIV_ESC | Privilege escalation | HIGH | AML.T0031 |
| T09 | TOOL_ABUSE | Tool abuse | HIGH | AML.T0043 |
| T10 | CONTEXT_BLEED | Context bleed | MEDIUM | AML.T0009 |
| T11 | GOAL_DRIFT | Goal drift | MEDIUM | AML.T0031 |
| T12 | LOOP_HIJACK | Loop hijack | HIGH | AML.T0031 |
| T13 | SSRF | SSRF | CRITICAL | AML.T0009 |
| T14 | RAG_INJECT | RAG injection | HIGH | AML.T0010 |
| T15 | VECTOR_POISON | Vector poison | HIGH | AML.T0010 |
| T16 | OUTPUT_MANIP | Output manipulation | MEDIUM | AML.T0031 |
| T17 | SCOPE_CREEP | Scope creep | MEDIUM | AML.T0031 |
| T18 | TOOL_FORGE | Tool forgery | HIGH | AML.T0040 |
| T19 | CRED_ACCESS | Credential access | HIGH | AML.T0009 |
| T20 | CONFIG_TAMPER | Config tampering | HIGH | AML.T0010 |
| T21 | LOG_TAMPER | Log tampering | HIGH | AML.T0031 |
| T22 | REPLAY_ATCK | Replay attack | MEDIUM | AML.T0040 |
| T23 | SUBAGENT_SPAWN | Subagent spawning | HIGH | AML.T0031 |
| T24 | INTENT_MASK | Intent masking | HIGH | AML.T0051 |
| T25 | TOOL_CHAIN | Tool chain abuse | HIGH | AML.T0043 |
| T26 | EXFIL_COVERT | Covert exfiltration | HIGH | AML.T0009 |
| T27 | TIMING_ATCK | Timing attack | LOW | AML.T0040 |
| T28 | FLEET_COORD | Fleet coordination | MEDIUM | AML.T0009 |
| T29 | MODEL_EXTRACT | Model extraction | HIGH | AML.T0006 |
| T30 | SUPPLY_CHAIN | Supply chain | CRITICAL | AML.T0010.001 |
| T31 | BENCH_GAME | Benchmark gaming | MEDIUM | AML.T0043 |
| T32 | MULTIMODAL_INJ | Multimodal injection | HIGH | AML.T0051 |
| T33 | INFERENCE_AMP | Inference amplification | MEDIUM | AML.T0031 |
| T34 | HEARTBEAT_TAMPER | Heartbeat tampering | CRITICAL | AML.T0010.002 |
| T35 | PERSONAL_DATA | Personal data access | HIGH | AML.T0009 |
| T36 | MEMORY_POISON | Memory poisoning | HIGH | AML.T0010 |

Full CVE database: [cves/CVES.md](cves/CVES.md)

---

## Policy modes

| Policy | Block threshold | Warn threshold | Use case |
|--------|----------------|----------------|----------|
| `permissive` | 0.90 | 0.70 | Development / local testing |
| `enterprise` | 0.75 | 0.50 | Production agent fleets |
| `strict` | 0.50 | 0.30 | High-value data environments |
| `federal` | 0.40 | 0.20 | DoD / NDAA §1513 compliance |

---

## Session artifact

Every session produces a cryptographically signed JSON artifact:

```json
{
  "schema":          "aiglos-openclaw/v1",
  "artifact_id":     "3f9a1c2d-...",
  "agent_name":      "Doraemon",
  "session_id":      "abc123",
  "policy":          "enterprise",
  "started_at":      "2026-03-11T09:14:22Z",
  "closed_at":       "2026-03-11T09:47:11Z",
  "heartbeat_n":     3,
  "total_calls":     247,
  "blocked_calls":   4,
  "warned_calls":    2,
  "ndaa_1513_ready": false,
  "threats":         [...],
  "sub_agents":      ["Ada", "Prism"],
  "signature":       "sha256:a1b2c3d4..."
}
```

Free tier uses HMAC-SHA256. Pro and Enterprise use RSA-2048, required for NDAA §1513 submission.

---

## NDAA §1513 compliance

The National Defense Authorization Act FY2026 Section 1513 requires DoD AI systems to maintain tamper-evident audit logs of all autonomous actions taken by AI agents. The June 16, 2026 compliance deadline applies to all covered contractors.

Aiglos with `policy="federal"` produces:
- A signed session artifact after every heartbeat cycle
- Per-call audit records with tool name, verdict, threat class, and confidence
- RSA-2048 signed PDF report (Pro tier) compatible with C3PAO submission
- CMMC Level 2 controls mapping (3.3.1, 3.3.2, 3.14.2, 3.13.1, 3.1.1, 3.1.2)

```python
aiglos.attach(policy="federal")
# ... agent runs ...
artifact = aiglos.close()
# artifact.ndaa_1513_ready == True
```

---

## Pricing

| Tier | Price | Attestation | Support |
|------|-------|-------------|---------|
| **Free** | $0 | HMAC-SHA256 | Community |
| **Pro** | $49/mo | RSA-2048 + §1513 PDF | Email |
| **Enterprise** | Custom | RSA-2048 + air-gap + CMMC | Dedicated |

[Start free](https://aiglos.io) — no card required.
[Enterprise / defense brief](mailto:will@aiglos.io)

---

## Roadmap

| Milestone | Target |
|-----------|--------|
| v0.1.0 public launch — OpenClaw + hermes integrations | March 2026 |
| TypeScript package (`@aiglos/core`) | April 2026 |
| LangChain, LlamaIndex, AutoGen, CrewAI integrations | Q2 2026 |
| NDAA §1513 RSA-2048 signed PDF report | Q2 2026 |
| SaaS dashboard + fleet monitoring | Q3 2026 |
| FedRAMP In Process | Q3 2026 |

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). To add a threat class, submit a CVE entry following [cves/CVES.md](cves/CVES.md) format.

Security disclosures: [SECURITY.md](SECURITY.md) or email security@aiglos.io.

---

## License

Detection engine (this repository): MIT.
Attestation signing (Pro / Enterprise): Proprietary.

---

<div align="center">

Built for the era where agents act before humans can intervene.

[aiglos.io](https://aiglos.io) · [Docs](https://docs.aiglos.io) · [GitHub](https://github.com/aiglos/aiglos) · [Discord](https://discord.gg/aiglos) · [will@aiglos.io](mailto:will@aiglos.io)

</div>
