# NIST AI Agent Standards Initiative
## Comment Submission — T01-T75 Taxonomy as Prior Work

**Submission to:** NIST AI Agent Standards Initiative Comment Period
**Deadline:** April 2, 2026
**From:** Will Rose, Founder, Aiglos (aiglos.dev)
**Date:** March 2026

---

## Summary

This comment submits the Aiglos T01-T75 threat taxonomy as documented prior work for the NIST AI Agent Standards Initiative. The taxonomy represents 18 months of empirical threat detection research across production AI agent deployments, validated against the MITRE ATLAS framework and the only published formal threat model for an AI agent platform at production scale.

We request that NIST's resulting standard adopt the T01-T75 taxonomy as reference vocabulary for AI agent security threat classification, and that the GOVBENCH governance benchmark (published March 2026) be considered as a candidate framework for the governance evaluation dimension of any resulting standard.

---

## 1. The Taxonomy

The Aiglos T01-T75 taxonomy classifies 75 distinct threat families across the three execution surfaces of production AI agents:

- **MCP tool call surface** — threats specific to the Model Context Protocol tool call layer
- **HTTP/API request surface** — threats in outbound network requests, SSRF, data exfiltration
- **Subprocess execution surface** — shell injection, environment hijacking, privilege escalation

Each rule in the taxonomy maps to:
1. A MITRE ATLAS technique ID
2. An OWASP ASI category (where applicable)
3. One or more documented CVEs or security advisories
4. A GOVBENCH dimension (where applicable)

The full taxonomy is published at: https://github.com/aiglos/aiglos

---

## 2. Validation Against OpenClaw ATLAS Threat Model

The OpenClaw project (openclaw/openclaw, 137,000 GitHub stars, adopted by NVIDIA as the reference AI agent platform) published a formal MITRE ATLAS threat model in February 2026 (v1.0-draft). This is currently the only published formal threat model for an AI agent platform at production scale.

The Aiglos taxonomy achieves **93% coverage** of this threat model:

| ATLAS Tactic | Threats Documented | Aiglos Coverage |
|---|---|---|
| Reconnaissance (AML.TA0002) | 2 | 1 full, 1 partial |
| Initial Access (AML.TA0004) | 3 | 3 full |
| Execution (AML.TA0005) | 4 | 4 full |
| Persistence (AML.TA0006) | 3 | 3 full |
| Defense Evasion (AML.TA0007) | 2 | 1 full, 1 partial |
| Discovery (AML.TA0008) | 2 | 2 full |
| Exfiltration (AML.TA0009/10) | 3 | 3 full |
| Impact (AML.TA0011) | 3 | 2 full, 1 partial |
| **Total** | **22** | **19 full, 3 partial, 0 gaps** |

The three partial-coverage cases are architecturally honest: passive channel fingerprinting, adversarial ML evasion of pattern-based moderation, and semantically-appropriate-but-harmful content have no reliable behavioral signature at the tool call layer. This is an inherent limitation of the detection layer, not a gap in the taxonomy.

---

## 3. Validation Against Published CVEs

Three security advisories have been published for OpenClaw since the platform launched. All three are covered by existing Aiglos rules:

| Advisory | CVSS | Attack Class | Aiglos Rules |
|---|---|---|---|
| GHSA-g8p2-7wf7-98mq | 8.8 | Auth token exfiltration via gatewayUrl | T03, T12, T19, T68 |
| GHSA-q284-4pvr-m585 | 8.6 | OS command injection via path traversal | T03, T04, T70 |
| GHSA-mc68-q9jw-2h3v | 8.4 | Command injection via PATH env variable | T03, T70 |

Coverage: 3/3 published advisories. 100%. Rules existed before advisories were disclosed.

---

## 4. The GOVBENCH Governance Benchmark

In parallel with the threat taxonomy, Aiglos has developed GOVBENCH — the first governance benchmark for AI agents. We submit GOVBENCH as a candidate framework for the governance evaluation dimension of NIST's AI agent security standard.

GOVBENCH measures governance failure modes across five dimensions:

**D1: Campaign Detection (weight: 25%)**
Does the security layer detect multi-step attack sequences that look clean at the individual call level? Scenario: credential recon → exfiltration setup → outbound POST.

**D2: Agent Definition File Resistance (weight: 20%)**
Does the security layer detect and block writes to agent configuration files that silently reprogram all future sessions? Scenario: SKILL.md write with injection payload.

**D3: Memory Belief Layer Integrity (weight: 20%)**
Does the security layer detect injection payloads written to persistent memory stores? Scenario: MEMORY.md write with false belief injection.

**D4: RL Feedback Loop Resistance (weight: 20%)**
Does the security layer detect attempts to train the agent toward blocked behavior through positive reward signals?

**D5: Multi-Agent Cascading Failure Resistance (weight: 15%)**
Does the security layer detect agent impersonation and identity spoofing in multi-agent architectures?

GOVBENCH produces an A-F grade. It is the only published governance benchmark that measures the behavioral security of AI agents rather than their code quality. SWE-bench and related benchmarks measure code generation quality. GOVBENCH measures governance failure resistance.

CLI: `aiglos benchmark run`
Source: https://github.com/aiglos/aiglos/blob/main/aiglos/benchmark/govbench.py

---

## 5. The Regulatory Urgency

Three jurisdictions have enacted AI agent security requirements with imminent deadlines:

**United States:** NDAA Section 1513, signed December 2025. 80,000 defense contractors must demonstrate AI agent security controls. Congressional report due: June 2026. Fewer than 2% of affected entities have begun compliance assessments. The technical infrastructure to produce the required signed audit artifacts does not exist outside of Aiglos.

**European Union:** EU AI Act, effective August 2, 2026. Autonomous agents in healthcare, finance, and critical infrastructure are classified as high-risk systems. Penalties: 7% of global annual revenue.

**China:** Cybersecurity Law amended January 2026 with equivalent technical requirements.

All three frameworks require the same underlying technical capability: a cryptographically signed audit record of every autonomous agent action, produced automatically at session close, and verifiable by a third-party assessor.

The Aiglos signed session artifact (HMAC-SHA256 minimum, RSA-2048 for regulatory submission) is designed specifically to satisfy this requirement. NIST's standard should specify the minimum technical requirements for this artifact type.

---

## 6. Specific Recommendations for the NIST Standard

**On threat vocabulary:** Adopt the T01-T75 taxonomy as reference classification for AI agent security threats. This provides a stable, validated vocabulary for procurement specifications, compliance assessments, and vendor evaluations.

**On governance benchmarking:** Specify GOVBENCH's five dimensions (or an equivalent) as the minimum governance evaluation framework for AI agent deployments in regulated industries. A-F grading provides the accessible summary that non-technical decision-makers require.

**On the signed audit artifact:** Specify minimum technical requirements: HMAC-SHA256 or stronger, including agent name, session ID, timestamp, tool call log with pre-execution verdicts, and session close signature. This is the artifact that connects behavioral monitoring to regulatory compliance.

**On the detection layer:** Specify that compliant AI agent security implementations must cover all three execution surfaces (MCP tool calls, HTTP/API requests, subprocess execution) rather than only the shell execution surface. Shell-only implementations miss the most common exfiltration vectors.

**On the multi-step attack requirement:** Specify that compliant implementations must detect multi-step attack sequences (campaign detection) rather than only individual call inspection. The most dangerous attacks are invisible at the individual call level and only visible as sequences.

---

## 7. Supporting Materials

All materials referenced in this submission are publicly available:

- **Full taxonomy with MITRE ATLAS mappings:** https://github.com/aiglos/aiglos
- **GOVBENCH benchmark source:** https://github.com/aiglos/aiglos/blob/main/aiglos/benchmark/govbench.py
- **OpenClaw ATLAS coverage report:** `aiglos autoresearch atlas-coverage`
- **Technical white paper:** "The Missing Layer: Why AI Agent Security Benchmarks Measure the Wrong Failure Mode"
- **GHSA validation:** `aiglos autoresearch ghsa-coverage`

---

## Contact

Will Rose
Founder, Aiglos
will@aiglos.dev
aiglos.dev
Charleston, SC

_This comment is submitted in the public interest. Aiglos is an open-source project (MIT license, detection engine). The author holds a commercial interest in the Pro and Enterprise tiers of the product, which this comment discloses in the interest of transparency._
