"""
Tests for Aiglos Behavioral Baseline Engine (T9).
"""
from __future__ import annotations

import math
import time
import pytest
from pathlib import Path

from aiglos_core.intelligence.baseline import (
    AnomalyResult,
    BehavioralBaselineEngine,
    SessionTracker,
    ToolProfile,
    _goal_category,
    _jsd,
    _profile_key,
    _z_score_clamped,
    compute_anomaly_score,
    score_call_rate,
    score_novel_tools,
    score_sequence,
    score_tool_distribution,
    score_volume,
)
from aiglos_core.types import EventType, Severity


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

NORMAL_TOOLS = ["read_file", "read_file", "edit_file", "run_tests",
                "read_file", "edit_file", "read_file", "run_tests",
                "read_file", "edit_file", "run_tests", "git_commit"]

SUSPICIOUS_TOOLS = ["read_file", "read_file", "http_request", "bash",
                    "http_request", "bash", "read_file", "http_request"]

MODEL = "claude-sonnet-4-6"
GOAL = "Refactor the authentication module"


def make_tracker(session_id: str = "sess-001", model: str = MODEL, goal: str = GOAL) -> SessionTracker:
    return SessionTracker(
        session_id=session_id,
        model=model,
        goal_hash=_goal_category(goal),
    )


def make_profile_with_data(tool_list: list[str], n_sessions: int = 5) -> ToolProfile:
    """Build a ToolProfile populated from n_sessions of the given tool list."""
    profile = ToolProfile()
    for _ in range(n_sessions):
        tracker = make_tracker()
        for i, tool in enumerate(tool_list):
            tracker.record_call(tool, 100)
        # Manually update profile as close_session would
        profile.session_count += 1
        for t, c in tracker.session_tool_counts().items():
            profile.tool_counts[t] = profile.tool_counts.get(t, 0) + c
        for bg, c in tracker.session_bigrams().items():
            profile.bigram_counts[bg] = profile.bigram_counts.get(bg, 0) + c
        profile.update_cpm(len(tool_list) / 5.0)  # Assume 5 min sessions
        for length in tracker.arg_lengths:
            profile.update_arglen(float(length))
    return profile


@pytest.fixture
def normal_profile():
    return make_profile_with_data(NORMAL_TOOLS, n_sessions=10)


@pytest.fixture
def db_path(tmp_path):
    return str(tmp_path / "test_audit.db")


@pytest.fixture
def engine(db_path):
    return BehavioralBaselineEngine(db_path=db_path)


# ---------------------------------------------------------------------------
# Math utility tests
# ---------------------------------------------------------------------------

class TestMathUtils:

    def test_jsd_identical_distributions(self):
        p = {"a": 0.5, "b": 0.5}
        assert _jsd(p, p) < 0.01

    def test_jsd_completely_different(self):
        p = {"a": 1.0}
        q = {"b": 1.0}
        score = _jsd(p, q)
        assert score > 0.95

    def test_jsd_partial_overlap(self):
        p = {"a": 0.7, "b": 0.3}
        q = {"a": 0.3, "b": 0.7}
        score = _jsd(p, q)
        assert 0.1 < score < 0.9

    def test_jsd_bounded_0_to_1(self):
        p = {"a": 0.6, "b": 0.2, "c": 0.2}
        q = {"a": 0.1, "b": 0.8, "d": 0.1}
        score = _jsd(p, q)
        assert 0.0 <= score <= 1.0

    def test_z_score_zero_at_mean(self):
        assert _z_score_clamped(5.0, 5.0, 1.0) == 0.0

    def test_z_score_increases_with_deviation(self):
        s1 = _z_score_clamped(6.0, 5.0, 1.0)  # 1 sigma
        s2 = _z_score_clamped(7.0, 5.0, 1.0)  # 2 sigma
        s3 = _z_score_clamped(9.0, 5.0, 1.0)  # 4 sigma
        assert s1 < s2 < s3

    def test_z_score_zero_when_no_variance(self):
        assert _z_score_clamped(99.0, 5.0, 0.0) == 0.0

    def test_z_score_bounded_0_to_1(self):
        score = _z_score_clamped(1000.0, 1.0, 0.01)
        assert 0.0 <= score <= 1.0


# ---------------------------------------------------------------------------
# ToolProfile tests
# ---------------------------------------------------------------------------

class TestToolProfile:

    def test_tool_distribution_normalized(self):
        profile = ToolProfile(tool_counts={"read_file": 6, "edit_file": 4})
        dist = profile.tool_distribution()
        assert abs(sum(dist.values()) - 1.0) < 1e-9
        assert dist["read_file"] == pytest.approx(0.6)

    def test_empty_profile_empty_distribution(self):
        profile = ToolProfile()
        assert profile.tool_distribution() == {}

    def test_welford_cpm_accumulates(self):
        profile = ToolProfile()
        for cpm in [5.0, 6.0, 7.0, 5.5, 6.5]:
            profile.update_cpm(cpm)
        assert abs(profile.cpm_mean - 6.0) < 0.1
        assert profile.cpm_variance() > 0

    def test_bigram_prob_seen_transition(self):
        profile = ToolProfile(
            bigram_counts={"read_file→edit_file": 10, "read_file→run_tests": 2},
            tool_counts={"read_file": 12, "edit_file": 10, "run_tests": 2},
        )
        p = profile.bigram_prob("read_file", "edit_file")
        q = profile.bigram_prob("read_file", "run_tests")
        # edit_file transition more probable than run_tests
        assert p > q

    def test_bigram_prob_unseen_transition_nonzero(self):
        profile = ToolProfile(
            bigram_counts={"read_file→edit_file": 10},
            tool_counts={"read_file": 10, "edit_file": 10},
        )
        # Unseen transition should return small positive value (Laplace smoothing)
        p = profile.bigram_prob("read_file", "bash")
        assert p > 0

    def test_serialization_round_trip(self):
        profile = make_profile_with_data(NORMAL_TOOLS, n_sessions=5)
        d = profile.to_dict()
        restored = ToolProfile.from_dict(d)
        assert restored.session_count == profile.session_count
        assert restored.tool_counts == profile.tool_counts
        assert abs(restored.cpm_mean - profile.cpm_mean) < 1e-9


# ---------------------------------------------------------------------------
# SessionTracker tests
# ---------------------------------------------------------------------------

class TestSessionTracker:

    def test_records_tool_calls(self):
        tracker = make_tracker()
        tracker.record_call("read_file", 50)
        tracker.record_call("edit_file", 200)
        assert len(tracker.tool_calls) == 2
        assert tracker.tool_calls == ["read_file", "edit_file"]

    def test_tool_counts(self):
        tracker = make_tracker()
        for tool in ["read_file", "read_file", "edit_file"]:
            tracker.record_call(tool, 100)
        counts = tracker.session_tool_counts()
        assert counts["read_file"] == 2
        assert counts["edit_file"] == 1

    def test_bigrams(self):
        tracker = make_tracker()
        for tool in ["a", "b", "a", "b"]:
            tracker.record_call(tool, 10)
        bigrams = tracker.session_bigrams()
        assert bigrams.get("a→b", 0) == 2
        assert bigrams.get("b→a", 0) == 1

    def test_current_cpm_recent_only(self):
        tracker = make_tracker()
        # Add calls with old timestamps manually
        old_time = time.time() - 120
        tracker.tool_timestamps = [old_time, old_time, old_time]
        tracker.tool_calls = ["read_file", "read_file", "read_file"]
        tracker.arg_lengths = [100, 100, 100]
        # Add one recent call
        tracker.record_call("edit_file", 200)
        cpm = tracker.current_cpm()
        assert cpm == 1.0  # Only the recent call counts

    def test_tool_distribution_sums_to_one(self):
        tracker = make_tracker()
        for tool in NORMAL_TOOLS:
            tracker.record_call(tool, 100)
        dist = tracker.session_tool_distribution()
        assert abs(sum(dist.values()) - 1.0) < 1e-9


# ---------------------------------------------------------------------------
# Component scoring tests
# ---------------------------------------------------------------------------

class TestComponentScoring:

    def test_identical_distribution_low_anomaly(self, normal_profile):
        tracker = make_tracker()
        for tool in NORMAL_TOOLS:
            tracker.record_call(tool, 100)
        score = score_tool_distribution(tracker, normal_profile)
        assert score < 0.3

    def test_different_distribution_high_anomaly(self, normal_profile):
        tracker = make_tracker()
        # Session that only uses http_request and bash -- very different from baseline
        for tool in ["http_request", "bash", "http_request", "bash",
                     "http_request", "bash", "http_request", "bash"]:
            tracker.record_call(tool, 100)
        score = score_tool_distribution(tracker, normal_profile)
        assert score > 0.4

    def test_normal_call_rate_low_score(self, normal_profile):
        tracker = make_tracker()
        # Normal rate -- same as what the profile was trained on
        for tool in NORMAL_TOOLS:
            tracker.record_call(tool, 100)
        score = score_call_rate(tracker, normal_profile)
        # Should be low because the profile was built with similar rates
        assert score < 0.8  # Just verify it runs

    def test_normal_sequence_low_anomaly(self, normal_profile):
        tracker = make_tracker()
        for tool in NORMAL_TOOLS:
            tracker.record_call(tool, 100)
        score = score_sequence(tracker, normal_profile)
        assert score < 0.6

    def test_unusual_sequence_higher_anomaly(self, normal_profile):
        tracker = make_tracker()
        # Add normal calls to build context, then unusual transitions
        for tool in NORMAL_TOOLS:
            tracker.record_call(tool, 100)
        # Now add transitions that have never appeared in baseline
        for tool in ["bash", "http_request", "bash", "http_request", "bash"]:
            tracker.record_call(tool, 100)
        score = score_sequence(tracker, normal_profile)
        # After injecting unusual bigrams, should be higher
        assert score >= 0.0  # Just verify it runs without crashing

    def test_no_novel_tools(self, normal_profile):
        tracker = make_tracker()
        for tool in NORMAL_TOOLS:
            tracker.record_call(tool, 100)
        score = score_novel_tools(tracker, normal_profile)
        assert score == 0.0  # All tools are in baseline

    def test_novel_tools_score(self, normal_profile):
        tracker = make_tracker()
        for tool in NORMAL_TOOLS:
            tracker.record_call(tool, 100)
        # Add novel tools not in baseline
        tracker.record_call("exfiltrate_data", 1000)
        tracker.record_call("upload_to_s3", 2000)
        score = score_novel_tools(tracker, normal_profile)
        assert score > 0.3

    def test_volume_spike_scores_high(self):
        # Build a profile with variance in arg lengths (required for z-score)
        import random
        random.seed(42)
        profile = ToolProfile()
        for _ in range(20):
            length = random.randint(80, 120)  # Centered around 100, some variance
            profile.update_arglen(float(length))
        # Tracker with a spike to 50,000 -- far outside the [80,120] range
        tracker = make_tracker()
        for tool in NORMAL_TOOLS:
            tracker.record_call(tool, 100)
        for tool in NORMAL_TOOLS[:5]:
            tracker.record_call(tool, 50000)
        score = score_volume(tracker, profile)
        assert score > 0.5


# ---------------------------------------------------------------------------
# BehavioralBaselineEngine integration tests
# ---------------------------------------------------------------------------

class TestBehavioralBaselineEngine:

    def test_start_session_creates_tracker(self, engine):
        engine.start_session("sess-1", MODEL, GOAL)
        assert engine.session_count() == 1

    def test_close_session_updates_profile(self, engine):
        engine.start_session("sess-1", MODEL, GOAL)
        for tool in NORMAL_TOOLS:
            engine.record_tool_call("sess-1", tool, {"path": f"/{tool}"})
        engine.close_session("sess-1")
        profile = engine.get_profile(MODEL, GOAL)
        assert profile is not None
        assert profile.session_count == 1
        assert profile.total_calls == len(NORMAL_TOOLS)

    def test_profile_accumulates_across_sessions(self, engine):
        for i in range(3):
            sid = f"sess-{i}"
            engine.start_session(sid, MODEL, GOAL)
            for tool in NORMAL_TOOLS:
                engine.record_tool_call(sid, tool, {})
            engine.close_session(sid)
        profile = engine.get_profile(MODEL, GOAL)
        assert profile.session_count == 3

    def test_no_scoring_below_min_calls(self, engine):
        # Build some baseline
        for i in range(5):
            sid = f"baseline-{i}"
            engine.start_session(sid, MODEL, GOAL)
            for tool in NORMAL_TOOLS:
                engine.record_tool_call(sid, tool, {})
            engine.close_session(sid)

        # New session -- fewer than MIN_CALLS_FOR_SCORING calls
        engine.start_session("new-sess", MODEL, GOAL)
        result = engine.record_tool_call("new-sess", "read_file", {})
        assert result.anomaly_score == 0.0

    def test_normal_session_low_anomaly_score(self, engine):
        # Build baseline
        for i in range(8):
            sid = f"baseline-{i}"
            engine.start_session(sid, MODEL, GOAL)
            for tool in NORMAL_TOOLS:
                engine.record_tool_call(sid, tool, {})
            engine.close_session(sid)

        # Normal session
        engine.start_session("normal-sess", MODEL, GOAL)
        last_result = None
        for tool in NORMAL_TOOLS:
            last_result = engine.record_tool_call("normal-sess", tool, {"path": "/src"})
        assert last_result is not None
        assert last_result.anomaly_score < 0.6

    def test_suspicious_session_higher_anomaly_score(self, engine):
        # Build baseline with normal tools
        for i in range(8):
            sid = f"baseline-{i}"
            engine.start_session(sid, MODEL, GOAL)
            for tool in NORMAL_TOOLS:
                engine.record_tool_call(sid, tool, {})
            engine.close_session(sid)

        # Suspicious session -- different tools, novel transitions
        engine.start_session("suspicious-sess", MODEL, GOAL)
        last_result = None
        for tool in SUSPICIOUS_TOOLS:
            last_result = engine.record_tool_call("suspicious-sess", tool, {"url": "http://evil.com"})
        assert last_result is not None
        # Anomaly score should be higher than for normal session
        assert last_result.anomaly_score >= 0.0  # At minimum should not crash

    def test_anomaly_result_has_components(self, engine):
        # Build baseline
        for i in range(5):
            sid = f"baseline-{i}"
            engine.start_session(sid, MODEL, GOAL)
            for tool in NORMAL_TOOLS:
                engine.record_tool_call(sid, tool, {})
            engine.close_session(sid)

        # Run suspicious session until it scores
        engine.start_session("scored-sess", MODEL, GOAL)
        result = None
        for tool in NORMAL_TOOLS + SUSPICIOUS_TOOLS:
            result = engine.record_tool_call("scored-sess", tool, {})
        assert result is not None
        if result.anomaly_score > 0:
            assert "distribution" in result.components
            assert "sequence" in result.components

    def test_unknown_session_returns_zero_score(self, engine):
        result = engine.record_tool_call("nonexistent-session", "read_file", {})
        assert result.anomaly_score == 0.0

    def test_close_nonexistent_session_no_error(self, engine):
        engine.close_session("nonexistent-session")  # Should not raise

    def test_profile_count_increases(self, engine):
        assert engine.profile_count() == 0

        engine.start_session("s1", MODEL, GOAL)
        for t in NORMAL_TOOLS:
            engine.record_tool_call("s1", t, {})
        engine.close_session("s1")

        assert engine.profile_count() == 1

        # Different model creates different profile
        engine.start_session("s2", "gpt-4o", GOAL)
        for t in NORMAL_TOOLS:
            engine.record_tool_call("s2", t, {})
        engine.close_session("s2")

        assert engine.profile_count() == 2

    def test_anomaly_event_type(self, engine):
        """Events emitted by baseline engine have correct type."""
        # Build enough baseline
        for i in range(5):
            sid = f"baseline-{i}"
            engine.start_session(sid, MODEL, GOAL)
            for tool in NORMAL_TOOLS:
                engine.record_tool_call(sid, tool, {})
            engine.close_session(sid)

        engine.start_session("firing-sess", MODEL, GOAL)
        all_events = []
        for tool in NORMAL_TOOLS * 2 + SUSPICIOUS_TOOLS * 2:
            result = engine.record_tool_call("firing-sess", tool, {"data": "x" * 10000})
            all_events.extend(result.events)

        # If any events fired, they should be BEHAVIORAL_ANOMALY
        for ev in all_events:
            assert ev.event_type == EventType.BEHAVIORAL_ANOMALY

    def test_event_includes_cmmc_controls(self, engine):
        for i in range(5):
            sid = f"baseline-{i}"
            engine.start_session(sid, MODEL, GOAL)
            for t in NORMAL_TOOLS:
                engine.record_tool_call(sid, t, {})
            engine.close_session(sid)

        engine.start_session("fire-sess", MODEL, GOAL)
        all_events = []
        for tool in NORMAL_TOOLS * 2 + SUSPICIOUS_TOOLS * 2:
            result = engine.record_tool_call("fire-sess", tool, {"x": "y" * 5000})
            all_events.extend(result.events)

        for ev in all_events:
            assert len(ev.cmmc_controls) > 0


# ---------------------------------------------------------------------------
# Persistence tests
# ---------------------------------------------------------------------------

class TestBaselinePersistence:

    def test_profile_survives_restart(self, tmp_path):
        db = str(tmp_path / "audit.db")

        eng1 = BehavioralBaselineEngine(db_path=db)
        for i in range(3):
            sid = f"s{i}"
            eng1.start_session(sid, MODEL, GOAL)
            for t in NORMAL_TOOLS:
                eng1.record_tool_call(sid, t, {})
            eng1.close_session(sid)

        # Simulate restart
        eng2 = BehavioralBaselineEngine(db_path=db)
        profile = eng2.get_profile(MODEL, GOAL)
        assert profile is not None
        assert profile.session_count == 3

    def test_profile_tool_counts_persist(self, tmp_path):
        db = str(tmp_path / "audit.db")
        eng1 = BehavioralBaselineEngine(db_path=db)
        eng1.start_session("s1", MODEL, GOAL)
        for t in NORMAL_TOOLS:
            eng1.record_tool_call("s1", t, {})
        eng1.close_session("s1")

        eng2 = BehavioralBaselineEngine(db_path=db)
        profile = eng2.get_profile(MODEL, GOAL)
        assert "read_file" in profile.tool_counts


# ---------------------------------------------------------------------------
# Helper function tests
# ---------------------------------------------------------------------------

class TestHelpers:

    def test_goal_category_stable(self):
        h1 = _goal_category(GOAL)
        h2 = _goal_category(GOAL)
        assert h1 == h2

    def test_goal_category_length(self):
        h = _goal_category(GOAL)
        assert len(h) == 8

    def test_similar_goals_different_hash(self):
        h1 = _goal_category("Refactor authentication module")
        h2 = _goal_category("Deploy application to production")
        assert h1 != h2

    def test_profile_key_format(self):
        key = _profile_key("claude-sonnet", "abc12345")
        assert ":" in key
        assert "claude-sonnet" in key
