"""
Tests for Aiglos Agent Identity Attestation (T7).
"""
from __future__ import annotations

import json
import time
import pytest

from aiglos_core.intelligence.attestation import (
    AttestationBuilder,
    AttestationDocument,
    attest_session,
    verify_document,
)
from aiglos_core.types import (
    AgentIdentity,
    EventType,
    SecurityEvent,
    SessionContext,
    Severity,
    ToolCall,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def make_session(
    goal: str = "Refactor the authentication module",
    model: str = "claude-sonnet-4-5",
    initiator: str = "will@aiglos.io",
    n_calls: int = 3,
    n_events: int = 2,
) -> tuple[SessionContext, list[SecurityEvent]]:
    ctx = SessionContext()
    ctx.identity.model_id = model
    ctx.identity.model_version = "20250514"
    ctx.identity.system_prompt_hash = "abc123def456" + "0" * 52
    ctx.identity.tool_permissions = ["read_file", "write_file", "bash"]
    ctx.identity.initiated_by = initiator
    ctx.identity.compute_attestation()
    ctx.set_goal(goal)
    ctx.goal_integrity_score = 0.92
    ctx.anomaly_score = 0.05
    ctx.end_time = ctx.identity.timestamp + 120.0

    for i in range(n_calls):
        call = ToolCall(
            session_id=ctx.identity.session_id,
            tool_name="read_file",
            arguments={"path": f"/project/file{i}.py"},
        )
        ctx.tool_calls.append(call)

    events = []
    for i in range(n_events):
        ev = SecurityEvent(
            session_id=ctx.identity.session_id,
            event_type=EventType.TOOL_CALL,
            severity=Severity.INFO,
            title=f"Tool call {i}",
            cmmc_controls=["3.3.1"],
            nist_controls=["AU-2"],
        )
        events.append(ev)
        ctx.events.append(ev)

    return ctx, events


# ---------------------------------------------------------------------------
# Core attestation tests
# ---------------------------------------------------------------------------

class TestAttestationDocument:

    def setup_method(self):
        # Use in-memory keys dir to avoid disk writes in tests
        self.builder = AttestationBuilder(keys_dir="/tmp/cg_test_keys")

    def test_document_produced(self):
        ctx, events = make_session()
        doc = self.builder.build(ctx, events)
        assert doc.session_id == ctx.identity.session_id
        assert doc.aiglos_attestation == "1.0"
        assert doc.issuer == "aiglos/0.1.0"

    def test_model_identity_correct(self):
        ctx, events = make_session(model="claude-opus-4-5")
        doc = self.builder.build(ctx, events)
        assert doc.model_identity["model_id"] == "claude-opus-4-5"
        assert doc.model_identity["system_prompt_hash"] == ctx.identity.system_prompt_hash

    def test_timeline_populated(self):
        ctx, events = make_session()
        doc = self.builder.build(ctx, events)
        assert doc.timeline["start_unix"] == ctx.identity.timestamp
        assert doc.timeline["end_unix"] == ctx.end_time
        assert doc.timeline["duration_seconds"] == 120.0
        assert "T" in doc.timeline["start_iso"]   # ISO format

    def test_security_posture_accurate(self):
        ctx, events = make_session(n_calls=5, n_events=3)
        # Block one call
        ctx.tool_calls[0].allowed = False
        doc = self.builder.build(ctx, events)
        assert doc.security_posture["total_tool_calls"] == 5
        assert doc.security_posture["blocked_calls"] == 1
        assert doc.security_posture["goal_integrity_score"] == 0.92
        assert doc.security_posture["anomaly_score"] == 0.05

    def test_event_manifest_complete(self):
        ctx, events = make_session(n_events=4)
        doc = self.builder.build(ctx, events)
        assert len(doc.event_manifest) == 4
        # Check sequence numbering
        for i, entry in enumerate(doc.event_manifest):
            assert entry["sequence"] == i
        # Each entry has a hash
        assert all(len(e["event_hash"]) == 64 for e in doc.event_manifest)

    def test_event_manifest_hashes_are_unique(self):
        ctx, events = make_session(n_events=3)
        doc = self.builder.build(ctx, events)
        hashes = [e["event_hash"] for e in doc.event_manifest]
        assert len(set(hashes)) == len(hashes)

    def test_cmmc_controls_aggregated(self):
        ctx, _ = make_session()
        # Add events with different controls
        events = [
            SecurityEvent(
                session_id=ctx.identity.session_id,
                event_type=EventType.CREDENTIAL_DETECTED,
                severity=Severity.CRITICAL,
                title="cred",
                cmmc_controls=["3.13.10", "3.13.16"],
                nist_controls=["SC-28", "IA-5"],
            ),
            SecurityEvent(
                session_id=ctx.identity.session_id,
                event_type=EventType.POLICY_VIOLATION,
                severity=Severity.HIGH,
                title="policy",
                cmmc_controls=["3.1.1", "3.13.10"],  # 3.13.10 is duplicate
                nist_controls=["AC-3"],
            ),
        ]
        doc = self.builder.build(ctx, events)
        # Controls deduplicated
        assert "3.13.10" in doc.cmmc_controls_active
        assert "3.13.16" in doc.cmmc_controls_active
        assert "3.1.1" in doc.cmmc_controls_active
        assert doc.cmmc_controls_active == sorted(set(doc.cmmc_controls_active))

    def test_tool_permissions_sorted(self):
        ctx, events = make_session()
        ctx.identity.tool_permissions = ["write_file", "bash", "read_file"]
        doc = self.builder.build(ctx, events)
        assert doc.tool_permissions == sorted(ctx.identity.tool_permissions)

    def test_document_hash_set(self):
        ctx, events = make_session()
        doc = self.builder.build(ctx, events)
        assert len(doc.document_hash) == 64  # SHA-256 hex

    def test_to_json_is_valid_json(self):
        ctx, events = make_session()
        doc = self.builder.build(ctx, events)
        parsed = json.loads(doc.to_json())
        assert parsed["session_id"] == ctx.identity.session_id
        assert "document_hash" in parsed
        assert "signature" in parsed

    def test_goal_hash_in_document(self):
        ctx, events = make_session(goal="Deploy the staging environment")
        doc = self.builder.build(ctx, events)
        assert doc.authorized_goal_hash == ctx.authorized_goal_hash
        assert len(doc.authorized_goal_hash) == 64


# ---------------------------------------------------------------------------
# Signature verification tests
# ---------------------------------------------------------------------------

class TestAttestationVerification:

    def setup_method(self):
        self.builder = AttestationBuilder(keys_dir="/tmp/cg_test_keys")

    def test_valid_document_verifies(self):
        ctx, events = make_session()
        doc = self.builder.build(ctx, events)
        is_valid, reason = self.builder.verify(doc)
        assert is_valid, f"Expected valid but got: {reason}"

    def test_tampered_session_id_fails(self):
        ctx, events = make_session()
        doc = self.builder.build(ctx, events)
        # Tamper with the document
        doc.session_id = "tampered-session-id"
        is_valid, reason = self.builder.verify(doc)
        assert not is_valid
        assert "tampered" in reason.lower() or "mismatch" in reason.lower()

    def test_tampered_security_posture_fails(self):
        ctx, events = make_session()
        doc = self.builder.build(ctx, events)
        # Attacker tries to inflate the goal integrity score
        doc.security_posture["goal_integrity_score"] = 1.0
        is_valid, reason = self.builder.verify(doc)
        assert not is_valid

    def test_tampered_event_manifest_fails(self):
        ctx, events = make_session(n_events=3)
        doc = self.builder.build(ctx, events)
        # Attacker removes an event from the manifest
        doc.event_manifest = doc.event_manifest[:-1]
        is_valid, reason = self.builder.verify(doc)
        assert not is_valid

    def test_tampered_model_identity_fails(self):
        ctx, events = make_session(model="claude-sonnet-4-5")
        doc = self.builder.build(ctx, events)
        # Attacker changes model to a less restricted one
        doc.model_identity["model_id"] = "gpt-4"
        is_valid, reason = self.builder.verify(doc)
        assert not is_valid

    def test_round_trip_json_verification(self):
        ctx, events = make_session()
        doc = self.builder.build(ctx, events)
        json_str = doc.to_json()
        is_valid, reason = self.builder.verify_json(json_str)
        assert is_valid, f"JSON round-trip failed: {reason}"

    def test_convenience_functions(self):
        ctx, events = make_session()
        doc = attest_session(ctx, events)
        assert doc.document_hash
        # verify_document uses a separate builder but same key dir
        json_str = doc.to_json()
        # Just verify parsing works
        parsed = json.loads(json_str)
        assert parsed["aiglos_attestation"] == "1.0"


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestAttestationEdgeCases:

    def setup_method(self):
        self.builder = AttestationBuilder(keys_dir="/tmp/cg_test_keys")

    def test_session_with_no_events(self):
        ctx, _ = make_session(n_events=0)
        doc = self.builder.build(ctx, [])
        assert doc.event_manifest == []
        assert doc.cmmc_controls_active == []
        is_valid, _ = self.builder.verify(doc)
        assert is_valid

    def test_session_with_no_end_time(self):
        ctx, events = make_session()
        ctx.end_time = None
        doc = self.builder.build(ctx, events)
        assert doc.timeline["end_unix"] is None
        assert doc.timeline["duration_seconds"] is None
        is_valid, _ = self.builder.verify(doc)
        assert is_valid

    def test_session_with_no_goal(self):
        ctx, events = make_session()
        ctx.authorized_goal = ""
        ctx.authorized_goal_hash = ""
        doc = self.builder.build(ctx, events)
        assert doc.authorized_goal_hash == ""
        is_valid, _ = self.builder.verify(doc)
        assert is_valid

    def test_multiple_attestations_different_hashes(self):
        """Two attestations for the same session at different times should differ."""
        ctx, events = make_session()
        doc1 = self.builder.build(ctx, events)
        time.sleep(0.01)
        doc2 = self.builder.build(ctx, events)
        # issued_at will differ, so document_hash will differ
        assert doc1.document_hash != doc2.document_hash

    def test_event_type_counts_in_posture(self):
        ctx, _ = make_session()
        events = [
            SecurityEvent(
                session_id=ctx.identity.session_id,
                event_type=EventType.CREDENTIAL_DETECTED,
                severity=Severity.CRITICAL,
                title="cred event",
            ),
            SecurityEvent(
                session_id=ctx.identity.session_id,
                event_type=EventType.GOAL_DRIFT,
                severity=Severity.HIGH,
                title="drift event",
            ),
            SecurityEvent(
                session_id=ctx.identity.session_id,
                event_type=EventType.POLICY_VIOLATION,
                severity=Severity.MEDIUM,
                title="policy event",
            ),
        ]
        doc = self.builder.build(ctx, events)
        assert doc.security_posture["critical_events"] == 1
        assert doc.security_posture["high_events"] == 1
        assert doc.security_posture["credential_events"] == 1
        assert doc.security_posture["goal_drift_events"] == 1
        assert doc.security_posture["policy_violations"] == 1
