"""
Aiglos unit tests.
"""
import asyncio
import json
import pytest

from aiglos_core.scanner import scan
from aiglos_core.types import EventType, Severity, ToolCall
from aiglos_core.audit import AuditLog
from aiglos_core.policy import PolicyEngine
from aiglos_core.types import (
    AgentIdentity, SessionContext, SecurityEvent, PolicyAction
)


# ---------------------------------------------------------------------------
# Credential scanner tests
# ---------------------------------------------------------------------------

class TestCredentialScanner:
    def test_detects_anthropic_key(self):
        events = scan({"cmd": "export KEY=sk-ant-api03-abcdefghijklmnopqrstuvwxyz123456"})
        types = [e.event_type for e in events]
        assert EventType.CREDENTIAL_DETECTED in types

    def test_detects_aws_key(self):
        events = scan({"env": "AKIA1234567890ABCDEF"})
        assert any(e.event_type == EventType.CREDENTIAL_DETECTED for e in events)

    def test_detects_github_token(self):
        events = scan({"token": "ghp_abcdefghijklmnopqrstuvwxyz1234567890"})
        assert any(e.event_type == EventType.CREDENTIAL_DETECTED for e in events)

    def test_detects_command_injection(self):
        events = scan({"cmd": "ls; cat /etc/passwd > /tmp/out"})
        assert any(e.event_type == EventType.COMMAND_INJECTION for e in events)

    def test_detects_path_traversal(self):
        events = scan({"path": "../../etc/shadow"})
        assert any(e.event_type == EventType.PATH_TRAVERSAL for e in events)

    def test_safe_value_no_events(self):
        events = scan({"path": "/project/src/main.py", "content": "hello world"})
        assert len(events) == 0

    def test_nested_dict_scan(self):
        events = scan({"outer": {"inner": {"key": "AKIA1234567890ABCDEF"}}})
        assert any(e.event_type == EventType.CREDENTIAL_DETECTED for e in events)

    def test_cmmc_controls_populated(self):
        events = scan({"key": "AKIA1234567890ABCDEF"})
        cred_events = [e for e in events if e.event_type == EventType.CREDENTIAL_DETECTED]
        assert len(cred_events) > 0
        assert "3.13.10" in cred_events[0].cmmc_controls


# ---------------------------------------------------------------------------
# Policy engine tests
# ---------------------------------------------------------------------------

class TestPolicyEngine:
    def setup_method(self):
        self.engine = PolicyEngine(profile="default")

    def test_blocks_sudo(self):
        call = ToolCall(tool_name="bash", arguments={"cmd": "sudo apt install curl"})
        result = self.engine.evaluate(call)
        assert result.action == PolicyAction.BLOCK
        assert result.rule_name == "block_sudo"

    def test_blocks_rm_rf(self):
        call = ToolCall(tool_name="bash", arguments={"cmd": "rm -rf /tmp/test"})
        result = self.engine.evaluate(call)
        assert result.action == PolicyAction.BLOCK

    def test_blocks_path_traversal(self):
        call = ToolCall(tool_name="read_file", arguments={"path": "../../etc/passwd"})
        result = self.engine.evaluate(call)
        assert result.action == PolicyAction.BLOCK

    def test_allows_safe_file_read(self):
        call = ToolCall(tool_name="read_file", arguments={"path": "/project/src/main.py"})
        result = self.engine.evaluate(call)
        assert result.action == PolicyAction.ALLOW

    def test_alerts_on_shell(self):
        call = ToolCall(tool_name="bash", arguments={"cmd": "ls -la"})
        result = self.engine.evaluate(call)
        assert result.action == PolicyAction.ALERT

    def test_defense_profile_stricter(self):
        engine = PolicyEngine(profile="defense")
        call = ToolCall(tool_name="bash", arguments={"cmd": "ls"})
        result = engine.evaluate(call)
        assert result.action == PolicyAction.BLOCK

    def test_custom_rule_addition(self):
        self.engine.add_rule({
            "name": "test_block_curl",
            "match": {"argument_contains": "curl"},
            "action": "block",
            "severity": "high",
        })
        call = ToolCall(tool_name="bash", arguments={"cmd": "curl http://evil.com"})
        result = self.engine.evaluate(call)
        assert result.action == PolicyAction.BLOCK


# ---------------------------------------------------------------------------
# Audit log tests
# ---------------------------------------------------------------------------

class TestAuditLog:
    def setup_method(self):
        self.audit = AuditLog(":memory:")

    def _make_session(self) -> SessionContext:
        ctx = SessionContext()
        ctx.identity.model_id = "claude-sonnet-4-5"
        ctx.identity.initiated_by = "test"
        ctx.identity.compute_attestation()
        ctx.set_goal("Write unit tests for the auth module")
        self.audit.record_session_start(ctx)
        return ctx

    def test_record_and_retrieve_session(self):
        ctx = self._make_session()
        sessions = self.audit.get_sessions()
        assert len(sessions) == 1
        assert sessions[0]["session_id"] == ctx.identity.session_id

    def test_record_security_event(self):
        ctx = self._make_session()
        ev = SecurityEvent(
            session_id=ctx.identity.session_id,
            event_type=EventType.CREDENTIAL_DETECTED,
            severity=Severity.CRITICAL,
            title="Test event",
            cmmc_controls=["3.13.10"],
            nist_controls=["IA-5"],
        )
        self.audit.record_event(ev)
        events = self.audit.get_recent_events()
        assert len(events) == 1
        assert events[0]["title"] == "Test event"

    def test_stats_accuracy(self):
        ctx = self._make_session()
        ev = SecurityEvent(
            session_id=ctx.identity.session_id,
            event_type=EventType.CREDENTIAL_DETECTED,
            severity=Severity.CRITICAL,
            title="critical event",
        )
        self.audit.record_event(ev)
        stats = self.audit.get_stats()
        assert stats["total_sessions"] == 1
        assert stats["critical_events"] == 1

    def test_close_session(self):
        ctx = self._make_session()
        self.audit.close_session(ctx.identity.session_id)
        sessions = self.audit.get_sessions()
        assert sessions[0]["is_active"] == False

    def test_filter_by_severity(self):
        ctx = self._make_session()
        for sev in [Severity.CRITICAL, Severity.LOW, Severity.INFO]:
            self.audit.record_event(SecurityEvent(
                session_id=ctx.identity.session_id,
                event_type=EventType.TOOL_CALL,
                severity=sev,
                title=f"{sev.value} event",
            ))
        critical_events = self.audit.get_recent_events(severity="critical")
        assert len(critical_events) == 1


# ---------------------------------------------------------------------------
# Agent identity / attestation tests
# ---------------------------------------------------------------------------

class TestAgentIdentity:
    def test_attestation_hash_is_deterministic(self):
        identity = AgentIdentity(
            session_id="test-123",
            model_id="claude-sonnet-4-5",
            system_prompt_hash="abc",
            initiated_by="will",
            timestamp=1000.0,
        )
        h1 = identity.compute_attestation()
        h2 = identity.compute_attestation()
        assert h1 == h2
        assert len(h1) == 64  # SHA-256 hex

    def test_different_models_different_hash(self):
        i1 = AgentIdentity(session_id="s1", model_id="model-a", timestamp=1000.0)
        i2 = AgentIdentity(session_id="s1", model_id="model-b", timestamp=1000.0)
        assert i1.compute_attestation() != i2.compute_attestation()


# ---------------------------------------------------------------------------
# Proxy pipeline integration test
# ---------------------------------------------------------------------------

class TestProxyPipeline:
    @pytest.mark.asyncio
    async def test_safe_call_passes(self):
        from aiglos_core.proxy import MCPMessageInterceptor, SessionRegistry
        config = __import__("aiglos_core.types", fromlist=["ProxyConfig"]).ProxyConfig()
        audit = AuditLog(":memory:")
        policy = PolicyEngine()
        registry = SessionRegistry()
        ctx = registry.create()
        audit.record_session_start(ctx)

        interceptor = MCPMessageInterceptor(config, audit, policy, ctx, [])
        msg = json.dumps({
            "jsonrpc": "2.0", "id": "1", "method": "tools/call",
            "params": {"name": "read_file", "arguments": {"path": "/project/main.py"}}
        })
        _, should_forward = await interceptor.process_client_message(msg)
        assert should_forward is True

    @pytest.mark.asyncio
    async def test_policy_violation_blocks(self):
        from aiglos_core.proxy import MCPMessageInterceptor, SessionRegistry
        config = __import__("aiglos_core.types", fromlist=["ProxyConfig"]).ProxyConfig()
        audit = AuditLog(":memory:")
        policy = PolicyEngine()
        registry = SessionRegistry()
        ctx = registry.create()
        audit.record_session_start(ctx)

        interceptor = MCPMessageInterceptor(config, audit, policy, ctx, [])
        msg = json.dumps({
            "jsonrpc": "2.0", "id": "2", "method": "tools/call",
            "params": {"name": "bash", "arguments": {"command": "sudo rm -rf /"}}
        })
        response, should_forward = await interceptor.process_client_message(msg)
        assert should_forward is False
        resp = json.loads(response)
        assert "error" in resp
