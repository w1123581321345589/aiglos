"""
Tests for Aiglos CMMC Compliance Mapper (T13/T14).
"""
from __future__ import annotations

import json
import pytest

from aiglos_core.compliance import (
    CMMCComplianceMapper,
    CMMCLevel,
    ComplianceReport,
    COVERED_CONTROLS,
    CONTROLS_BY_ID,
    EVENT_CONTROL_MAP,
    SECTION_1513_REQUIREMENTS,
    build_compliance_report,
    enrich_event,
)
from aiglos_core.types import EventType, SecurityEvent, Severity


def make_event(
    event_type: EventType = EventType.TOOL_CALL,
    severity: Severity = Severity.INFO,
    cmmc: list[str] | None = None,
    nist: list[str] | None = None,
) -> SecurityEvent:
    return SecurityEvent(
        event_type=event_type,
        severity=severity,
        title=f"Test {event_type.value}",
        cmmc_controls=cmmc or [],
        nist_controls=nist or [],
    )


class TestControlDefinitions:

    def test_all_covered_controls_have_required_fields(self):
        for ctrl in COVERED_CONTROLS:
            assert ctrl.control_id, f"Missing control_id"
            assert ctrl.family, f"Missing family for {ctrl.control_id}"
            assert ctrl.title, f"Missing title for {ctrl.control_id}"
            assert ctrl.nist_equivalent, f"Missing NIST equivalent for {ctrl.control_id}"
            assert ctrl.aiglos_feature, f"Missing feature for {ctrl.control_id}"

    def test_control_ids_are_unique(self):
        ids = [c.control_id for c in COVERED_CONTROLS]
        assert len(ids) == len(set(ids)), "Duplicate control IDs found"

    def test_controls_by_id_lookup(self):
        ctrl = CONTROLS_BY_ID.get("3.1.1")
        assert ctrl is not None
        assert ctrl.family == "Access Control"
        assert ctrl.nist_equivalent == "AC-2"

    def test_all_event_types_map_to_valid_controls(self):
        for event_type, ctrl_ids in EVENT_CONTROL_MAP.items():
            for ctrl_id in ctrl_ids:
                assert ctrl_id in CONTROLS_BY_ID, (
                    f"Event type {event_type} maps to unknown control {ctrl_id}"
                )

    def test_section_1513_requirements_complete(self):
        assert len(SECTION_1513_REQUIREMENTS) >= 8
        for req in SECTION_1513_REQUIREMENTS:
            assert "requirement" in req
            assert "category" in req
            assert "aiglos_implementation" in req


class TestEventEnrichment:

    def test_enriches_tool_call_event(self):
        ev = make_event(EventType.TOOL_CALL)
        enriched = enrich_event(ev)
        assert "3.3.1" in enriched.cmmc_controls
        assert "AU-2" in enriched.nist_controls

    def test_enriches_credential_detected(self):
        ev = make_event(EventType.CREDENTIAL_DETECTED)
        enriched = enrich_event(ev)
        assert "3.13.10" in enriched.cmmc_controls or "3.13.16" in enriched.cmmc_controls
        assert len(enriched.nist_controls) > 0

    def test_enriches_goal_drift(self):
        ev = make_event(EventType.GOAL_DRIFT)
        enriched = enrich_event(ev)
        assert "3.13.3" in enriched.cmmc_controls
        assert "3.14.7" in enriched.cmmc_controls

    def test_enriches_command_injection(self):
        ev = make_event(EventType.COMMAND_INJECTION, Severity.CRITICAL)
        enriched = enrich_event(ev)
        assert "3.14.2" in enriched.cmmc_controls
        assert "SI-3" in enriched.nist_controls

    def test_does_not_overwrite_existing_controls(self):
        ev = make_event(EventType.TOOL_CALL, cmmc=["3.1.1"], nist=["AC-2"])
        enriched = enrich_event(ev)
        assert "3.1.1" in enriched.cmmc_controls
        assert "AC-2" in enriched.nist_controls

    def test_enriches_session_events(self):
        for et in [EventType.SESSION_START, EventType.SESSION_END, EventType.AGENT_ATTESTED]:
            ev = make_event(et)
            enriched = enrich_event(ev)
            assert len(enriched.cmmc_controls) > 0


class TestComplianceReport:

    def setup_method(self):
        self.mapper = CMMCComplianceMapper()

    def _make_events(self, types: list[EventType]) -> list[SecurityEvent]:
        events = []
        for et in types:
            ev = make_event(et)
            self.mapper.enrich_event(ev)
            events.append(ev)
        return events

    def test_report_produced(self):
        events = self._make_events([
            EventType.SESSION_START, EventType.TOOL_CALL, EventType.SESSION_END
        ])
        report = self.mapper.build_report(events)
        assert report.report_id
        assert report.generated_at
        assert report.total_controls_applicable > 0

    def test_report_coverage_increases_with_more_events(self):
        few_events = self._make_events([EventType.SESSION_START])
        many_events = self._make_events([
            EventType.SESSION_START, EventType.TOOL_CALL,
            EventType.CREDENTIAL_DETECTED, EventType.POLICY_VIOLATION,
            EventType.GOAL_DRIFT, EventType.AGENT_ATTESTED,
            EventType.COMMAND_INJECTION, EventType.SESSION_END,
        ] * 5)
        report_few = self.mapper.build_report(few_events)
        report_many = self.mapper.build_report(many_events)
        assert report_many.controls_covered >= report_few.controls_covered

    def test_level_1_has_fewer_controls_than_level_2(self):
        events = self._make_events([EventType.SESSION_START, EventType.TOOL_CALL])
        r1 = self.mapper.build_report(events, cmmc_level=CMMCLevel.LEVEL_1)
        r2 = self.mapper.build_report(events, cmmc_level=CMMCLevel.LEVEL_2)
        assert r1.total_controls_applicable <= r2.total_controls_applicable

    def test_coverage_pct_between_0_and_100(self):
        events = self._make_events([EventType.SESSION_START])
        report = self.mapper.build_report(events)
        assert 0.0 <= report.overall_coverage_pct <= 100.0

    def test_all_control_families_represented(self):
        events = self._make_events([
            EventType.SESSION_START, EventType.TOOL_CALL,
            EventType.CREDENTIAL_DETECTED, EventType.COMMAND_INJECTION,
            EventType.POLICY_VIOLATION, EventType.GOAL_DRIFT,
            EventType.AGENT_ATTESTED,
        ])
        report = self.mapper.build_report(events)
        families = {e["family"] for e in report.control_coverage}
        expected = {"Access Control", "Audit and Accountability", "System and Information Integrity"}
        assert expected.issubset(families)

    def test_control_coverage_entries_have_required_fields(self):
        events = self._make_events([EventType.SESSION_START])
        report = self.mapper.build_report(events)
        for entry in report.control_coverage:
            assert "control_id" in entry
            assert "status" in entry
            assert entry["status"] in ("covered", "partial", "not_covered")
            assert "evidence_count" in entry
            assert "aiglos_feature" in entry

    def test_critical_events_counted(self):
        events = self._make_events([EventType.CREDENTIAL_DETECTED])
        events[0].severity = Severity.CRITICAL
        report = self.mapper.build_report(events)
        assert report.critical_events == 1

    def test_attestations_counted(self):
        events = self._make_events([
            EventType.AGENT_ATTESTED, EventType.AGENT_ATTESTED
        ])
        report = self.mapper.build_report(events)
        assert report.attestations_issued == 2

    def test_section_1513_all_active(self):
        events = self._make_events([EventType.SESSION_START])
        report = self.mapper.build_report(events)
        assert report.section_1513_total == len(SECTION_1513_REQUIREMENTS)
        assert report.section_1513_active_count == report.section_1513_total
        for item in report.section_1513_readiness:
            assert item["status"] == "active"
            assert item["aiglos_implementation"]

    def test_gaps_populated_on_critical_events(self):
        events = self._make_events([EventType.CREDENTIAL_DETECTED])
        events[0].severity = Severity.CRITICAL
        report = self.mapper.build_report(events)
        assert any("CRITICAL" in g for g in report.gaps)

    def test_to_json_is_valid(self):
        events = self._make_events([EventType.SESSION_START, EventType.TOOL_CALL])
        report = self.mapper.build_report(events)
        parsed = json.loads(report.to_json())
        assert "cmmc_assessment" in parsed
        assert "control_coverage" in parsed
        assert "section_1513_readiness" in parsed
        assert "evidence_summary" in parsed

    def test_family_summary_populated(self):
        events = self._make_events([
            EventType.SESSION_START, EventType.CREDENTIAL_DETECTED
        ])
        report = self.mapper.build_report(events)
        assert len(report.family_summary) > 0
        for fam, counts in report.family_summary.items():
            assert "total" in counts
            assert counts["total"] > 0

    def test_convenience_function_matches_class(self):
        events = self._make_events([EventType.SESSION_START])
        r1 = self.mapper.build_report(events)
        r2 = build_compliance_report(events)
        assert r1.total_controls_applicable == r2.total_controls_applicable
        assert len(r1.control_coverage) == len(r2.control_coverage)

    def test_empty_events_produces_valid_report(self):
        report = self.mapper.build_report([])
        assert report.total_events == 0
        assert report.overall_coverage_pct == 0.0
        assert report.controls_covered == 0
        is_valid_json = json.loads(report.to_json())
        assert is_valid_json

    def test_high_coverage_scenario(self):
        """Full event spectrum should cover most controls."""
        all_event_types = list(EventType)
        events = []
        for et in all_event_types:
            for _ in range(4):   # 4 events each -> "covered" threshold
                ev = make_event(et)
                self.mapper.enrich_event(ev)
                events.append(ev)
        report = self.mapper.build_report(events)
        # Should cover most controls
        assert report.overall_coverage_pct >= 60.0
