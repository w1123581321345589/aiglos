"""
Tests for Aiglos Compliance PDF Report Generator (T19).
"""
from __future__ import annotations

import io
import time
import struct
import pytest
from pathlib import Path

from aiglos_core.compliance.report_pdf import (
    ControlEntry,
    EventSummary,
    ReportData,
    S1513Entry,
    build_report_data,
    generate_pdf,
    generate_pdf_bytes,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def minimal_data():
    return ReportData(
        organization="ACME Defense LLC",
        deployment_tier="cloud",
        cmmc_level=2,
        generated_at=time.time(),
        controls=[
            ControlEntry("3.1.1", "Access Control (AC)", "Authorized Access Control", "covered", 50),
            ControlEntry("3.3.1", "Audit and Accountability (AU)", "System Auditing", "covered", 200),
            ControlEntry("3.14.1", "System and Information Integrity (SI)", "Flaw Remediation", "partial", 5),
        ],
        s1513_items=[
            S1513Entry("AI system identity tracking", "active", "Attestation module"),
            S1513Entry("Goal drift monitoring", "active", "Goal Integrity Engine"),
            S1513Entry("Credential protection", "active", "Credential Scanner"),
        ],
        event_summary=EventSummary(
            total_events=247,
            by_severity={"critical": 3, "high": 18, "medium": 44, "low": 12, "info": 170},
            by_type={"credential_detected": 3, "policy_violation": 18, "tool_call": 170},
            sessions_analyzed=42,
            total_tool_calls=1800,
            blocked_calls=21,
        ),
    )


@pytest.fixture
def full_data():
    return build_report_data(
        organization="Lockwood Aerospace Systems",
        deployment_tier="on_prem",
        cmmc_level=2,
        period_days=30,
        event_summary=EventSummary(
            total_events=512,
            by_severity={"critical": 2, "high": 45, "medium": 130, "low": 80, "info": 255},
            by_type={"credential_detected": 2, "goal_drift": 12, "policy_violation": 33},
            sessions_analyzed=88,
            total_tool_calls=4400,
            blocked_calls=35,
        ),
        affirming_official="Col. J. Henderson",
        attestation_key_fingerprint="a1b2c3d4e5f6",
    )


# ---------------------------------------------------------------------------
# PDF generation tests
# ---------------------------------------------------------------------------

class TestPdfGeneration:

    def test_generate_pdf_creates_file(self, tmp_path, minimal_data):
        out = str(tmp_path / "report.pdf")
        generate_pdf(minimal_data, out)
        assert Path(out).exists()

    def test_generated_file_is_nonzero(self, tmp_path, minimal_data):
        out = str(tmp_path / "report.pdf")
        generate_pdf(minimal_data, out)
        assert Path(out).stat().st_size > 1000

    def test_generate_pdf_bytes_returns_bytes(self, minimal_data):
        result = generate_pdf_bytes(minimal_data)
        assert isinstance(result, bytes)
        assert len(result) > 1000

    def test_pdf_magic_bytes(self, minimal_data):
        """PDF files start with %PDF-"""
        pdf_bytes = generate_pdf_bytes(minimal_data)
        assert pdf_bytes[:5] == b"%PDF-"

    def test_full_data_generates(self, tmp_path, full_data):
        out = str(tmp_path / "full_report.pdf")
        generate_pdf(full_data, out)
        assert Path(out).exists()
        assert Path(out).stat().st_size > 5000

    def test_no_controls_does_not_crash(self, tmp_path):
        data = ReportData(
            organization="Empty Org",
            controls=[],
            s1513_items=[],
            event_summary=EventSummary(),
        )
        out = str(tmp_path / "empty.pdf")
        generate_pdf(data, out)
        assert Path(out).exists()

    def test_critical_events_generate(self, tmp_path):
        data = ReportData(
            organization="Critical Org",
            controls=[
                ControlEntry("3.1.1", "AC", "Title", "covered", 5),
            ],
            s1513_items=[S1513Entry("Req 1", "active")],
            event_summary=EventSummary(
                total_events=10,
                by_severity={"critical": 5, "high": 5},
            ),
        )
        out = str(tmp_path / "critical.pdf")
        generate_pdf(data, out)
        assert Path(out).exists()

    def test_all_statuses_generate(self, tmp_path):
        data = ReportData(
            organization="Status Test",
            controls=[
                ControlEntry("3.1.1", "AC", "Title A", "covered", 10),
                ControlEntry("3.1.2", "AC", "Title B", "partial", 3),
                ControlEntry("3.1.3", "AC", "Title C", "not_covered", 0),
            ],
            s1513_items=[
                S1513Entry("Req 1", "active"),
                S1513Entry("Req 2", "inactive"),
                S1513Entry("Req 3", "partial"),
            ],
            event_summary=EventSummary(total_events=20),
        )
        out = str(tmp_path / "statuses.pdf")
        generate_pdf(data, out)
        assert Path(out).exists()

    def test_gov_tier_generates(self, tmp_path):
        data = build_report_data("Pentagon Contractor", deployment_tier="gov")
        out = str(tmp_path / "gov_report.pdf")
        generate_pdf(data, out)
        assert Path(out).exists()


# ---------------------------------------------------------------------------
# build_report_data tests
# ---------------------------------------------------------------------------

class TestBuildReportData:

    def test_returns_report_data(self):
        data = build_report_data("Test Corp")
        assert isinstance(data, ReportData)

    def test_organization_set(self):
        data = build_report_data("Raytheon Dynamics")
        assert data.organization == "Raytheon Dynamics"

    def test_has_17_controls(self):
        data = build_report_data("Test Corp")
        assert len(data.controls) == 17

    def test_has_10_s1513_items(self):
        data = build_report_data("Test Corp")
        assert len(data.s1513_items) == 10

    def test_all_s1513_items_active(self):
        data = build_report_data("Test Corp")
        for item in data.s1513_items:
            assert item.status == "active"

    def test_assessment_period_set(self):
        data = build_report_data("Test Corp", period_days=30)
        assert data.assessment_period_start is not None
        assert data.assessment_period_end is not None
        period = data.assessment_period_end - data.assessment_period_start
        assert abs(period - 30 * 86400) < 60  # within 1 minute

    def test_event_summary_passed_through(self):
        ev = EventSummary(total_events=999, sessions_analyzed=55)
        data = build_report_data("Test Corp", event_summary=ev)
        assert data.event_summary.total_events == 999
        assert data.event_summary.sessions_analyzed == 55

    def test_affirming_official_stored(self):
        data = build_report_data("Test Corp", affirming_official="Gen. Smith")
        assert data.affirming_official == "Gen. Smith"

    def test_deployment_tier_stored(self):
        for tier in ["cloud", "on_prem", "gov"]:
            data = build_report_data("Test Corp", deployment_tier=tier)
            assert data.deployment_tier == tier

    def test_most_controls_covered(self):
        data = build_report_data("Test Corp")
        covered = sum(1 for c in data.controls if c.status == "covered")
        assert covered >= 14  # At least 14 of 17 covered

    def test_all_controls_have_family(self):
        data = build_report_data("Test Corp")
        for ctrl in data.controls:
            assert ctrl.family != ""

    def test_all_s1513_items_have_evidence(self):
        data = build_report_data("Test Corp")
        for item in data.s1513_items:
            assert item.evidence != ""


# ---------------------------------------------------------------------------
# ControlEntry and EventSummary tests
# ---------------------------------------------------------------------------

class TestDataStructures:

    def test_control_entry_fields(self):
        ctrl = ControlEntry("3.1.1", "AC", "Title", "covered", 42)
        assert ctrl.control_id == "3.1.1"
        assert ctrl.status == "covered"
        assert ctrl.evidence_count == 42

    def test_event_summary_defaults(self):
        ev = EventSummary()
        assert ev.total_events == 0
        assert ev.by_severity == {}
        assert ev.sessions_analyzed == 0

    def test_s1513_entry_fields(self):
        item = S1513Entry("Audit requirement", "active", "Audit log module")
        assert item.requirement == "Audit requirement"
        assert item.status == "active"
        assert item.evidence == "Audit log module"
