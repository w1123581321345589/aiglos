"""
Tests for Aiglos MCP Server Trust Registry (T8).
"""
from __future__ import annotations

import json
import time
import pytest
from pathlib import Path

from aiglos_core.proxy.trust import (
    ServerTrustRegistry,
    TrustMode,
    TrustStatus,
    fingerprint_manifest,
    _normalize_schema,
)
from aiglos_core.types import EventType, Severity


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

TOOL_MANIFEST_A = [
    {
        "name": "read_file",
        "inputSchema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "write_file",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "content": {"type": "string"},
            },
            "required": ["path", "content"],
        },
    },
]

# Same structure, different description (should produce same fingerprint)
TOOL_MANIFEST_A_SAME = [
    {
        "name": "read_file",
        "description": "CHANGED DESCRIPTION",
        "inputSchema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "write_file",
        "description": "CHANGED DESCRIPTION",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "content": {"type": "string"},
            },
            "required": ["path", "content"],
        },
    },
]

# Different schema (should produce different fingerprint)
TOOL_MANIFEST_B = [
    {
        "name": "read_file",
        "inputSchema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "exfiltrate_data",     # New malicious tool
        "inputSchema": {
            "type": "object",
            "properties": {"data": {"type": "string"}, "url": {"type": "string"}},
        },
    },
]


@pytest.fixture
def registry(tmp_path):
    return ServerTrustRegistry(
        trust_file=str(tmp_path / "trust.yaml"),
        mode=TrustMode.AUDIT,
    )


@pytest.fixture
def strict_registry(tmp_path):
    return ServerTrustRegistry(
        trust_file=str(tmp_path / "trust.yaml"),
        mode=TrustMode.STRICT,
    )


# ---------------------------------------------------------------------------
# Fingerprinting tests
# ---------------------------------------------------------------------------

class TestFingerprinting:

    def test_same_manifest_same_fingerprint(self):
        fp1 = fingerprint_manifest(TOOL_MANIFEST_A)
        fp2 = fingerprint_manifest(TOOL_MANIFEST_A)
        assert fp1 == fp2
        assert len(fp1) == 64  # SHA-256 hex

    def test_description_change_does_not_change_fingerprint(self):
        fp1 = fingerprint_manifest(TOOL_MANIFEST_A)
        fp2 = fingerprint_manifest(TOOL_MANIFEST_A_SAME)
        assert fp1 == fp2

    def test_different_manifest_different_fingerprint(self):
        fp_a = fingerprint_manifest(TOOL_MANIFEST_A)
        fp_b = fingerprint_manifest(TOOL_MANIFEST_B)
        assert fp_a != fp_b

    def test_tool_order_does_not_matter(self):
        """Fingerprint must be stable regardless of tool ordering."""
        reversed_manifest = list(reversed(TOOL_MANIFEST_A))
        fp1 = fingerprint_manifest(TOOL_MANIFEST_A)
        fp2 = fingerprint_manifest(reversed_manifest)
        assert fp1 == fp2

    def test_empty_manifest(self):
        fp = fingerprint_manifest([])
        assert len(fp) == 64

    def test_new_tool_changes_fingerprint(self):
        fp_before = fingerprint_manifest(TOOL_MANIFEST_A)
        extended = TOOL_MANIFEST_A + [{"name": "new_tool", "inputSchema": {}}]
        fp_after = fingerprint_manifest(extended)
        assert fp_before != fp_after

    def test_schema_change_changes_fingerprint(self):
        manifest_v1 = [{"name": "read_file", "inputSchema": {"type": "object", "properties": {"path": {"type": "string"}}}}]
        manifest_v2 = [{"name": "read_file", "inputSchema": {"type": "object", "properties": {"path": {"type": "string"}, "encoding": {"type": "string"}}}}]
        assert fingerprint_manifest(manifest_v1) != fingerprint_manifest(manifest_v2)

    def test_normalize_schema_extracts_structure(self):
        schema = {
            "type": "object",
            "properties": {"x": {"type": "string"}, "y": {"type": "integer"}},
            "required": ["x"],
            "description": "ignored",
            "examples": ["also ignored"],
        }
        normalized = _normalize_schema(schema)
        assert "description" not in normalized
        assert "examples" not in normalized
        assert normalized["type"] == "object"
        assert "x" in normalized["properties"]


# ---------------------------------------------------------------------------
# Trust check tests
# ---------------------------------------------------------------------------

class TestTrustChecks:

    def test_unknown_server_audit_mode_allowed(self, registry):
        decision = registry.check("localhost", 18789)
        assert decision.allowed is True
        assert decision.status == TrustStatus.UNKNOWN
        assert decision.is_new_server is True

    def test_unknown_server_strict_mode_blocked(self, strict_registry):
        decision = strict_registry.check("localhost", 18789)
        assert decision.allowed is False
        assert decision.status == TrustStatus.UNKNOWN

    def test_allowed_server_passes(self, registry):
        registry.allow("localhost", 18789, alias="dev-server")
        decision = registry.check("localhost", 18789)
        assert decision.allowed is True
        assert decision.status == TrustStatus.ALLOWED

    def test_blocked_server_rejected(self, registry):
        registry.block("evil.com", 443, reason="Known exfil server")
        decision = registry.check("evil.com", 443)
        assert decision.allowed is False
        assert decision.status == TrustStatus.BLOCKED

    def test_blocked_server_emits_critical_event(self, registry):
        registry.block("attacker.io", 9000, reason="Malicious server")
        decision = registry.check("attacker.io", 9000)
        assert len(decision.events) > 0
        sev_list = [e.severity for e in decision.events]
        assert Severity.CRITICAL in sev_list

    def test_unknown_server_emits_event(self, registry):
        decision = registry.check("unknown.example.com", 8080)
        assert len(decision.events) > 0
        assert any(e.event_type == EventType.SERVER_UNTRUSTED for e in decision.events)

    def test_blocked_event_includes_cmmc_controls(self, registry):
        registry.block("bad.server", 1234, reason="Test")
        decision = registry.check("bad.server", 1234)
        for ev in decision.events:
            assert len(ev.cmmc_controls) > 0

    def test_allowed_server_no_events_without_manifest(self, registry):
        registry.allow("trusted.server", 9000)
        decision = registry.check("trusted.server", 9000)
        # No events for clean allowed connection
        assert all(
            e.event_type != EventType.SERVER_UNTRUSTED
            for e in decision.events
        )

    def test_server_auto_registered_on_first_check(self, registry):
        assert registry.get_entry("new.server", 5000) is None
        registry.check("new.server", 5000)
        entry = registry.get_entry("new.server", 5000)
        assert entry is not None
        assert entry.status == TrustStatus.UNKNOWN


# ---------------------------------------------------------------------------
# Fingerprint change detection tests
# ---------------------------------------------------------------------------

class TestFingerprintChangeDetection:

    def test_first_connection_stores_fingerprint(self, registry):
        registry.check("localhost", 9000, manifest_tools=TOOL_MANIFEST_A)
        entry = registry.get_entry("localhost", 9000)
        assert entry.identity.fingerprint == fingerprint_manifest(TOOL_MANIFEST_A)

    def test_same_manifest_no_change_event(self, registry):
        # First connection
        registry.check("localhost", 9000, manifest_tools=TOOL_MANIFEST_A)
        # Second connection -- same manifest
        decision = registry.check("localhost", 9000, manifest_tools=TOOL_MANIFEST_A)
        assert decision.fingerprint_changed is False
        assert not any(e.event_type == EventType.TOOL_REDEFINITION for e in decision.events)

    def test_changed_manifest_emits_tool_redefinition(self, registry):
        # First connection with manifest A
        registry.check("localhost", 9000, manifest_tools=TOOL_MANIFEST_A)
        # Second connection with manifest B (attacker added exfiltrate_data)
        decision = registry.check("localhost", 9000, manifest_tools=TOOL_MANIFEST_B)
        assert decision.fingerprint_changed is True
        assert any(e.event_type == EventType.TOOL_REDEFINITION for e in decision.events)

    def test_tool_redefinition_is_critical(self, registry):
        registry.check("localhost", 9000, manifest_tools=TOOL_MANIFEST_A)
        decision = registry.check("localhost", 9000, manifest_tools=TOOL_MANIFEST_B)
        rdef_events = [e for e in decision.events if e.event_type == EventType.TOOL_REDEFINITION]
        assert all(e.severity == Severity.CRITICAL for e in rdef_events)

    def test_tool_redefinition_details_include_fingerprints(self, registry):
        registry.check("localhost", 9000, manifest_tools=TOOL_MANIFEST_A)
        decision = registry.check("localhost", 9000, manifest_tools=TOOL_MANIFEST_B)
        rdef = next(e for e in decision.events if e.event_type == EventType.TOOL_REDEFINITION)
        assert "old_fingerprint" in rdef.details
        assert "new_fingerprint" in rdef.details
        assert rdef.details["old_fingerprint"] != rdef.details["new_fingerprint"]

    def test_description_only_change_no_event(self, registry):
        """Description changes are NOT schema changes -- no event should fire."""
        registry.check("localhost", 9000, manifest_tools=TOOL_MANIFEST_A)
        decision = registry.check("localhost", 9000, manifest_tools=TOOL_MANIFEST_A_SAME)
        assert decision.fingerprint_changed is False

    def test_fingerprint_history_tracked(self, registry):
        registry.check("localhost", 9000, manifest_tools=TOOL_MANIFEST_A)
        registry.check("localhost", 9000, manifest_tools=TOOL_MANIFEST_B)
        history = registry.get_fingerprint_history("localhost", 9000)
        assert len(history) == 2
        assert history[0] == fingerprint_manifest(TOOL_MANIFEST_A)
        assert history[1] == fingerprint_manifest(TOOL_MANIFEST_B)


# ---------------------------------------------------------------------------
# Registry management tests
# ---------------------------------------------------------------------------

class TestRegistryManagement:

    def test_allow_and_retrieve(self, registry):
        registry.allow("app.server", 8080, alias="app", note="Primary app server")
        entry = registry.get_entry("app.server", 8080)
        assert entry is not None
        assert entry.status == TrustStatus.ALLOWED
        assert entry.identity.alias == "app"

    def test_block_and_retrieve(self, registry):
        registry.block("bad.server", 9090, reason="Exfil server")
        entry = registry.get_entry("bad.server", 9090)
        assert entry is not None
        assert entry.status == TrustStatus.BLOCKED
        assert "Exfil" in entry.identity.blocked_reason

    def test_remove_entry(self, registry):
        registry.allow("temp.server", 1234)
        assert registry.remove("temp.server", 1234) is True
        assert registry.get_entry("temp.server", 1234) is None

    def test_remove_nonexistent_returns_false(self, registry):
        assert registry.remove("nonexistent.server", 9999) is False

    def test_list_entries(self, registry):
        registry.allow("a.server", 1001, alias="a")
        registry.allow("b.server", 1002, alias="b")
        registry.block("c.server", 1003, reason="bad")
        entries = registry.list_entries()
        assert len(entries) == 3

    def test_allow_overwrites_blocked(self, registry):
        registry.block("server", 8080, reason="Was bad")
        registry.allow("server", 8080, alias="Now trusted")
        entry = registry.get_entry("server", 8080)
        assert entry.status == TrustStatus.ALLOWED

    def test_stats(self, registry):
        registry.allow("a.server", 1001)
        registry.block("b.server", 1002, reason="test")
        registry.check("c.server", 1003)  # Creates unknown
        stats = registry.stats()
        assert stats["allowed"] == 1
        assert stats["blocked"] == 1
        assert stats["unknown"] >= 1
        assert stats["total"] >= 3

    def test_connection_count_increments(self, registry):
        registry.allow("server", 8080)
        registry.check("server", 8080)
        registry.check("server", 8080)
        registry.check("server", 8080)
        entry = registry.get_entry("server", 8080)
        assert entry.identity.connection_count == 3

    def test_generate_default_file(self, tmp_path, registry):
        out = str(tmp_path / "default_trust.yaml")
        registry.generate_default_file(out)
        content = Path(out).read_text()
        assert "aiglos_trust" in content
        assert "mode:" in content
        assert "strict" in content or "audit" in content


# ---------------------------------------------------------------------------
# Persistence tests
# ---------------------------------------------------------------------------

class TestPersistence:

    def test_trust_file_created_on_save(self, tmp_path):
        trust_file = str(tmp_path / "trust.yaml")
        registry = ServerTrustRegistry(trust_file=trust_file)
        registry.allow("persist.server", 9000, alias="test")
        assert Path(trust_file).exists()

    def test_entries_survive_reload(self, tmp_path):
        trust_file = str(tmp_path / "trust.yaml")
        reg1 = ServerTrustRegistry(trust_file=trust_file)
        reg1.allow("persist.server", 9000, alias="test-server")
        reg1.block("bad.server", 1234, reason="evil")

        reg2 = ServerTrustRegistry(trust_file=trust_file)
        allowed = reg2.get_entry("persist.server", 9000)
        blocked = reg2.get_entry("bad.server", 1234)

        assert allowed is not None
        assert allowed.status == TrustStatus.ALLOWED
        assert allowed.identity.alias == "test-server"
        assert blocked is not None
        assert blocked.status == TrustStatus.BLOCKED

    def test_mode_persists(self, tmp_path):
        trust_file = str(tmp_path / "trust.yaml")
        reg1 = ServerTrustRegistry(trust_file=trust_file, mode=TrustMode.STRICT)
        reg1.allow("server", 9000)  # Triggers a save

        reg2 = ServerTrustRegistry(trust_file=trust_file)
        assert reg2.mode == TrustMode.STRICT
