"""
Tests for Aiglos Multi-Agent Trust Fabric (T12).
"""
from __future__ import annotations

import time
import pytest

from aiglos_core.proxy.trust_fabric import (
    AgentTrustFabric,
    DelegationRequest,
    InvocationRequest,
    TrustFabricError,
    VerificationResult,
    _b64url,
    _b64url_decode,
    _deserialize_token,
    _hash_goal,
    _serialize_token,
    TokenClaims,
    TOKEN_TYPE_AGENT,
    TOKEN_TYPE_DELEGATION,
    DEFAULT_TOKEN_TTL,
)
from aiglos_core.types import EventType, Severity


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

SECRET = b"aiglos-test-secret-32-bytes!!"   # 32 bytes
GOAL = "Refactor the authentication module to use OAuth2"
MODEL = "claude-sonnet-4-6"


@pytest.fixture
def fabric(tmp_path):
    return AgentTrustFabric(
        db_path=str(tmp_path / "audit.db"),
        signing_secret=SECRET,
        integrity_threshold=0.25,
    )


def register_agent(fabric, session_id="sess-001", model=MODEL, goal=GOAL):
    return fabric.register_agent(session_id, model, goal)


# ---------------------------------------------------------------------------
# Token serialization tests
# ---------------------------------------------------------------------------

class TestTokenSerialization:

    def test_serialize_deserialize_round_trip(self):
        claims = TokenClaims(
            token_id="tok_abc123",
            token_type=TOKEN_TYPE_AGENT,
            issued_at=time.time(),
            expires_at=time.time() + 300,
            agent_id="agt_xyz",
            model_id=MODEL,
            session_id="sess-001",
            goal_hash="abc12345",
        )
        token_str = _serialize_token(claims, SECRET)
        valid, restored = _deserialize_token(token_str, SECRET)
        assert valid is True
        assert restored is not None
        assert restored.token_id == claims.token_id
        assert restored.agent_id == claims.agent_id
        assert restored.session_id == claims.session_id

    def test_tampered_claims_invalid(self):
        claims = TokenClaims(
            token_id="tok_1",
            token_type=TOKEN_TYPE_AGENT,
            issued_at=time.time(),
            expires_at=time.time() + 300,
            agent_id="agt_1",
            model_id=MODEL,
            session_id="sess-001",
            goal_hash="abc",
        )
        token_str = _serialize_token(claims, SECRET)
        # Tamper with the middle segment
        parts = token_str.split(".")
        import base64
        import json
        tampered_claims = json.loads(base64.urlsafe_b64decode(parts[1] + "=="))
        tampered_claims["aid"] = "evil_agent"
        parts[1] = _b64url(
            json.dumps(tampered_claims, separators=(",", ":")).encode()
        )
        tampered_token = ".".join(parts)
        valid, _ = _deserialize_token(tampered_token, SECRET)
        assert valid is False

    def test_wrong_secret_invalid(self):
        claims = TokenClaims(
            token_id="tok_2",
            token_type=TOKEN_TYPE_AGENT,
            issued_at=time.time(),
            expires_at=time.time() + 300,
            agent_id="agt_2",
            model_id=MODEL,
            session_id="sess-002",
            goal_hash="def",
        )
        token_str = _serialize_token(claims, SECRET)
        wrong_secret = b"wrong-secret-also-32-bytes-long!"
        valid, _ = _deserialize_token(token_str, wrong_secret)
        assert valid is False

    def test_malformed_token_invalid(self):
        valid, claims = _deserialize_token("not.a.valid.token.string", SECRET)
        assert valid is False

    def test_three_part_token(self):
        claims = TokenClaims(
            token_id="tok_3",
            token_type=TOKEN_TYPE_AGENT,
            issued_at=time.time(),
            expires_at=time.time() + 300,
        )
        token_str = _serialize_token(claims, SECRET)
        parts = token_str.split(".")
        assert len(parts) == 3

    def test_expiry_detected(self):
        claims = TokenClaims(
            token_id="tok_exp",
            token_type=TOKEN_TYPE_AGENT,
            issued_at=time.time() - 600,
            expires_at=time.time() - 1,  # already expired
        )
        assert claims.is_expired() is True

    def test_not_expired(self):
        claims = TokenClaims(
            token_id="tok_valid",
            token_type=TOKEN_TYPE_AGENT,
            issued_at=time.time(),
            expires_at=time.time() + 300,
        )
        assert claims.is_expired() is False


# ---------------------------------------------------------------------------
# Registration tests
# ---------------------------------------------------------------------------

class TestRegistration:

    def test_register_returns_token(self, fabric):
        token = register_agent(fabric)
        assert token.token_string != ""
        assert token.claims.token_type == TOKEN_TYPE_AGENT

    def test_registered_agent_stored(self, fabric):
        token = register_agent(fabric, session_id="sess-001")
        agent = fabric.get_agent(token.claims.agent_id)
        assert agent is not None
        assert agent.session_id == "sess-001"
        assert agent.model_id == MODEL

    def test_goal_hash_stored(self, fabric):
        token = register_agent(fabric, goal=GOAL)
        agent = fabric.get_agent(token.claims.agent_id)
        assert agent.goal_hash == _hash_goal(GOAL)

    def test_get_agent_by_session(self, fabric):
        token = register_agent(fabric, session_id="sess-xyz")
        agent = fabric.get_agent_by_session("sess-xyz")
        assert agent is not None
        assert agent.agent_id == token.claims.agent_id

    def test_multiple_agents_registered(self, fabric):
        t1 = register_agent(fabric, session_id="sess-1")
        t2 = register_agent(fabric, session_id="sess-2")
        assert t1.claims.agent_id != t2.claims.agent_id
        assert len(fabric.list_agents()) == 2

    def test_agent_token_initially_valid(self, fabric):
        token = register_agent(fabric)
        assert fabric.is_token_valid(token.claims.token_id) is True


# ---------------------------------------------------------------------------
# Delegation tests
# ---------------------------------------------------------------------------

class TestDelegation:

    def test_delegation_returns_token(self, fabric):
        orch_token = register_agent(fabric, session_id="orch-001")
        subagent_token = register_agent(fabric, session_id="sub-001")

        req = DelegationRequest(
            orchestrator_token=orch_token.token_string,
            recipient_agent_id=subagent_token.claims.agent_id,
            task_description="Analyze the authentication module",
            allowed_tools=["read_file", "search_files"],
        )
        deleg = fabric.request_delegation(req)
        assert deleg.token_string != ""
        assert deleg.claims.token_type == TOKEN_TYPE_DELEGATION

    def test_delegation_binds_recipient(self, fabric):
        orch_token = register_agent(fabric, session_id="orch-001")
        sub_token = register_agent(fabric, session_id="sub-001")

        req = DelegationRequest(
            orchestrator_token=orch_token.token_string,
            recipient_agent_id=sub_token.claims.agent_id,
            task_description="Analyze the module",
            allowed_tools=["read_file"],
        )
        deleg = fabric.request_delegation(req)
        assert deleg.claims.recipient_agent_id == sub_token.claims.agent_id

    def test_delegation_binds_tools(self, fabric):
        orch_token = register_agent(fabric, session_id="orch-001")
        sub_token = register_agent(fabric, session_id="sub-001")

        allowed = ["read_file", "search_files"]
        req = DelegationRequest(
            orchestrator_token=orch_token.token_string,
            recipient_agent_id=sub_token.claims.agent_id,
            task_description="Task",
            allowed_tools=allowed,
        )
        deleg = fabric.request_delegation(req)
        assert set(deleg.claims.allowed_tools) == set(allowed)

    def test_delegation_tracks_depth(self, fabric):
        orch_token = register_agent(fabric, session_id="orch-001")
        sub_token = register_agent(fabric, session_id="sub-001")

        req = DelegationRequest(
            orchestrator_token=orch_token.token_string,
            recipient_agent_id=sub_token.claims.agent_id,
            task_description="Sub-task",
            allowed_tools=["read_file"],
        )
        deleg = fabric.request_delegation(req)
        assert deleg.claims.delegation_depth == 1

    def test_delegation_with_invalid_orchestrator_token_fails(self, fabric):
        sub_token = register_agent(fabric, session_id="sub-001")
        req = DelegationRequest(
            orchestrator_token="not.a.real.token",
            recipient_agent_id=sub_token.claims.agent_id,
            task_description="Task",
            allowed_tools=["read_file"],
        )
        with pytest.raises(TrustFabricError, match="invalid signature"):
            fabric.request_delegation(req)

    def test_delegation_ttl_capped(self, fabric):
        orch_token = register_agent(fabric, session_id="orch-001")
        sub_token = register_agent(fabric, session_id="sub-001")

        req = DelegationRequest(
            orchestrator_token=orch_token.token_string,
            recipient_agent_id=sub_token.claims.agent_id,
            task_description="Task",
            allowed_tools=["read_file"],
            ttl=999999,   # Way too long
        )
        deleg = fabric.request_delegation(req)
        assert deleg.claims.expires_at - deleg.claims.issued_at <= 3600

    def test_delegation_fails_when_orchestrator_compromised(self, fabric):
        orch_token = register_agent(fabric, session_id="orch-001")
        sub_token = register_agent(fabric, session_id="sub-001")
        # Degrade orchestrator integrity below threshold
        fabric.update_integrity_score(orch_token.claims.agent_id, 0.05)

        req = DelegationRequest(
            orchestrator_token=orch_token.token_string,
            recipient_agent_id=sub_token.claims.agent_id,
            task_description="Task",
            allowed_tools=["read_file"],
        )
        with pytest.raises(TrustFabricError, match="integrity too low"):
            fabric.request_delegation(req)

    def test_delegation_depth_limit_enforced(self, fabric):
        """Build a delegation chain up to the limit and verify the next level fails."""
        # Register agents for a deep chain
        tokens = [register_agent(fabric, session_id=f"agent-{i}") for i in range(7)]

        # Build chain manually
        current_token = tokens[0]
        for i in range(1, 6):  # Build depth 1-5
            req = DelegationRequest(
                orchestrator_token=current_token.token_string,
                recipient_agent_id=tokens[i].claims.agent_id,
                task_description=f"Task level {i}",
                allowed_tools=["read_file"],
            )
            current_token = fabric.request_delegation(req)

        # One more should fail
        req = DelegationRequest(
            orchestrator_token=current_token.token_string,
            recipient_agent_id=tokens[6].claims.agent_id,
            task_description="Too deep",
            allowed_tools=["read_file"],
        )
        with pytest.raises(TrustFabricError, match="depth limit"):
            fabric.request_delegation(req)


# ---------------------------------------------------------------------------
# Verification tests
# ---------------------------------------------------------------------------

class TestVerification:

    def _make_delegation(self, fabric, orch_token, sub_agent_id, tools=None):
        req = DelegationRequest(
            orchestrator_token=orch_token.token_string,
            recipient_agent_id=sub_agent_id,
            task_description="Analyze the module",
            allowed_tools=tools or ["read_file", "search_files"],
        )
        return fabric.request_delegation(req)

    def test_valid_invocation_allowed(self, fabric):
        orch = register_agent(fabric, session_id="orch-001")
        sub = register_agent(fabric, session_id="sub-001")
        deleg = self._make_delegation(fabric, orch, sub.claims.agent_id)

        inv = InvocationRequest(
            delegation_token=deleg.token_string,
            agent_id=sub.claims.agent_id,
            tool_name="read_file",
            session_id="sub-001",
        )
        outcome = fabric.verify_invocation(inv)
        assert outcome.result == VerificationResult.OK
        assert outcome.allowed is True

    def test_wrong_recipient_blocked(self, fabric):
        orch = register_agent(fabric, session_id="orch-001")
        sub1 = register_agent(fabric, session_id="sub-001")
        sub2 = register_agent(fabric, session_id="sub-002")
        deleg = self._make_delegation(fabric, orch, sub1.claims.agent_id)

        # Sub2 tries to use a token intended for Sub1
        inv = InvocationRequest(
            delegation_token=deleg.token_string,
            agent_id=sub2.claims.agent_id,  # Wrong agent
            tool_name="read_file",
            session_id="sub-002",
        )
        outcome = fabric.verify_invocation(inv)
        assert outcome.result == VerificationResult.WRONG_RECIPIENT
        assert outcome.allowed is False

    def test_tool_outside_scope_blocked(self, fabric):
        orch = register_agent(fabric, session_id="orch-001")
        sub = register_agent(fabric, session_id="sub-001")
        deleg = self._make_delegation(fabric, orch, sub.claims.agent_id, tools=["read_file"])

        inv = InvocationRequest(
            delegation_token=deleg.token_string,
            agent_id=sub.claims.agent_id,
            tool_name="bash",   # Not in allowed_tools
            session_id="sub-001",
        )
        outcome = fabric.verify_invocation(inv)
        assert outcome.result == VerificationResult.TOOL_NOT_DELEGATED
        assert outcome.allowed is False

    def test_wildcard_tool_allows_any(self, fabric):
        orch = register_agent(fabric, session_id="orch-001")
        sub = register_agent(fabric, session_id="sub-001")
        deleg = self._make_delegation(fabric, orch, sub.claims.agent_id, tools=["*"])

        for tool in ["read_file", "bash", "http_request", "any_tool"]:
            inv = InvocationRequest(
                delegation_token=deleg.token_string,
                agent_id=sub.claims.agent_id,
                tool_name=tool,
                session_id="sub-001",
            )
            outcome = fabric.verify_invocation(inv)
            assert outcome.allowed is True

    def test_revoked_token_blocked(self, fabric):
        orch = register_agent(fabric, session_id="orch-001")
        sub = register_agent(fabric, session_id="sub-001")
        deleg = self._make_delegation(fabric, orch, sub.claims.agent_id)
        fabric.revoke_token(deleg.claims.token_id)

        inv = InvocationRequest(
            delegation_token=deleg.token_string,
            agent_id=sub.claims.agent_id,
            tool_name="read_file",
            session_id="sub-001",
        )
        outcome = fabric.verify_invocation(inv)
        assert outcome.result == VerificationResult.REVOKED
        assert outcome.allowed is False

    def test_invalid_signature_blocked(self, fabric):
        sub = register_agent(fabric, session_id="sub-001")
        inv = InvocationRequest(
            delegation_token="header.claims.badsignature",
            agent_id=sub.claims.agent_id,
            tool_name="read_file",
            session_id="sub-001",
        )
        outcome = fabric.verify_invocation(inv)
        assert outcome.result == VerificationResult.INVALID_SIGNATURE
        assert outcome.allowed is False

    def test_compromised_orchestrator_blocks_invocation(self, fabric):
        orch = register_agent(fabric, session_id="orch-001")
        sub = register_agent(fabric, session_id="sub-001")
        deleg = self._make_delegation(fabric, orch, sub.claims.agent_id)

        # Degrade orchestrator AFTER delegation was issued
        fabric.update_integrity_score(orch.claims.agent_id, 0.05)

        inv = InvocationRequest(
            delegation_token=deleg.token_string,
            agent_id=sub.claims.agent_id,
            tool_name="read_file",
            session_id="sub-001",
        )
        outcome = fabric.verify_invocation(inv)
        assert outcome.result == VerificationResult.ORCHESTRATOR_COMPROMISED
        assert outcome.allowed is False

    def test_security_events_emitted_on_failure(self, fabric):
        orch = register_agent(fabric, session_id="orch-001")
        sub1 = register_agent(fabric, session_id="sub-001")
        sub2 = register_agent(fabric, session_id="sub-002")
        deleg = self._make_delegation(fabric, orch, sub1.claims.agent_id)

        inv = InvocationRequest(
            delegation_token=deleg.token_string,
            agent_id=sub2.claims.agent_id,   # Wrong recipient
            tool_name="read_file",
            session_id="sub-002",
        )
        outcome = fabric.verify_invocation(inv)
        assert len(outcome.events) > 0
        for ev in outcome.events:
            assert ev.event_type == EventType.TRUST_VIOLATION
            assert len(ev.cmmc_controls) > 0

    def test_critical_severity_for_signature_failure(self, fabric):
        inv = InvocationRequest(
            delegation_token="bad.token.here",
            agent_id="some-agent",
            tool_name="read_file",
        )
        outcome = fabric.verify_invocation(inv)
        assert any(ev.severity == Severity.CRITICAL for ev in outcome.events)

    def test_critical_severity_for_wrong_recipient(self, fabric):
        orch = register_agent(fabric, session_id="orch-001")
        sub1 = register_agent(fabric, session_id="sub-001")
        sub2 = register_agent(fabric, session_id="sub-002")
        deleg = self._make_delegation(fabric, orch, sub1.claims.agent_id)

        inv = InvocationRequest(
            delegation_token=deleg.token_string,
            agent_id=sub2.claims.agent_id,
            tool_name="read_file",
        )
        outcome = fabric.verify_invocation(inv)
        assert any(ev.severity == Severity.CRITICAL for ev in outcome.events)

    def test_ok_invocation_emits_no_events(self, fabric):
        orch = register_agent(fabric, session_id="orch-001")
        sub = register_agent(fabric, session_id="sub-001")
        deleg = self._make_delegation(fabric, orch, sub.claims.agent_id)

        inv = InvocationRequest(
            delegation_token=deleg.token_string,
            agent_id=sub.claims.agent_id,
            tool_name="read_file",
        )
        outcome = fabric.verify_invocation(inv)
        assert outcome.allowed is True
        assert outcome.events == []


# ---------------------------------------------------------------------------
# Revocation tests
# ---------------------------------------------------------------------------

class TestRevocation:

    def test_revoke_agent(self, fabric):
        token = register_agent(fabric)
        agent_id = token.claims.agent_id
        assert fabric.revoke_agent(agent_id, reason="Compromised") is True
        agent = fabric.get_agent(agent_id)
        assert agent.is_revoked is True

    def test_revoke_agent_revokes_token(self, fabric):
        token = register_agent(fabric)
        fabric.revoke_agent(token.claims.agent_id)
        assert fabric.is_token_valid(token.claims.token_id) is False

    def test_revoke_token_directly(self, fabric):
        orch = register_agent(fabric, session_id="orch-001")
        sub = register_agent(fabric, session_id="sub-001")
        req = DelegationRequest(
            orchestrator_token=orch.token_string,
            recipient_agent_id=sub.claims.agent_id,
            task_description="Task",
            allowed_tools=["read_file"],
        )
        deleg = fabric.request_delegation(req)
        assert fabric.is_token_valid(deleg.claims.token_id) is True
        fabric.revoke_token(deleg.claims.token_id)
        assert fabric.is_token_valid(deleg.claims.token_id) is False

    def test_revoke_nonexistent_agent_returns_false(self, fabric):
        assert fabric.revoke_agent("nonexistent") is False

    def test_revoke_nonexistent_token_returns_false(self, fabric):
        assert fabric.revoke_token("nonexistent-token-id") is False

    def test_delegation_from_revoked_orchestrator_fails(self, fabric):
        orch = register_agent(fabric, session_id="orch-001")
        sub = register_agent(fabric, session_id="sub-001")
        fabric.revoke_agent(orch.claims.agent_id, reason="Compromised")

        req = DelegationRequest(
            orchestrator_token=orch.token_string,
            recipient_agent_id=sub.claims.agent_id,
            task_description="Task",
            allowed_tools=["read_file"],
        )
        with pytest.raises(TrustFabricError, match="revoked"):
            fabric.request_delegation(req)


# ---------------------------------------------------------------------------
# Integrity score tests
# ---------------------------------------------------------------------------

class TestIntegrityScores:

    def test_update_integrity_score(self, fabric):
        token = register_agent(fabric)
        agent_id = token.claims.agent_id
        fabric.update_integrity_score(agent_id, 0.42)
        agent = fabric.get_agent(agent_id)
        assert abs(agent.integrity_score - 0.42) < 1e-9

    def test_integrity_clamped_0_to_1(self, fabric):
        token = register_agent(fabric)
        agent_id = token.claims.agent_id
        fabric.update_integrity_score(agent_id, 99.0)
        assert fabric.get_agent(agent_id).integrity_score <= 1.0
        fabric.update_integrity_score(agent_id, -5.0)
        assert fabric.get_agent(agent_id).integrity_score >= 0.0

    def test_delegation_blocked_at_threshold(self, fabric):
        orch = register_agent(fabric, session_id="orch-001")
        sub = register_agent(fabric, session_id="sub-001")
        # Score just below threshold -- should fail (0.24 < 0.25)
        fabric.update_integrity_score(orch.claims.agent_id, 0.24)
        req = DelegationRequest(
            orchestrator_token=orch.token_string,
            recipient_agent_id=sub.claims.agent_id,
            task_description="Task",
            allowed_tools=["read_file"],
        )
        with pytest.raises(TrustFabricError, match="integrity too low"):
            fabric.request_delegation(req)

    def test_delegation_allowed_above_threshold(self, fabric):
        orch = register_agent(fabric, session_id="orch-001")
        sub = register_agent(fabric, session_id="sub-001")
        fabric.update_integrity_score(orch.claims.agent_id, 0.5)  # Above 0.25
        req = DelegationRequest(
            orchestrator_token=orch.token_string,
            recipient_agent_id=sub.claims.agent_id,
            task_description="Task",
            allowed_tools=["read_file"],
        )
        deleg = fabric.request_delegation(req)
        assert deleg.claims.token_type == TOKEN_TYPE_DELEGATION


# ---------------------------------------------------------------------------
# Persistence tests
# ---------------------------------------------------------------------------

class TestPersistence:

    def test_agents_survive_restart(self, tmp_path):
        db = str(tmp_path / "audit.db")
        fabric1 = AgentTrustFabric(db_path=db, signing_secret=SECRET)
        token = fabric1.register_agent("sess-001", MODEL, GOAL)
        agent_id = token.claims.agent_id

        fabric2 = AgentTrustFabric(db_path=db, signing_secret=SECRET)
        agent = fabric2.get_agent(agent_id)
        assert agent is not None
        assert agent.session_id == "sess-001"

    def test_revocation_survives_restart(self, tmp_path):
        db = str(tmp_path / "audit.db")
        fabric1 = AgentTrustFabric(db_path=db, signing_secret=SECRET)
        token = fabric1.register_agent("sess-001", MODEL, GOAL)
        fabric1.revoke_agent(token.claims.agent_id)

        fabric2 = AgentTrustFabric(db_path=db, signing_secret=SECRET)
        agent = fabric2.get_agent(token.claims.agent_id)
        assert agent.is_revoked is True

    def test_token_revocation_survives_restart(self, tmp_path):
        db = str(tmp_path / "audit.db")
        fabric1 = AgentTrustFabric(db_path=db, signing_secret=SECRET)
        token = fabric1.register_agent("sess-001", MODEL, GOAL)
        fabric1.revoke_token(token.claims.token_id)

        fabric2 = AgentTrustFabric(db_path=db, signing_secret=SECRET)
        assert fabric2.is_token_valid(token.claims.token_id) is False


# ---------------------------------------------------------------------------
# Stats tests
# ---------------------------------------------------------------------------

class TestStats:

    def test_stats_empty_fabric(self, fabric):
        stats = fabric.stats()
        assert stats["total_agents"] == 0
        assert stats["active_agents"] == 0

    def test_stats_with_agents(self, fabric):
        register_agent(fabric, session_id="s1")
        register_agent(fabric, session_id="s2")
        token = register_agent(fabric, session_id="s3")
        fabric.revoke_agent(token.claims.agent_id)
        stats = fabric.stats()
        assert stats["total_agents"] == 3
        assert stats["active_agents"] == 2
        assert stats["revoked_agents"] == 1
