"""
Tests for Aiglos SIEM Integration and Alert Dispatch (T15).
"""
from __future__ import annotations

import asyncio
import json
import os
import time
import pytest
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

from aiglos_core.integrations import (
    AlertDispatcher,
    AlertDestination,
    DestinationConfig,
    FileSinkConfig,
    FileSinkDestination,
    SlackConfig,
    SlackDestination,
    SplunkConfig,
    SplunkHECDestination,
    SyslogCEFDestination,
    SyslogConfig,
    TokenBucket,
    WebhookConfig,
    WebhookDestination,
    dispatcher_from_config,
    severity_at_least,
)
from aiglos_core.types import EventType, SecurityEvent, Severity


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def make_event(
    severity: Severity = Severity.CRITICAL,
    event_type: EventType = EventType.CREDENTIAL_DETECTED,
) -> SecurityEvent:
    return SecurityEvent(
        session_id="test-session-123",
        event_type=event_type,
        severity=severity,
        title=f"Test {event_type.value}",
        description="Test description for alerting",
        details={"test_key": "test_value"},
        cmmc_controls=["3.13.10"],
        nist_controls=["SC-28"],
    )


# ---------------------------------------------------------------------------
# Utility tests
# ---------------------------------------------------------------------------

class TestSeverityRouting:

    def test_critical_at_least_critical(self):
        assert severity_at_least(Severity.CRITICAL, Severity.CRITICAL)

    def test_critical_at_least_high(self):
        assert severity_at_least(Severity.CRITICAL, Severity.HIGH)

    def test_critical_at_least_info(self):
        assert severity_at_least(Severity.CRITICAL, Severity.INFO)

    def test_info_not_at_least_high(self):
        assert not severity_at_least(Severity.INFO, Severity.HIGH)

    def test_medium_not_at_least_high(self):
        assert not severity_at_least(Severity.MEDIUM, Severity.HIGH)

    def test_high_at_least_high(self):
        assert severity_at_least(Severity.HIGH, Severity.HIGH)


class TestTokenBucket:

    def test_initial_tokens_available(self):
        bucket = TokenBucket(rate=10.0, burst=5)
        assert bucket.consume()

    def test_burst_limit_enforced(self):
        bucket = TokenBucket(rate=0.0, burst=3)  # No refill
        assert bucket.consume()
        assert bucket.consume()
        assert bucket.consume()
        assert not bucket.consume()  # Exhausted

    def test_tokens_refill_over_time(self):
        bucket = TokenBucket(rate=100.0, burst=1)
        bucket.consume()
        time.sleep(0.05)  # 50ms -> ~5 tokens at rate=100/s
        assert bucket.consume()


# ---------------------------------------------------------------------------
# File sink tests (pure I/O, no network needed)
# ---------------------------------------------------------------------------

class TestFileSinkDestination:

    def setup_method(self):
        self.sink_path = "/tmp/cg_test_events.jsonl"
        if Path(self.sink_path).exists():
            Path(self.sink_path).unlink()
        self.dest = FileSinkDestination(FileSinkConfig(
            name="test_sink",
            path=self.sink_path,
            min_severity=Severity.INFO,
            include_all_severities=True,
        ))

    def teardown_method(self):
        if Path(self.sink_path).exists():
            Path(self.sink_path).unlink()

    @pytest.mark.asyncio
    async def test_writes_event_to_file(self):
        event = make_event(Severity.CRITICAL)
        await self.dest.dispatch(event)
        assert Path(self.sink_path).exists()
        line = Path(self.sink_path).read_text().strip()
        record = json.loads(line)
        assert record["event_id"] == event.id
        assert record["severity"] == "critical"

    @pytest.mark.asyncio
    async def test_appends_multiple_events(self):
        for sev in [Severity.CRITICAL, Severity.HIGH, Severity.INFO]:
            await self.dest.dispatch(make_event(sev))
        lines = Path(self.sink_path).read_text().strip().split("\n")
        assert len(lines) == 3

    @pytest.mark.asyncio
    async def test_jsonl_format_each_line_valid(self):
        await self.dest.dispatch(make_event(Severity.HIGH))
        await self.dest.dispatch(make_event(Severity.MEDIUM))
        lines = Path(self.sink_path).read_text().strip().split("\n")
        for line in lines:
            parsed = json.loads(line)
            assert "timestamp" in parsed
            assert "event_type" in parsed
            assert "cmmc_controls" in parsed

    @pytest.mark.asyncio
    async def test_info_events_written_when_include_all(self):
        event = make_event(Severity.INFO)
        result = await self.dest.dispatch(event)
        assert result is True
        assert Path(self.sink_path).exists()

    @pytest.mark.asyncio
    async def test_respects_min_severity_when_set(self):
        dest = FileSinkDestination(FileSinkConfig(
            name="high_only_sink",
            path=self.sink_path,
            min_severity=Severity.HIGH,
            include_all_severities=False,
        ))
        low_event = make_event(Severity.LOW)
        result = await dest.dispatch(low_event)
        assert result is False
        assert not Path(self.sink_path).exists()

    @pytest.mark.asyncio
    async def test_stat_tracking(self):
        await self.dest.dispatch(make_event(Severity.CRITICAL))
        await self.dest.dispatch(make_event(Severity.HIGH))
        stats = self.dest.stats()
        assert stats["sent"] == 2
        assert stats["errors"] == 0


# ---------------------------------------------------------------------------
# Syslog CEF formatting tests
# ---------------------------------------------------------------------------

class TestSyslogCEFFormat:

    def setup_method(self):
        self.dest = SyslogCEFDestination(SyslogConfig(
            name="test_syslog",
            host="127.0.0.1",
            port=9514,  # Non-standard to avoid conflicts
            min_severity=Severity.INFO,
        ))

    def test_cef_format_is_valid(self):
        event = make_event(Severity.CRITICAL, EventType.GOAL_DRIFT)
        cef = self.dest._build_cef(event)
        # Full message has syslog header prefix; CEF payload is embedded within
        assert "CEF:0|Aiglos|" in cef
        assert "AIAgentSecurityRuntime" in cef

    def test_cef_contains_session_id(self):
        event = make_event(Severity.HIGH)
        event.session_id = "abc123-session"
        cef = self.dest._build_cef(event)
        assert "abc123" in cef or "sessionId" in cef

    def test_cef_severity_mapping(self):
        critical_event = make_event(Severity.CRITICAL)
        info_event = make_event(Severity.INFO)
        cef_crit = self.dest._build_cef(critical_event)
        cef_info = self.dest._build_cef(info_event)
        # Severity appears as a field in CEF header (|severity|)
        # Critical should have higher number than info
        assert cef_crit != cef_info

    def test_cef_includes_cmmc_controls(self):
        event = make_event(Severity.HIGH)
        event.cmmc_controls = ["3.13.10", "3.14.2"]
        cef = self.dest._build_cef(event)
        assert "3.13.10" in cef

    def test_syslog_priority_calculated(self):
        event = make_event(Severity.CRITICAL)
        cef = self.dest._build_cef(event)
        # Should start with <priority>
        assert cef.startswith("<")
        priority_end = cef.index(">")
        priority = int(cef[1:priority_end])
        assert 0 <= priority <= 191  # Valid syslog priority range

    def test_goal_drift_details_included(self):
        event = make_event(Severity.HIGH, EventType.GOAL_DRIFT)
        event.details = {"integrity_score": 0.12}
        cef = self.dest._build_cef(event)
        assert "0.120" in cef or "goalIntegrityScore" in cef


# ---------------------------------------------------------------------------
# Slack message formatting tests
# ---------------------------------------------------------------------------

class TestSlackMessageFormat:

    def setup_method(self):
        self.dest = SlackDestination(SlackConfig(
            name="test_slack",
            webhook_url="https://hooks.slack.com/test",
            min_severity=Severity.HIGH,
        ))

    def test_slack_message_has_attachment(self):
        event = make_event(Severity.CRITICAL)
        msg = self.dest._build_message(event)
        assert "attachments" in msg
        assert len(msg["attachments"]) == 1

    def test_slack_color_matches_severity(self):
        crit_event = make_event(Severity.CRITICAL)
        high_event = make_event(Severity.HIGH)
        crit_msg = self.dest._build_message(crit_event)
        high_msg = self.dest._build_message(high_event)
        assert crit_msg["attachments"][0]["color"] != high_msg["attachments"][0]["color"]

    def test_slack_includes_cmmc_controls(self):
        event = make_event(Severity.CRITICAL)
        event.cmmc_controls = ["3.13.10", "3.13.16"]
        msg = self.dest._build_message(event)
        field_titles = [f["title"] for f in msg["attachments"][0]["fields"]]
        assert "CMMC Controls" in field_titles

    def test_slack_includes_goal_integrity_score(self):
        event = make_event(Severity.CRITICAL, EventType.GOAL_DRIFT)
        event.details = {"integrity_score": 0.08}
        msg = self.dest._build_message(event)
        field_titles = [f["title"] for f in msg["attachments"][0]["fields"]]
        assert "Goal Integrity Score" in field_titles

    def test_slack_severity_below_threshold_not_sent(self):
        low_event = make_event(Severity.LOW)
        assert not self.dest.should_send(low_event)

    def test_slack_critical_sent(self):
        crit_event = make_event(Severity.CRITICAL)
        assert self.dest.should_send(crit_event)


# ---------------------------------------------------------------------------
# AlertDispatcher tests
# ---------------------------------------------------------------------------

class TestAlertDispatcher:

    @pytest.mark.asyncio
    async def test_empty_dispatcher_does_not_error(self):
        dispatcher = AlertDispatcher()
        event = make_event(Severity.CRITICAL)
        # Should complete without raising
        await dispatcher.dispatch(event)

    @pytest.mark.asyncio
    async def test_file_sink_receives_all_events(self, tmp_path):
        path = str(tmp_path / "events.jsonl")
        dispatcher = AlertDispatcher()
        dispatcher.add_file_sink(path=path, min_severity=Severity.INFO)

        events = [
            make_event(Severity.CRITICAL),
            make_event(Severity.HIGH),
            make_event(Severity.INFO),
        ]
        for ev in events:
            await dispatcher.dispatch(ev)

        lines = Path(path).read_text().strip().split("\n")
        assert len(lines) == 3

    @pytest.mark.asyncio
    async def test_multiple_destinations_fan_out(self, tmp_path):
        path1 = str(tmp_path / "sink1.jsonl")
        path2 = str(tmp_path / "sink2.jsonl")
        dispatcher = AlertDispatcher()
        dispatcher.add_file_sink(path=path1, min_severity=Severity.INFO)
        dispatcher.add_file_sink(path=path2, min_severity=Severity.INFO)

        await dispatcher.dispatch(make_event(Severity.CRITICAL))

        assert Path(path1).exists()
        assert Path(path2).exists()

    @pytest.mark.asyncio
    async def test_severity_filtering_works(self, tmp_path):
        path_all = str(tmp_path / "all.jsonl")
        path_crit = str(tmp_path / "crit.jsonl")

        dispatcher = AlertDispatcher()
        dispatcher.add_file_sink(path=path_all, min_severity=Severity.INFO)

        crit_dest = FileSinkDestination(FileSinkConfig(
            name="crit_only",
            path=path_crit,
            min_severity=Severity.CRITICAL,
            include_all_severities=False,
        ))
        dispatcher.add_destination(crit_dest)

        await dispatcher.dispatch(make_event(Severity.HIGH))
        await dispatcher.dispatch(make_event(Severity.CRITICAL))

        all_lines = Path(path_all).read_text().strip().split("\n")
        crit_lines = Path(path_crit).read_text().strip().split("\n")
        assert len(all_lines) == 2
        assert len(crit_lines) == 1

    @pytest.mark.asyncio
    async def test_one_destination_error_does_not_stop_others(self, tmp_path):
        """A failing destination should not prevent other destinations from receiving."""
        path = str(tmp_path / "backup.jsonl")

        class FailingDestination(AlertDestination):
            async def _send(self, event):
                raise RuntimeError("Simulated failure")

        dispatcher = AlertDispatcher()
        dispatcher.add_destination(FailingDestination(DestinationConfig(
            name="failing",
            min_severity=Severity.INFO,
        )))
        dispatcher.add_file_sink(path=path, min_severity=Severity.INFO)

        await dispatcher.dispatch(make_event(Severity.CRITICAL))

        # File sink should still have received the event
        assert Path(path).exists()

    @pytest.mark.asyncio
    async def test_callable_interface(self, tmp_path):
        path = str(tmp_path / "events.jsonl")
        dispatcher = AlertDispatcher()
        dispatcher.add_file_sink(path=path, min_severity=Severity.INFO)
        event = make_event(Severity.HIGH)
        await dispatcher(event)  # Call as callable
        assert Path(path).exists()

    def test_stats_summary(self):
        dispatcher = AlertDispatcher()
        summary = dispatcher.summary()
        assert "destinations" in summary
        assert "total_dispatched" in summary
        assert summary["destinations"] == 0

    @pytest.mark.asyncio
    async def test_stats_increment_on_send(self, tmp_path):
        path = str(tmp_path / "events.jsonl")
        dispatcher = AlertDispatcher()
        dispatcher.add_file_sink(path=path, min_severity=Severity.INFO)
        await dispatcher.dispatch(make_event(Severity.CRITICAL))
        await dispatcher.dispatch(make_event(Severity.HIGH))
        summary = dispatcher.summary()
        assert summary["total_dispatched"] == 2


# ---------------------------------------------------------------------------
# dispatcher_from_config factory tests
# ---------------------------------------------------------------------------

class TestDispatcherFactory:

    def test_empty_config_produces_empty_dispatcher(self):
        dispatcher = dispatcher_from_config({})
        assert len(dispatcher._destinations) == 0

    def test_file_sink_added_from_config(self, tmp_path):
        path = str(tmp_path / "events.jsonl")
        config = {
            "alerts": {
                "file_sink": {"path": path, "min_severity": "info"},
            }
        }
        dispatcher = dispatcher_from_config(config)
        assert len(dispatcher._destinations) == 1
        assert dispatcher._destinations[0].config.name == "file_sink"

    def test_multiple_destinations_from_config(self, tmp_path):
        path = str(tmp_path / "events.jsonl")
        config = {
            "alerts": {
                "file_sink": {"path": path},
                "slack": {"webhook_url": "https://hooks.slack.com/test"},
                "webhook": {"url": "https://api.example.com/alert"},
            }
        }
        dispatcher = dispatcher_from_config(config)
        assert len(dispatcher._destinations) == 3

    def test_missing_required_fields_skipped(self):
        config = {
            "alerts": {
                "splunk": {"hec_url": ""},    # No token, no URL
                "slack": {},                   # No webhook_url
                "webhook": {},                 # No url
            }
        }
        dispatcher = dispatcher_from_config(config)
        # None should be added -- missing required fields
        assert len(dispatcher._destinations) == 0

    def test_severity_threshold_respected_from_config(self, tmp_path):
        path = str(tmp_path / "events.jsonl")
        config = {
            "alerts": {
                "file_sink": {"path": path, "min_severity": "critical"},
            }
        }
        dispatcher = dispatcher_from_config(config)
        dest = dispatcher._destinations[0]
        assert dest.config.min_severity == Severity.CRITICAL
