"""
Aiglos OPA (Open Policy Agent) Integration (T11).

Why OPA over YAML rules
-----------------------
The YAML policy engine (T10) handles simple glob patterns well: "block any
bash call containing sudo", "alert on http_request to external domains".
That covers the 80% case and runs at sub-millisecond latency.

OPA handles the other 20%: policies that require context, composition, and
audit trails. Defense contractors need policies like:

  "Block any tool call where:
   - the tool is bash AND
   - the argument contains a network command AND
   - the session has already called read_file on a .env path AND
   - the current session's goal does not include 'network' in its scope"

That rule cannot be expressed as a glob pattern. It requires stateful
reasoning across the session's call history. OPA's Rego language handles
this naturally.

Architecture
------------
Two modes of operation:

  Mode 1: OPA server (recommended for production)
    Aiglos sends each tool call to a running OPA HTTP server at
    http://localhost:8181/v1/data/aiglos/policy/decision.
    OPA evaluates the policy bundle and returns allow/deny with reason.
    Latency: ~2-5ms per call (OPA is fast).
    Benefit: policies can be updated at runtime without restarting Aiglos.

  Mode 2: Embedded evaluation (fallback)
    If OPA server is unavailable, Aiglos falls back to its own Rego
    evaluator for a core set of built-in policies. This uses a pure-Python
    Rego subset interpreter that handles the most critical defense rules:
    - Dangerous command blocking
    - Path traversal detection
    - Credential pattern matching
    - Network exfiltration detection
    This mode has no external dependencies and works in air-gapped environments.

Policy bundle
-------------
Aiglos ships a default policy bundle (policies/aiglos.rego) that
encodes the CMMC Level 2 baseline. The bundle is:
  - Version-controlled (bundle includes a metadata document)
  - Cryptographically signed (HMAC-SHA256 of bundle content)
  - Incrementally updatable (OPA bundle API compatible)

Policy input schema
-------------------
Every tool call evaluation sends:

  {
    "session_id": "sess_abc123",
    "model": "claude-sonnet-4-6",
    "tool_name": "bash",
    "arguments": {"command": "ls -la /etc"},
    "argument_string": "ls -la /etc",      // flattened for text matching
    "call_index": 42,                       // position in session
    "goal_hash": "abc12345",
    "session_tool_history": ["read_file", "read_file", "bash"],
    "session_has_credential_event": false,
    "metadata": {"deployment_tier": "gov"}
  }

Policy output schema
--------------------
  {
    "allow": true|false,
    "action": "allow|block|alert|require_approval",
    "severity": "critical|high|medium|low|info",
    "reason": "Human-readable explanation",
    "rule_name": "The Rego rule that fired",
    "cmmc_controls": ["3.1.1"],
    "nist_controls": ["AC-3"]
  }
"""

from __future__ import annotations

import hashlib
import hmac
import json
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional
import textwrap

import structlog

from aiglos_core.types import PolicyAction, SecurityEvent, EventType, Severity

logger = structlog.get_logger("aiglos.opa")


# ---------------------------------------------------------------------------
# Default CMMC baseline Rego policy
# ---------------------------------------------------------------------------

AIGLOS_DEFAULT_REGO = textwrap.dedent(r"""
# Aiglos CMMC Level 2 Baseline Policy Bundle
# Version: 1.0.0
# Framework: NIST SP 800-171 Rev 2 / CMMC Level 2
#
# Covers: 3.1.1, 3.1.2, 3.13.1, 3.14.2

package aiglos.policy

import future.keywords.if
import future.keywords.in
import future.keywords.every

# Default: allow if no rule fires
default allow = true
default action = "allow"
default severity = "info"
default reason = "No policy rule matched"
default rule_name = "default_allow"
default cmmc_controls = []
default nist_controls = []

# ── Rule definitions ────────────────────────────────────────────────────────

# Block sudo commands (CMMC 3.1.1, 3.1.2)
deny_sudo if {
    input.tool_name in {"bash", "run_command", "shell", "exec"}
    contains(lower(input.argument_string), "sudo")
}

# Block recursive deletion (CMMC 3.13.1)
deny_rm_rf if {
    input.tool_name in {"bash", "run_command", "shell", "exec"}
    regex.match(`rm\s+(-[a-zA-Z]*r[a-zA-Z]*|-r)\s+/`, lower(input.argument_string))
}

# Block path traversal (CMMC 3.1.3)
deny_path_traversal if {
    contains(input.argument_string, "../")
}

deny_path_traversal if {
    contains(input.argument_string, "..\\\\")
}

# Block curl/wget with pipe to shell (supply chain attack pattern)
deny_curl_pipe_shell if {
    input.tool_name in {"bash", "run_command", "shell", "exec"}
    regex.match(`(curl|wget).*(\\||>).*sh`, lower(input.argument_string))
}

# Block access to sensitive system files
deny_sensitive_files if {
    input.tool_name in {"read_file", "bash", "run_command"}
    sensitive_path(input.argument_string)
}

sensitive_path(arg) if { contains(arg, "/etc/shadow") }
sensitive_path(arg) if { contains(arg, "/etc/passwd") }
sensitive_path(arg) if { contains(arg, "id_rsa") }
sensitive_path(arg) if { contains(arg, "id_ed25519") }
sensitive_path(arg) if { contains(arg, ".ssh/") }

# Alert on outbound HTTP (CMMC 3.13.1 -- boundary protection)
alert_outbound_http if {
    input.tool_name in {"http_request", "fetch", "requests", "curl"}
    not contains(lower(input.argument_string), "localhost")
    not contains(lower(input.argument_string), "127.0.0.1")
}

# Alert on git push without review (CMMC 3.1.1)
alert_git_push if {
    input.tool_name == "git"
    contains(lower(input.argument_string), "push")
}

# Alert on tool calls after reading .env or credentials
alert_post_credential_read if {
    input.session_has_credential_event
    input.tool_name in {"http_request", "bash", "run_command"}
}

# ── Decision aggregation ─────────────────────────────────────────────────────

# Compute final decision
allow = false if { deny_sudo }
action = "block" if { deny_sudo }
severity = "critical" if { deny_sudo }
reason = "Command contains sudo -- privilege escalation blocked (CMMC 3.1.1)" if { deny_sudo }
rule_name = "deny_sudo" if { deny_sudo }
cmmc_controls = ["3.1.1", "3.1.2"] if { deny_sudo }
nist_controls = ["AC-2", "AC-3", "AC-6"] if { deny_sudo }

allow = false if { deny_rm_rf }
action = "block" if { deny_rm_rf }
severity = "critical" if { deny_rm_rf }
reason = "Recursive deletion of root-level path blocked (CMMC 3.13.1)" if { deny_rm_rf }
rule_name = "deny_rm_rf" if { deny_rm_rf }
cmmc_controls = ["3.13.1"] if { deny_rm_rf }
nist_controls = ["SC-7"] if { deny_rm_rf }

allow = false if { deny_path_traversal }
action = "block" if { deny_path_traversal }
severity = "high" if { deny_path_traversal }
reason = "Path traversal pattern detected in arguments (CMMC 3.1.3)" if { deny_path_traversal }
rule_name = "deny_path_traversal" if { deny_path_traversal }
cmmc_controls = ["3.1.3"] if { deny_path_traversal }
nist_controls = ["AC-4"] if { deny_path_traversal }

allow = false if { deny_curl_pipe_shell }
action = "block" if { deny_curl_pipe_shell }
severity = "critical" if { deny_curl_pipe_shell }
reason = "Remote code execution pattern: curl/wget piped to shell (CMMC 3.14.2)" if { deny_curl_pipe_shell }
rule_name = "deny_curl_pipe_shell" if { deny_curl_pipe_shell }
cmmc_controls = ["3.14.2"] if { deny_curl_pipe_shell }
nist_controls = ["SI-3"] if { deny_curl_pipe_shell }

allow = false if { deny_sensitive_files }
action = "block" if { deny_sensitive_files }
severity = "critical" if { deny_sensitive_files }
reason = "Attempt to read sensitive system file blocked (CMMC 3.1.1)" if { deny_sensitive_files }
rule_name = "deny_sensitive_files" if { deny_sensitive_files }
cmmc_controls = ["3.1.1", "3.13.1"] if { deny_sensitive_files }
nist_controls = ["AC-3", "SC-7"] if { deny_sensitive_files }

# Alerts (allow=true but raise an event)
action = "alert" if {
    allow
    alert_outbound_http
    not deny_sudo
    not deny_rm_rf
    not deny_path_traversal
    not deny_curl_pipe_shell
    not deny_sensitive_files
}
severity = "medium" if {
    allow
    alert_outbound_http
    not deny_sudo
    not deny_rm_rf
    not deny_path_traversal
    not deny_curl_pipe_shell
    not deny_sensitive_files
}
reason = "Outbound HTTP request detected -- boundary monitoring (CMMC 3.13.1)" if {
    allow
    alert_outbound_http
}
rule_name = "alert_outbound_http" if {
    allow
    alert_outbound_http
}
cmmc_controls = ["3.13.1"] if {
    allow
    alert_outbound_http
}
nist_controls = ["SC-7"] if {
    allow
    alert_outbound_http
}
""")


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class OPADecision:
    """Result of an OPA policy evaluation."""
    allow: bool
    action: PolicyAction
    severity: Severity
    reason: str
    rule_name: str
    cmmc_controls: list[str] = field(default_factory=list)
    nist_controls: list[str] = field(default_factory=list)
    evaluation_ms: float = 0.0
    source: str = "opa_server"  # "opa_server" | "embedded"

    @classmethod
    def allow_default(cls) -> "OPADecision":
        return cls(
            allow=True,
            action=PolicyAction.ALLOW,
            severity=Severity.INFO,
            reason="No OPA rule matched",
            rule_name="default_allow",
            source="embedded",
        )

    def to_security_event(self, session_id: str, tool_name: str) -> Optional[SecurityEvent]:
        """Convert a non-allow decision to a SecurityEvent."""
        if self.action == PolicyAction.ALLOW:
            return None
        return SecurityEvent(
            session_id=session_id,
            event_type=EventType.POLICY_VIOLATION,
            severity=self.severity,
            title=f"OPA policy: {self.rule_name}",
            description=self.reason,
            details={
                "tool": tool_name,
                "rule": self.rule_name,
                "action": self.action.value,
                "source": self.source,
            },
            cmmc_controls=self.cmmc_controls,
            nist_controls=self.nist_controls,
        )


@dataclass
class PolicyBundle:
    """A versioned, signed OPA policy bundle."""
    name: str
    version: str
    rego_content: str
    created_at: float = field(default_factory=time.time)
    signature: str = ""

    def sign(self, secret: bytes) -> None:
        payload = f"{self.name}:{self.version}:{self.rego_content}"
        self.signature = hmac.new(secret, payload.encode(), hashlib.sha256).hexdigest()

    def verify(self, secret: bytes) -> bool:
        payload = f"{self.name}:{self.version}:{self.rego_content}"
        expected = hmac.new(secret, payload.encode(), hashlib.sha256).hexdigest()
        return hmac.compare_digest(expected, self.signature)

    def save(self, path: str) -> None:
        Path(path).write_text(self.rego_content)
        meta_path = path + ".meta.json"
        Path(meta_path).write_text(json.dumps({
            "name": self.name,
            "version": self.version,
            "created_at": self.created_at,
            "signature": self.signature,
        }, indent=2))

    @classmethod
    def load(cls, path: str) -> "PolicyBundle":
        rego = Path(path).read_text()
        meta_path = path + ".meta.json"
        if Path(meta_path).exists():
            meta = json.loads(Path(meta_path).read_text())
        else:
            meta = {"name": "custom", "version": "0.0.0", "created_at": time.time(), "signature": ""}
        return cls(
            name=meta["name"],
            version=meta["version"],
            rego_content=rego,
            created_at=meta["created_at"],
            signature=meta["signature"],
        )


# ---------------------------------------------------------------------------
# Embedded Rego evaluator (pure Python, no OPA binary required)
# ---------------------------------------------------------------------------

class EmbeddedRegoEvaluator:
    """
    Pure-Python evaluator for Aiglos's baseline Rego rules.

    Implements the 8 core rules from AIGLOS_DEFAULT_REGO without
    requiring the OPA binary. Used in air-gapped and offline environments.

    This is not a general Rego interpreter. It specifically evaluates the
    Aiglos baseline rule set with hand-compiled Python logic that
    mirrors the Rego semantics exactly.
    """

    SHELL_TOOLS = {"bash", "run_command", "shell", "exec"}
    HTTP_TOOLS = {"http_request", "fetch", "requests", "curl"}
    SENSITIVE_PATTERNS = [
        "/etc/shadow", "/etc/passwd", "id_rsa", "id_ed25519", ".ssh/"
    ]

    def evaluate(self, input_data: dict) -> OPADecision:
        """Evaluate the baseline policy rules against input_data."""
        tool = input_data.get("tool_name", "")
        arg_str = input_data.get("argument_string", "").lower()
        has_cred_event = input_data.get("session_has_credential_event", False)

        # Rule: deny_sudo
        if tool in self.SHELL_TOOLS and "sudo" in arg_str:
            return OPADecision(
                allow=False,
                action=PolicyAction.BLOCK,
                severity=Severity.CRITICAL,
                reason="Command contains sudo -- privilege escalation blocked (CMMC 3.1.1)",
                rule_name="deny_sudo",
                cmmc_controls=["3.1.1", "3.1.2"],
                nist_controls=["AC-2", "AC-3", "AC-6"],
                source="embedded",
            )

        # Rule: deny_rm_rf
        if tool in self.SHELL_TOOLS and re.search(r"rm\s+(-[a-z]*r[a-z]*|-r)\s+/", arg_str):
            return OPADecision(
                allow=False,
                action=PolicyAction.BLOCK,
                severity=Severity.CRITICAL,
                reason="Recursive deletion of root-level path blocked (CMMC 3.13.1)",
                rule_name="deny_rm_rf",
                cmmc_controls=["3.13.1"],
                nist_controls=["SC-7"],
                source="embedded",
            )

        # Rule: deny_path_traversal
        raw_arg = input_data.get("argument_string", "")
        if "../" in raw_arg or "..\\" in raw_arg:
            return OPADecision(
                allow=False,
                action=PolicyAction.BLOCK,
                severity=Severity.HIGH,
                reason="Path traversal pattern detected in arguments (CMMC 3.1.3)",
                rule_name="deny_path_traversal",
                cmmc_controls=["3.1.3"],
                nist_controls=["AC-4"],
                source="embedded",
            )

        # Rule: deny_curl_pipe_shell
        if tool in self.SHELL_TOOLS and re.search(r"(curl|wget).*(\||>).*sh", arg_str):
            return OPADecision(
                allow=False,
                action=PolicyAction.BLOCK,
                severity=Severity.CRITICAL,
                reason="Remote code execution pattern: curl/wget piped to shell (CMMC 3.14.2)",
                rule_name="deny_curl_pipe_shell",
                cmmc_controls=["3.14.2"],
                nist_controls=["SI-3"],
                source="embedded",
            )

        # Rule: deny_sensitive_files
        original_arg = input_data.get("argument_string", "")
        if tool in {"read_file", "bash", "run_command"}:
            for pattern in self.SENSITIVE_PATTERNS:
                if pattern in original_arg:
                    return OPADecision(
                        allow=False,
                        action=PolicyAction.BLOCK,
                        severity=Severity.CRITICAL,
                        reason="Attempt to read sensitive system file blocked (CMMC 3.1.1)",
                        rule_name="deny_sensitive_files",
                        cmmc_controls=["3.1.1", "3.13.1"],
                        nist_controls=["AC-3", "SC-7"],
                        source="embedded",
                    )

        # Rule: alert_outbound_http
        if (tool in self.HTTP_TOOLS and
                "localhost" not in arg_str and
                "127.0.0.1" not in arg_str):
            return OPADecision(
                allow=True,
                action=PolicyAction.ALERT,
                severity=Severity.MEDIUM,
                reason="Outbound HTTP request detected -- boundary monitoring (CMMC 3.13.1)",
                rule_name="alert_outbound_http",
                cmmc_controls=["3.13.1"],
                nist_controls=["SC-7"],
                source="embedded",
            )

        # Rule: alert_post_credential_read
        if has_cred_event and tool in self.HTTP_TOOLS | self.SHELL_TOOLS:
            return OPADecision(
                allow=True,
                action=PolicyAction.ALERT,
                severity=Severity.HIGH,
                reason="Tool call following credential detection in session",
                rule_name="alert_post_credential_read",
                cmmc_controls=["3.1.1", "3.13.1"],
                nist_controls=["AC-3", "SC-7"],
                source="embedded",
            )

        return OPADecision.allow_default()


# ---------------------------------------------------------------------------
# OPA HTTP client
# ---------------------------------------------------------------------------

class OPAClient:
    """
    HTTP client for an external OPA server.
    Falls back to EmbeddedRegoEvaluator if server is unavailable.
    """

    DEFAULT_SERVER_URL = "http://localhost:8181"
    POLICY_PATH = "/v1/data/aiglos/policy"

    def __init__(
        self,
        server_url: str = DEFAULT_SERVER_URL,
        timeout_ms: int = 50,
        fallback_on_error: bool = True,
    ) -> None:
        self.server_url = server_url.rstrip("/")
        self.timeout = timeout_ms / 1000.0
        self.fallback_on_error = fallback_on_error
        self._embedded = EmbeddedRegoEvaluator()
        self._server_available: Optional[bool] = None  # None = untested
        self._last_health_check: float = 0.0
        self._health_check_interval = 30.0

    def evaluate(self, input_data: dict) -> OPADecision:
        """Evaluate policy, using OPA server or falling back to embedded."""
        if self._should_use_embedded():
            return self._embedded.evaluate(input_data)

        start = time.monotonic()
        try:
            import requests as req_lib
            response = req_lib.post(
                f"{self.server_url}{self.POLICY_PATH}",
                json={"input": input_data},
                timeout=self.timeout,
            )
            elapsed_ms = (time.monotonic() - start) * 1000

            if response.status_code == 200:
                self._server_available = True
                result = response.json().get("result", {})
                return self._parse_opa_result(result, elapsed_ms)
            else:
                logger.warning("opa_server_error", status=response.status_code)
                if self.fallback_on_error:
                    return self._embedded.evaluate(input_data)
                return OPADecision.allow_default()

        except Exception as e:
            logger.warning("opa_server_unavailable", error=str(e)[:80])
            self._server_available = False
            self._last_health_check = time.time()
            if self.fallback_on_error:
                return self._embedded.evaluate(input_data)
            return OPADecision.allow_default()

    def _should_use_embedded(self) -> bool:
        """True if we should use embedded evaluator."""
        if self._server_available is False:
            # Re-check after interval
            if time.time() - self._last_health_check > self._health_check_interval:
                self._server_available = None
                return False
            return True
        return False

    def _parse_opa_result(self, result: dict, elapsed_ms: float) -> OPADecision:
        """Parse OPA server response into OPADecision."""
        allow = result.get("allow", True)
        action_str = result.get("action", "allow" if allow else "block")
        severity_str = result.get("severity", "info")
        reason = result.get("reason", "")
        rule_name = result.get("rule_name", "unknown")
        cmmc = result.get("cmmc_controls", [])
        nist = result.get("nist_controls", [])

        try:
            action = PolicyAction(action_str)
        except ValueError:
            action = PolicyAction.ALLOW if allow else PolicyAction.BLOCK

        try:
            severity = Severity(severity_str)
        except ValueError:
            severity = Severity.INFO

        return OPADecision(
            allow=allow,
            action=action,
            severity=severity,
            reason=reason,
            rule_name=rule_name,
            cmmc_controls=cmmc,
            nist_controls=nist,
            evaluation_ms=elapsed_ms,
            source="opa_server",
        )

    def health_check(self) -> bool:
        """Returns True if the OPA server is reachable."""
        try:
            import requests as req_lib
            r = req_lib.get(f"{self.server_url}/health", timeout=1.0)
            self._server_available = r.status_code == 200
            return self._server_available
        except Exception:
            self._server_available = False
            return False

    def load_policy(self, bundle: PolicyBundle) -> bool:
        """Upload a policy bundle to the OPA server via the Policies API."""
        try:
            import requests as req_lib
            r = req_lib.put(
                f"{self.server_url}/v1/policies/aiglos",
                data=bundle.rego_content.encode(),
                headers={"Content-Type": "text/plain"},
                timeout=5.0,
            )
            return r.status_code in (200, 201)
        except Exception as e:
            logger.warning("opa_policy_load_failed", error=str(e)[:80])
            return False


# ---------------------------------------------------------------------------
# OPA Policy Engine (main entry point)
# ---------------------------------------------------------------------------

class OPAPolicyEngine:
    """
    High-level OPA policy engine for Aiglos.

    Wraps OPAClient and provides the same interface as the YAML policy engine
    (evaluate_tool_call) so it can be used as a drop-in replacement or
    run alongside the YAML engine.

    Usage:
        engine = OPAPolicyEngine(opa_server_url="http://localhost:8181")

        decision = engine.evaluate_tool_call(
            session_id="sess_abc",
            tool_name="bash",
            arguments={"command": "sudo rm -rf /"},
            session_context={...}
        )
        if not decision.allow:
            # block the call
    """

    def __init__(
        self,
        opa_server_url: str = OPAClient.DEFAULT_SERVER_URL,
        policy_file: Optional[str] = None,
        signing_secret: bytes | None = None,
        fallback_to_embedded: bool = True,
    ) -> None:
        self.client = OPAClient(
            server_url=opa_server_url,
            fallback_on_error=fallback_to_embedded,
        )
        self._embedded = EmbeddedRegoEvaluator()
        self.signing_secret = signing_secret
        self._active_bundle: Optional[PolicyBundle] = None

        # Load policy file if provided
        if policy_file and Path(policy_file).exists():
            bundle = PolicyBundle.load(policy_file)
            if signing_secret and not bundle.verify(signing_secret):
                logger.warning("opa_policy_signature_invalid", file=policy_file)
            else:
                self._active_bundle = bundle
                logger.info("opa_policy_loaded", file=policy_file, version=bundle.version)

    def evaluate_tool_call(
        self,
        session_id: str,
        tool_name: str,
        arguments: dict | str,
        model: str = "unknown",
        goal_hash: str = "",
        call_index: int = 0,
        session_tool_history: list[str] | None = None,
        session_has_credential_event: bool = False,
        deployment_tier: str = "cloud",
    ) -> OPADecision:
        """
        Evaluate a tool call against OPA policy.
        Returns an OPADecision with allow/block/alert action.
        """
        if isinstance(arguments, dict):
            arg_str = json.dumps(arguments)
        else:
            arg_str = str(arguments)

        input_data = {
            "session_id": session_id,
            "model": model,
            "tool_name": tool_name,
            "arguments": arguments if isinstance(arguments, dict) else {},
            "argument_string": arg_str,
            "call_index": call_index,
            "goal_hash": goal_hash,
            "session_tool_history": session_tool_history or [],
            "session_has_credential_event": session_has_credential_event,
            "metadata": {
                "deployment_tier": deployment_tier,
                "aiglos_version": "0.1.0",
            },
        }

        decision = self.client.evaluate(input_data)

        if decision.action != PolicyAction.ALLOW:
            logger.info(
                "opa_policy_decision",
                session_id=session_id[:8],
                tool=tool_name,
                action=decision.action.value,
                rule=decision.rule_name,
                source=decision.source,
            )

        return decision

    def load_bundle(self, bundle: PolicyBundle) -> bool:
        """Load a policy bundle, optionally pushing to OPA server."""
        if self.signing_secret:
            if not bundle.verify(self.signing_secret):
                logger.error("opa_bundle_signature_invalid", name=bundle.name)
                return False
        self._active_bundle = bundle
        # Push to server if available
        if self.client._server_available is not False:
            pushed = self.client.load_policy(bundle)
            if pushed:
                logger.info("opa_bundle_pushed", name=bundle.name, version=bundle.version)
        return True

    def get_default_bundle(self) -> PolicyBundle:
        """Get the default Aiglos CMMC baseline policy bundle."""
        bundle = PolicyBundle(
            name="aiglos_cmmc_baseline",
            version="1.0.0",
            rego_content=AIGLOS_DEFAULT_REGO,
        )
        if self.signing_secret:
            bundle.sign(self.signing_secret)
        return bundle

    def generate_policy_files(self, output_dir: str) -> list[str]:
        """Write default policy files to a directory."""
        output = Path(output_dir)
        output.mkdir(parents=True, exist_ok=True)
        bundle = self.get_default_bundle()
        rego_path = str(output / "aiglos.rego")
        bundle.save(rego_path)
        return [rego_path, rego_path + ".meta.json"]
