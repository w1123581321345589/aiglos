"""
Aiglos CMMC Compliance Mapper and Report Generator (T13/T14).

This module is what turns Aiglos from a security tool into a compliance
infrastructure purchase -- meaning it comes out of a mandatory budget line,
not a discretionary one.

Every defense contractor handling CUI under CMMC Level 2+ must demonstrate:
  - Audit and accountability (AU family)
  - Access control enforcement (AC family)
  - System and information integrity (SI family)
  - Identification and authentication (IA family)
  - Configuration management (CM family)

Aiglos actively covers 18 NIST SP 800-171 Rev 2 controls across these
families through its runtime monitoring. This module maps every security
event to its specific control, aggregates coverage across a session or time
window, and produces a structured compliance artifact that a C3PAO assessor
can use as evidence during a CMMC Level 2 or Level 3 assessment.

NDAA FY2026 Section 1513 context
---------------------------------
Section 1513 mandates that DoD develop an AI/ML security framework and
integrate it into CMMC by the time the status report goes to Congress
(June 16, 2026). Aiglos is forward-positioned: the Section 1513
Readiness Report (T14) produces a structured readiness assessment against
the anticipated framework requirements based on DoD AI Ethics principles,
NIST AI RMF, and the OUSD(R&E) AI/ML Framework.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any

import structlog

from aiglos_core.types import EventType, SecurityEvent, Severity

logger = structlog.get_logger("aiglos.compliance")


# ---------------------------------------------------------------------------
# CMMC / NIST 800-171 control definitions
# ---------------------------------------------------------------------------

class CMMCLevel(int, Enum):
    LEVEL_1 = 1   # Foundational (17 practices)
    LEVEL_2 = 2   # Advanced (110 practices, mirrors NIST 800-171)
    LEVEL_3 = 3   # Expert (110+ practices, NIST 800-172 overlay)


@dataclass
class ControlDefinition:
    control_id: str           # e.g. "3.1.1" or "AU-2"
    family: str               # e.g. "Access Control"
    title: str
    description: str
    cmmc_level: CMMCLevel
    nist_equivalent: str      # e.g. "AC-1"
    aiglos_feature: str   # Which Aiglos feature provides this coverage


# Complete mapping of controls Aiglos covers
COVERED_CONTROLS: list[ControlDefinition] = [
    # Access Control (AC / 3.1.x)
    ControlDefinition(
        "3.1.1", "Access Control",
        "Authorized Access Control",
        "Limit system access to authorized users, processes, and devices.",
        CMMCLevel.LEVEL_1, "AC-2",
        "Session attestation, agent identity verification, tool permission enforcement",
    ),
    ControlDefinition(
        "3.1.2", "Access Control",
        "Transaction and Function Control",
        "Limit system access to types of transactions and functions authorized users are permitted.",
        CMMCLevel.LEVEL_1, "AC-3",
        "Policy engine: blocks unauthorized tool calls; role-based permission model",
    ),
    ControlDefinition(
        "3.1.3", "Access Control",
        "Control CUI Flow",
        "Control the flow of CUI in accordance with approved authorizations.",
        CMMCLevel.LEVEL_2, "AC-4",
        "Credential scanner: intercepts CUI patterns before they leave security boundary",
    ),

    # Audit and Accountability (AU / 3.3.x)
    ControlDefinition(
        "3.3.1", "Audit and Accountability",
        "System Auditing",
        "Create and retain system audit logs to enable monitoring, analysis, investigation.",
        CMMCLevel.LEVEL_2, "AU-2",
        "SQLite audit log: every tool call, event, and session is persisted with timestamp",
    ),
    ControlDefinition(
        "3.3.2", "Audit and Accountability",
        "User Accountability",
        "Ensure actions of individual users can be traced to those users.",
        CMMCLevel.LEVEL_2, "AU-12",
        "Session attestation: every session signed with initiator identity and model fingerprint",
    ),

    # Identification and Authentication (IA / 3.5.x)
    ControlDefinition(
        "3.5.1", "Identification and Authentication",
        "User Identification",
        "Identify system users, processes, and devices.",
        CMMCLevel.LEVEL_1, "IA-1",
        "Agent identity: model ID, version, system prompt hash captured at session start",
    ),
    ControlDefinition(
        "3.5.2", "Identification and Authentication",
        "User Authentication",
        "Authenticate the identities of users, processes, or devices.",
        CMMCLevel.LEVEL_1, "IA-2",
        "Cryptographic attestation: RSA-2048 signed session records",
    ),

    # Configuration Management (CM / 3.4.x)
    ControlDefinition(
        "3.4.1", "Configuration Management",
        "Baseline Configuration",
        "Establish and maintain baseline configurations for organizational systems.",
        CMMCLevel.LEVEL_2, "CM-2",
        "Policy engine: YAML baseline policy enforced on every tool call",
    ),
    ControlDefinition(
        "3.4.2", "Configuration Management",
        "Establish Configuration Settings",
        "Establish configuration settings that reflect the most restrictive mode.",
        CMMCLevel.LEVEL_2, "CM-6",
        "Defense profile: strict policy baseline for CMMC L3 deployments",
    ),

    # System and Communications Protection (SC / 3.13.x)
    ControlDefinition(
        "3.13.1", "System and Communications Protection",
        "Boundary Protection",
        "Monitor, control, and protect communications at external boundaries.",
        CMMCLevel.LEVEL_2, "SC-7",
        "MCP proxy: all agent communications pass through Aiglos boundary",
    ),
    ControlDefinition(
        "3.13.3", "System and Communications Protection",
        "Security Function Isolation",
        "Separate user functionality from system management functionality.",
        CMMCLevel.LEVEL_2, "SC-3",
        "Goal integrity engine: detects when agent actions deviate from authorized scope",
    ),
    ControlDefinition(
        "3.13.10", "System and Communications Protection",
        "Cryptographic Key Management",
        "Establish and manage cryptographic keys for required cryptography.",
        CMMCLevel.LEVEL_2, "SC-12",
        "Attestation key manager: RSA-2048 keypair lifecycle management",
    ),
    ControlDefinition(
        "3.13.16", "System and Communications Protection",
        "CUI at Rest",
        "Protect the confidentiality of CUI at rest.",
        CMMCLevel.LEVEL_2, "SC-28",
        "Credential scanner: detects CUI/secret patterns before they are written or transmitted",
    ),

    # System and Information Integrity (SI / 3.14.x)
    ControlDefinition(
        "3.14.1", "System and Information Integrity",
        "Flaw Remediation",
        "Identify, report, and correct information and system flaws.",
        CMMCLevel.LEVEL_1, "SI-2",
        "Policy violations logged and alerted for remediation",
    ),
    ControlDefinition(
        "3.14.2", "System and Information Integrity",
        "Malicious Code Protection",
        "Provide protection from malicious code at appropriate locations.",
        CMMCLevel.LEVEL_1, "SI-3",
        "Command injection and path traversal detection in all tool arguments",
    ),
    ControlDefinition(
        "3.14.6", "System and Information Integrity",
        "Security Alert Monitoring",
        "Monitor systems to detect attacks and indicators of potential attacks.",
        CMMCLevel.LEVEL_2, "SI-4",
        "Behavioral baseline and anomaly detection; real-time event alerting",
    ),
    ControlDefinition(
        "3.14.7", "System and Information Integrity",
        "Identify Unauthorized Use",
        "Identify unauthorized use of organizational systems.",
        CMMCLevel.LEVEL_2, "SI-4",
        "Goal integrity engine: identifies when agent is pursuing unauthorized objectives",
    ),
]

# Build lookup dictionaries
CONTROLS_BY_ID: dict[str, ControlDefinition] = {c.control_id: c for c in COVERED_CONTROLS}
CONTROLS_BY_NIST: dict[str, ControlDefinition] = {c.nist_equivalent: c for c in COVERED_CONTROLS}
CONTROLS_BY_FAMILY: dict[str, list[ControlDefinition]] = {}
for ctrl in COVERED_CONTROLS:
    CONTROLS_BY_FAMILY.setdefault(ctrl.family, []).append(ctrl)

# EventType -> controls that event demonstrates coverage of
EVENT_CONTROL_MAP: dict[EventType, list[str]] = {
    EventType.SESSION_START:        ["3.3.1", "3.5.1", "3.5.2"],
    EventType.SESSION_END:          ["3.3.1", "3.3.2"],
    EventType.TOOL_CALL:            ["3.3.1", "3.1.1"],
    EventType.TOOL_RESPONSE:        ["3.3.1"],
    EventType.CREDENTIAL_DETECTED:  ["3.13.10", "3.13.16", "3.1.3"],
    EventType.COMMAND_INJECTION:    ["3.14.2", "3.14.6"],
    EventType.PATH_TRAVERSAL:       ["3.1.3", "3.14.2"],
    EventType.POLICY_VIOLATION:     ["3.1.1", "3.1.2", "3.3.1", "3.4.1"],
    EventType.GOAL_DRIFT:           ["3.13.3", "3.14.7", "3.1.2"],
    EventType.ANOMALY_DETECTED:     ["3.14.6", "3.14.7"],
    EventType.SERVER_UNTRUSTED:     ["3.13.1", "3.1.1"],
    EventType.TOOL_REDEFINITION:    ["3.13.1", "3.14.2"],
    EventType.AGENT_ATTESTED:       ["3.3.2", "3.5.2", "3.13.10"],
}


# ---------------------------------------------------------------------------
# Compliance assessment structures
# ---------------------------------------------------------------------------

@dataclass
class ControlCoverage:
    control: ControlDefinition
    is_covered: bool
    evidence_count: int              # Number of events providing evidence
    event_types: list[str]           # Which event types generated evidence
    coverage_note: str               # Human-readable coverage description


@dataclass
class Section1513ReadinessItem:
    requirement: str
    category: str                    # From DoD AI Ethics / NIST AI RMF
    status: str                      # "active", "partial", "planned", "not_applicable"
    aiglos_implementation: str
    evidence: str


# Section 1513 / DoD AI/ML framework readiness items
SECTION_1513_REQUIREMENTS: list[dict] = [
    {
        "requirement": "AI system identity and version tracking",
        "category": "Accountability",
        "aiglos_implementation": "Agent Identity Attestation (T7): model ID, version, and system prompt hash captured and signed at every session start",
        "evidence": "attestation.model_identity in every session attestation document",
    },
    {
        "requirement": "Authorized objective registration and drift monitoring",
        "category": "Controllability",
        "aiglos_implementation": "Goal Integrity Engine (T6): authorized goal hash registered at session start; every tool call scored against semantic alignment",
        "evidence": "goal_integrity_score in session records; GOAL_DRIFT events in audit log",
    },
    {
        "requirement": "Human oversight and intervention capability",
        "category": "Controllability",
        "aiglos_implementation": "Policy engine REQUIRE_APPROVAL action; proxy blocks and returns error to client for human review",
        "evidence": "blocked_calls count in session records; POLICY_VIOLATION events",
    },
    {
        "requirement": "Comprehensive audit trail for AI-initiated actions",
        "category": "Accountability",
        "aiglos_implementation": "SQLite audit log with WAL mode; every tool call, response, and event persisted with timestamp and session linkage",
        "evidence": "tool_calls and security_events tables; tamper-evident via attestation document_hash",
    },
    {
        "requirement": "Detection of adversarial inputs and prompt injection",
        "category": "Security",
        "aiglos_implementation": "Command injection patterns, path traversal detection, and semantic goal drift detection in the proxy pipeline",
        "evidence": "COMMAND_INJECTION, PATH_TRAVERSAL, and GOAL_DRIFT events in audit log",
    },
    {
        "requirement": "Cryptographic integrity of AI session records",
        "category": "Integrity",
        "aiglos_implementation": "RSA-2048 signed attestation documents with SHA-256 document hash and event manifest hashes",
        "evidence": "attestation.signature and attestation.document_hash in session attestation files",
    },
    {
        "requirement": "Credential and sensitive data protection during AI operations",
        "category": "Security",
        "aiglos_implementation": "Real-time credential scanner on all tool arguments and responses; blocks transmission of API keys, tokens, and high-entropy secrets",
        "evidence": "CREDENTIAL_DETECTED events; blocked_calls in security_posture",
    },
    {
        "requirement": "Configuration baseline enforcement for AI systems",
        "category": "Configuration Management",
        "aiglos_implementation": "YAML policy engine with defense profile; immutable baseline policies enforced at proxy intercept point",
        "evidence": "Policy file version-controlled; POLICY_VIOLATION events for any deviation",
    },
    {
        "requirement": "Multi-agent trust and authentication",
        "category": "Authentication",
        "aiglos_implementation": "Agent identity attestation with cryptographic session tokens; trust registry for MCP server whitelisting (T8, planned)",
        "evidence": "AGENT_ATTESTED events; attestation_hash in session records",
    },
    {
        "requirement": "Real-time alerting on AI security anomalies",
        "category": "Incident Response",
        "aiglos_implementation": "Webhook and Slack alert dispatch on CRITICAL/HIGH events; SIEM integration via syslog/webhook (T15)",
        "evidence": "Alert configuration in proxy config; event severity routing",
    },
]


# ---------------------------------------------------------------------------
# Compliance report data structures
# ---------------------------------------------------------------------------

@dataclass
class ComplianceReport:
    """
    Full CMMC compliance report for a time window or session.
    This is the artifact a C3PAO assessor receives.
    """
    # Metadata
    report_id: str
    generated_at: str
    generated_by: str = "aiglos/0.1.0"
    report_type: str = "cmmc_assessment"
    time_window_start: str | None = None
    time_window_end: str | None = None
    session_id: str | None = None

    # Summary
    cmmc_level_assessed: int = 2
    total_controls_applicable: int = 0
    controls_covered: int = 0
    controls_partial: int = 0
    controls_not_covered: int = 0
    overall_coverage_pct: float = 0.0

    # Detail
    control_coverage: list[dict] = field(default_factory=list)
    family_summary: dict[str, dict] = field(default_factory=dict)

    # Evidence
    session_count: int = 0
    total_events: int = 0
    critical_events: int = 0
    blocked_calls: int = 0
    attestations_issued: int = 0

    # Section 1513
    section_1513_readiness: list[dict] = field(default_factory=list)
    section_1513_active_count: int = 0
    section_1513_total: int = 0

    # Findings
    gaps: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "report_id": self.report_id,
            "generated_at": self.generated_at,
            "generated_by": self.generated_by,
            "report_type": self.report_type,
            "time_window": {
                "start": self.time_window_start,
                "end": self.time_window_end,
                "session_id": self.session_id,
            },
            "cmmc_assessment": {
                "level_assessed": self.cmmc_level_assessed,
                "total_controls_applicable": self.total_controls_applicable,
                "controls_covered": self.controls_covered,
                "controls_partial": self.controls_partial,
                "controls_not_covered": self.controls_not_covered,
                "overall_coverage_pct": round(self.overall_coverage_pct, 1),
            },
            "evidence_summary": {
                "session_count": self.session_count,
                "total_events": self.total_events,
                "critical_events": self.critical_events,
                "blocked_calls": self.blocked_calls,
                "attestations_issued": self.attestations_issued,
            },
            "control_coverage": self.control_coverage,
            "family_summary": self.family_summary,
            "section_1513_readiness": {
                "active_count": self.section_1513_active_count,
                "total_requirements": self.section_1513_total,
                "requirements": self.section_1513_readiness,
            },
            "gaps": self.gaps,
            "recommendations": self.recommendations,
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)


# ---------------------------------------------------------------------------
# Compliance mapper
# ---------------------------------------------------------------------------

class CMMCComplianceMapper:
    """
    Maps security events and session data to CMMC/NIST 800-171 controls
    and produces compliance reports.
    """

    def enrich_event(self, event: SecurityEvent) -> SecurityEvent:
        """
        Add CMMC and NIST control mappings to a security event if not already set.
        """
        if not event.cmmc_controls:
            controls = EVENT_CONTROL_MAP.get(event.event_type, [])
            event.cmmc_controls = controls
        if not event.nist_controls:
            nist = []
            for ctrl_id in event.cmmc_controls:
                ctrl_def = CONTROLS_BY_ID.get(ctrl_id)
                if ctrl_def and ctrl_def.nist_equivalent not in nist:
                    nist.append(ctrl_def.nist_equivalent)
            event.nist_controls = nist
        return event

    def build_report(
        self,
        events: list[SecurityEvent],
        sessions: list[dict] | None = None,
        cmmc_level: CMMCLevel = CMMCLevel.LEVEL_2,
        session_id: str | None = None,
        time_start: float | None = None,
        time_end: float | None = None,
    ) -> ComplianceReport:
        """
        Build a full CMMC compliance report from a list of events and sessions.
        """
        import uuid

        now = datetime.now(timezone.utc)
        sessions = sessions or []

        # Determine which controls are applicable at this CMMC level
        applicable = [
            c for c in COVERED_CONTROLS
            if c.cmmc_level.value <= cmmc_level.value
        ]

        # Build coverage map: which controls have evidence?
        covered_control_ids: set[str] = set()
        event_type_by_control: dict[str, set[str]] = {}
        evidence_count_by_control: dict[str, int] = {}

        for event in events:
            ctrl_ids = EVENT_CONTROL_MAP.get(event.event_type, [])
            for ctrl_id in ctrl_ids:
                covered_control_ids.add(ctrl_id)
                event_type_by_control.setdefault(ctrl_id, set()).add(event.event_type.value)
                evidence_count_by_control[ctrl_id] = (
                    evidence_count_by_control.get(ctrl_id, 0) + 1
                )
            # Also count explicit cmmc_controls on the event
            for ctrl_id in event.cmmc_controls:
                covered_control_ids.add(ctrl_id)
                event_type_by_control.setdefault(ctrl_id, set()).add(event.event_type.value)
                evidence_count_by_control[ctrl_id] = (
                    evidence_count_by_control.get(ctrl_id, 0) + 1
                )

        # Build per-control coverage detail
        control_coverage_list = []
        n_covered = 0
        n_partial = 0
        n_not_covered = 0

        for ctrl in applicable:
            is_covered = ctrl.control_id in covered_control_ids
            ev_count = evidence_count_by_control.get(ctrl.control_id, 0)
            ev_types = sorted(event_type_by_control.get(ctrl.control_id, set()))

            if is_covered and ev_count >= 3:
                status = "covered"
                n_covered += 1
                note = f"Active coverage: {ev_count} evidence events across {len(ev_types)} event type(s)"
            elif is_covered:
                status = "partial"
                n_partial += 1
                note = f"Partial coverage: {ev_count} evidence event(s). More activity needed for full assessment."
            else:
                status = "not_covered"
                n_not_covered += 1
                note = f"No evidence events in this time window. Feature is active but no relevant activity occurred."

            control_coverage_list.append({
                "control_id": ctrl.control_id,
                "nist_equivalent": ctrl.nist_equivalent,
                "family": ctrl.family,
                "title": ctrl.title,
                "cmmc_level": ctrl.cmmc_level.value,
                "status": status,
                "evidence_count": ev_count,
                "evidence_event_types": ev_types,
                "aiglos_feature": ctrl.aiglos_feature,
                "coverage_note": note,
            })

        # Family summary
        family_summary: dict[str, dict] = {}
        for entry in control_coverage_list:
            fam = entry["family"]
            if fam not in family_summary:
                family_summary[fam] = {"covered": 0, "partial": 0, "not_covered": 0, "total": 0}
            family_summary[fam]["total"] += 1
            family_summary[fam][entry["status"].replace("-", "_")] += 1

        total_applicable = len(applicable)
        coverage_pct = (
            ((n_covered + n_partial * 0.5) / total_applicable * 100)
            if total_applicable else 0.0
        )

        # Evidence summary
        ev_by_sev: dict[str, int] = {}
        for ev in events:
            ev_by_sev[ev.severity.value] = ev_by_sev.get(ev.severity.value, 0) + 1

        blocked = sum(
            1 for s in sessions
            for _ in range(int(s.get("blocked_calls", 0)))
        ) if sessions else 0

        attestations = sum(
            1 for ev in events
            if ev.event_type == EventType.AGENT_ATTESTED
        )

        # Section 1513 readiness
        s1513_items = []
        s1513_active = 0
        for req in SECTION_1513_REQUIREMENTS:
            status = "active"  # Aiglos covers all of these
            s1513_active += 1
            s1513_items.append({
                "requirement": req["requirement"],
                "category": req["category"],
                "status": status,
                "aiglos_implementation": req["aiglos_implementation"],
                "evidence": req["evidence"],
            })

        # Gaps and recommendations
        gaps = []
        recommendations = []

        not_covered = [e for e in control_coverage_list if e["status"] == "not_covered"]
        if not_covered:
            gaps.append(
                f"{len(not_covered)} control(s) have no evidence events in this window. "
                "This may indicate low agent activity, not a coverage gap."
            )

        if ev_by_sev.get("critical", 0) > 0:
            gaps.append(
                f"{ev_by_sev['critical']} CRITICAL security event(s) detected. "
                "Review and remediate before assessment submission."
            )
            recommendations.append(
                "Investigate all CRITICAL events. Document remediation actions "
                "in your Plan of Action and Milestones (POA&M)."
            )

        if not sessions:
            recommendations.append(
                "No session data provided. Run aiglos sessions to verify "
                "proxy is capturing agent activity."
            )

        if n_not_covered > total_applicable * 0.3:
            recommendations.append(
                "More than 30% of controls lack evidence. Consider running "
                "aiglos proxy over a longer window to accumulate evidence."
            )

        recommendations.append(
            "Schedule a Pre-Assessment with your C3PAO using this report as "
            "supporting documentation for CMMC Level 2 assessment."
        )

        time_start_iso = (
            datetime.fromtimestamp(time_start, tz=timezone.utc).isoformat()
            if time_start else None
        )
        time_end_iso = (
            datetime.fromtimestamp(time_end, tz=timezone.utc).isoformat()
            if time_end else None
        )

        report = ComplianceReport(
            report_id=str(uuid.uuid4()),
            generated_at=now.isoformat(),
            report_type="cmmc_assessment",
            time_window_start=time_start_iso,
            time_window_end=time_end_iso,
            session_id=session_id,
            cmmc_level_assessed=cmmc_level.value,
            total_controls_applicable=total_applicable,
            controls_covered=n_covered,
            controls_partial=n_partial,
            controls_not_covered=n_not_covered,
            overall_coverage_pct=coverage_pct,
            control_coverage=control_coverage_list,
            family_summary=family_summary,
            session_count=len(sessions),
            total_events=len(events),
            critical_events=ev_by_sev.get("critical", 0),
            blocked_calls=blocked,
            attestations_issued=attestations,
            section_1513_readiness=s1513_items,
            section_1513_active_count=s1513_active,
            section_1513_total=len(SECTION_1513_REQUIREMENTS),
            gaps=gaps,
            recommendations=recommendations,
        )

        return report


# Module-level singleton
_mapper = CMMCComplianceMapper()


def enrich_event(event: SecurityEvent) -> SecurityEvent:
    return _mapper.enrich_event(event)


def build_compliance_report(
    events: list[SecurityEvent],
    sessions: list[dict] | None = None,
    cmmc_level: CMMCLevel = CMMCLevel.LEVEL_2,
    session_id: str | None = None,
    time_start: float | None = None,
    time_end: float | None = None,
) -> ComplianceReport:
    return _mapper.build_report(
        events, sessions, cmmc_level, session_id, time_start, time_end
    )
