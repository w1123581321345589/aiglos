"""
Aiglos Multi-Agent Trust Fabric (T12).

The problem this solves
-----------------------
When Agent A calls Agent B, there is currently no security primitive that
answers three questions:

  1. Identity:  Is this really Agent A? Or is it an attacker impersonating A?
  2. Scope:     Is Agent A authorized to invoke Agent B for this task?
  3. Integrity: Has Agent A's goal been compromised since it was authorized?

Without answers to these questions, multi-agent systems are vulnerable to
covert tool invocation: a compromised orchestrator calls subagents to perform
unauthorized actions without user awareness. The user sees the top-level agent
operating normally. The actual work is being done by subagents that were never
explicitly authorized.

This is not a theoretical threat. It is the documented attack pattern in
OWASP Agentic Top 10 2026 entries #3 (Excessive Agency) and #5 (Multi-Agent
Trust Vulnerabilities).

How it works
------------
The trust fabric implements a token-based handshake protocol:

  1. REGISTRATION
     An agent registers with the fabric, presenting its identity (model ID,
     session ID, authorized goal hash) and receiving a signed agent token.
     The token is a compact signed JWT-like structure: header.claims.signature.

  2. DELEGATION
     When Orchestrator A wants to invoke Subagent B, it requests a delegation
     token scoped to a specific sub-task. The delegation token binds:
       - the orchestrator's identity
       - the subagent's expected identity
       - the specific sub-task scope (a hash of the task description)
       - an expiry (default: 5 minutes)
       - allowed tools for the subagent

     The delegation token is signed by the fabric's signing key. Subagent B
     verifies the token before accepting the invocation.

  3. VERIFICATION
     Subagent B presents the delegation token to the fabric for verification.
     The fabric checks:
       - Signature validity
       - Token not expired
       - Orchestrator is registered and its goal has not drifted beyond threshold
       - Subagent identity matches the token's expected recipient
       - Requested tool is within the delegated tool scope

     If all checks pass, the invocation is permitted and logged.

  4. REVOCATION
     Any agent token can be revoked at any time. Revocation is immediate --
     all pending and future invocations using a revoked token fail.

Token format
------------
Compact base64url-encoded JSON segments:

  header.claims.signature

  header:  {"alg": "RS256", "typ": "CGT"}  (Aiglos Token)
  claims:  JSON object with standardized fields
  signature: RSA-PSS signature over "header_b64.claims_b64"

The format is intentionally similar to JWT to make it easy to integrate with
existing tooling, but the semantics are specific to agentic workflows.

Storage
-------
Agent registrations and token records are stored in SQLite alongside the
audit log. The fabric is stateful and survives process restarts.

Defense context
---------------
For DoD environments, the trust fabric provides the inter-agent authentication
that Section 1513 NDAA FY2026 requires. When you have an orchestrator spawning
subagents to handle classified tasks, each subagent-to-subagent call needs a
chain of custody that can be audited later. The delegation token chain is that
record.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import secrets
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional
import sqlite3

import structlog

from aiglos_core.types import EventType, SecurityEvent, Severity

logger = structlog.get_logger("aiglos.trust_fabric")


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

TOKEN_VERSION = "1"
DEFAULT_TOKEN_TTL = 300          # 5 minutes
MAX_TOKEN_TTL = 3600             # 1 hour hard ceiling
DELEGATION_DEPTH_LIMIT = 5      # Max chain: root → A → B → C → D → E
TOKEN_TYPE_AGENT = "agent"
TOKEN_TYPE_DELEGATION = "delegation"


# ---------------------------------------------------------------------------
# Enums and data structures
# ---------------------------------------------------------------------------

class TrustFabricError(Exception):
    """Raised when a trust operation fails for a security reason."""
    pass


class VerificationResult(str, Enum):
    OK = "ok"
    EXPIRED = "expired"
    REVOKED = "revoked"
    INVALID_SIGNATURE = "invalid_signature"
    WRONG_RECIPIENT = "wrong_recipient"
    TOOL_NOT_DELEGATED = "tool_not_delegated"
    ORCHESTRATOR_COMPROMISED = "orchestrator_compromised"
    DEPTH_EXCEEDED = "depth_exceeded"
    AGENT_NOT_REGISTERED = "agent_not_registered"
    UNKNOWN = "unknown"


@dataclass
class AgentIdentity:
    """The cryptographic identity of a registered agent."""
    agent_id: str
    model_id: str
    session_id: str
    goal_hash: str                  # SHA-256 of authorized goal
    registered_at: float
    token_id: str = ""              # ID of the agent's own token
    integrity_score: float = 1.0   # Current goal integrity (updated by proxy)
    is_revoked: bool = False
    revoked_reason: str = ""

    def to_dict(self) -> dict:
        return {
            "agent_id": self.agent_id,
            "model_id": self.model_id,
            "session_id": self.session_id,
            "goal_hash": self.goal_hash,
            "registered_at": self.registered_at,
            "token_id": self.token_id,
            "integrity_score": self.integrity_score,
            "is_revoked": self.is_revoked,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "AgentIdentity":
        return cls(
            agent_id=d["agent_id"],
            model_id=d["model_id"],
            session_id=d["session_id"],
            goal_hash=d["goal_hash"],
            registered_at=d["registered_at"],
            token_id=d.get("token_id", ""),
            integrity_score=d.get("integrity_score", 1.0),
            is_revoked=d.get("is_revoked", False),
        )


@dataclass
class TokenClaims:
    """Claims embedded in a trust token."""
    token_id: str
    token_type: str          # TOKEN_TYPE_AGENT or TOKEN_TYPE_DELEGATION
    issued_at: float
    expires_at: float
    issuer: str = "aiglos/trust-fabric"

    # Agent token fields
    agent_id: str = ""
    model_id: str = ""
    session_id: str = ""
    goal_hash: str = ""

    # Delegation token additional fields
    orchestrator_id: str = ""
    recipient_agent_id: str = ""
    task_hash: str = ""          # SHA-256 of the sub-task description
    allowed_tools: list[str] = field(default_factory=list)
    delegation_depth: int = 0
    parent_token_id: str = ""   # Token ID of the delegating token

    def is_expired(self) -> bool:
        return time.time() > self.expires_at

    def to_dict(self) -> dict:
        return {
            "tid": self.token_id,
            "typ": self.token_type,
            "iat": self.issued_at,
            "exp": self.expires_at,
            "iss": self.issuer,
            "aid": self.agent_id,
            "mid": self.model_id,
            "sid": self.session_id,
            "ghsh": self.goal_hash,
            "oid": self.orchestrator_id,
            "rid": self.recipient_agent_id,
            "thsh": self.task_hash,
            "tools": self.allowed_tools,
            "depth": self.delegation_depth,
            "ptid": self.parent_token_id,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "TokenClaims":
        return cls(
            token_id=d["tid"],
            token_type=d["typ"],
            issued_at=d["iat"],
            expires_at=d["exp"],
            issuer=d.get("iss", ""),
            agent_id=d.get("aid", ""),
            model_id=d.get("mid", ""),
            session_id=d.get("sid", ""),
            goal_hash=d.get("ghsh", ""),
            orchestrator_id=d.get("oid", ""),
            recipient_agent_id=d.get("rid", ""),
            task_hash=d.get("thsh", ""),
            allowed_tools=d.get("tools", []),
            delegation_depth=d.get("depth", 0),
            parent_token_id=d.get("ptid", ""),
        )


@dataclass
class TrustToken:
    """A signed trust token: header.claims.signature."""
    claims: TokenClaims
    token_string: str = ""     # The compact serialized form
    is_revoked: bool = False

    @property
    def token_id(self) -> str:
        return self.claims.token_id


@dataclass
class DelegationRequest:
    """A request from an orchestrator to invoke a subagent."""
    orchestrator_token: str     # The orchestrator's own agent token
    recipient_agent_id: str     # Who should receive this delegation
    task_description: str       # What the subagent should do
    allowed_tools: list[str]    # Which tools the subagent may use
    ttl: int = DEFAULT_TOKEN_TTL


@dataclass
class InvocationRequest:
    """A subagent presenting a delegation token to invoke a tool."""
    delegation_token: str       # Token received from orchestrator
    agent_id: str               # The subagent's identity claim
    tool_name: str              # The tool being invoked
    session_id: str = ""        # Current session ID of the subagent


@dataclass
class VerificationOutcome:
    """Result of verifying a delegation token for an invocation."""
    result: VerificationResult
    allowed: bool
    reason: str
    claims: Optional[TokenClaims] = None
    events: list[SecurityEvent] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Token signing (HMAC-SHA256 for compactness and air-gap compatibility)
# ---------------------------------------------------------------------------

def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def _b64url_decode(s: str) -> bytes:
    padding = 4 - len(s) % 4
    if padding != 4:
        s += "=" * padding
    return base64.urlsafe_b64decode(s)


def _sign(payload: str, secret: bytes) -> str:
    sig = hmac.new(secret, payload.encode(), hashlib.sha256).digest()
    return _b64url(sig)


def _verify_sig(payload: str, signature: str, secret: bytes) -> bool:
    expected = hmac.new(secret, payload.encode(), hashlib.sha256).digest()
    try:
        provided = _b64url_decode(signature)
        return hmac.compare_digest(expected, provided)
    except Exception:
        return False


def _serialize_token(claims: TokenClaims, secret: bytes) -> str:
    header = {"alg": "HS256", "typ": "CGT", "ver": TOKEN_VERSION}
    header_b64 = _b64url(json.dumps(header, separators=(",", ":")).encode())
    claims_b64 = _b64url(json.dumps(claims.to_dict(), separators=(",", ":")).encode())
    payload = f"{header_b64}.{claims_b64}"
    sig = _sign(payload, secret)
    return f"{payload}.{sig}"


def _deserialize_token(token_str: str, secret: bytes) -> tuple[bool, Optional[TokenClaims]]:
    """Returns (signature_valid, claims_or_None)."""
    parts = token_str.split(".")
    if len(parts) != 3:
        return False, None
    header_b64, claims_b64, sig = parts
    payload = f"{header_b64}.{claims_b64}"
    if not _verify_sig(payload, sig, secret):
        return False, None
    try:
        claims_dict = json.loads(_b64url_decode(claims_b64))
        return True, TokenClaims.from_dict(claims_dict)
    except Exception:
        return False, None


# ---------------------------------------------------------------------------
# Trust Fabric
# ---------------------------------------------------------------------------

class AgentTrustFabric:
    """
    Central trust authority for multi-agent Aiglos deployments.

    Manages agent registration, token issuance, delegation chains,
    and invocation verification.
    """

    def __init__(
        self,
        db_path: str = "aiglos_audit.db",
        signing_secret: bytes | None = None,
        integrity_threshold: float = 0.25,
    ) -> None:
        self.db_path = db_path
        # Use a provided secret or generate one per process
        # In production: inject via AIGLOS_FABRIC_SECRET env var
        self._secret = signing_secret or secrets.token_bytes(32)
        self.integrity_threshold = integrity_threshold

        self._agents: dict[str, AgentIdentity] = {}     # agent_id -> identity
        self._tokens: dict[str, bool] = {}              # token_id -> is_revoked
        self._delegation_chains: dict[str, list[str]] = {}  # token_id -> [parent chain]

        self._ensure_tables()
        self._load_state()

    # ------------------------------------------------------------------
    # Registration
    # ------------------------------------------------------------------

    def register_agent(
        self,
        session_id: str,
        model_id: str,
        authorized_goal: str,
        agent_id: str | None = None,
    ) -> TrustToken:
        """
        Register an agent and issue its identity token.
        Called at session start by the proxy.
        """
        agent_id = agent_id or _generate_id("agt")
        goal_hash = _hash_goal(authorized_goal)
        now = time.time()

        identity = AgentIdentity(
            agent_id=agent_id,
            model_id=model_id,
            session_id=session_id,
            goal_hash=goal_hash,
            registered_at=now,
        )

        claims = TokenClaims(
            token_id=_generate_id("tok"),
            token_type=TOKEN_TYPE_AGENT,
            issued_at=now,
            expires_at=now + MAX_TOKEN_TTL,
            agent_id=agent_id,
            model_id=model_id,
            session_id=session_id,
            goal_hash=goal_hash,
        )

        token_str = _serialize_token(claims, self._secret)
        identity.token_id = claims.token_id
        self._agents[agent_id] = identity
        self._tokens[claims.token_id] = False  # not revoked
        self._save_agent(identity)
        self._save_token_record(claims.token_id, False)

        logger.info(
            "agent_registered",
            agent_id=agent_id,
            model_id=model_id,
            session_id=session_id[:8],
        )

        return TrustToken(claims=claims, token_string=token_str)

    # ------------------------------------------------------------------
    # Delegation
    # ------------------------------------------------------------------

    def request_delegation(self, req: DelegationRequest) -> TrustToken:
        """
        An orchestrator requests a delegation token to invoke a subagent.
        Returns a scoped token the orchestrator passes to the subagent.
        """
        # Verify orchestrator's own token
        valid, orch_claims = _deserialize_token(req.orchestrator_token, self._secret)
        if not valid or orch_claims is None:
            raise TrustFabricError("Orchestrator token has invalid signature")
        if orch_claims.is_expired():
            raise TrustFabricError("Orchestrator token is expired")
        if self._tokens.get(orch_claims.token_id, True):
            raise TrustFabricError("Orchestrator token has been revoked")

        orch_agent = self._agents.get(orch_claims.agent_id)
        if not orch_agent:
            raise TrustFabricError(
                f"Orchestrator agent {orch_claims.agent_id} is not registered"
            )
        if orch_agent.is_revoked:
            raise TrustFabricError("Orchestrator agent has been revoked")
        if orch_agent.integrity_score < self.integrity_threshold:
            raise TrustFabricError(
                f"Orchestrator goal integrity too low to delegate "
                f"({orch_agent.integrity_score:.2f} < {self.integrity_threshold})"
            )

        # Depth check
        depth = orch_claims.delegation_depth + 1
        if depth > DELEGATION_DEPTH_LIMIT:
            raise TrustFabricError(
                f"Delegation depth limit ({DELEGATION_DEPTH_LIMIT}) exceeded"
            )

        # TTL cap
        ttl = min(req.ttl, MAX_TOKEN_TTL)
        now = time.time()
        task_hash = hashlib.sha256(req.task_description.encode()).hexdigest()

        claims = TokenClaims(
            token_id=_generate_id("dtok"),
            token_type=TOKEN_TYPE_DELEGATION,
            issued_at=now,
            expires_at=now + ttl,
            agent_id=orch_claims.agent_id,
            model_id=orch_claims.model_id,
            session_id=orch_claims.session_id,
            goal_hash=orch_claims.goal_hash,
            orchestrator_id=orch_claims.agent_id,
            recipient_agent_id=req.recipient_agent_id,
            task_hash=task_hash,
            allowed_tools=list(req.allowed_tools),
            delegation_depth=depth,
            parent_token_id=orch_claims.token_id,
        )

        token_str = _serialize_token(claims, self._secret)
        self._tokens[claims.token_id] = False
        self._save_token_record(claims.token_id, False)

        logger.info(
            "delegation_issued",
            orchestrator=orch_claims.agent_id,
            recipient=req.recipient_agent_id,
            depth=depth,
            tools=req.allowed_tools,
            token_id=claims.token_id[:12],
        )

        return TrustToken(claims=claims, token_string=token_str)

    # ------------------------------------------------------------------
    # Verification
    # ------------------------------------------------------------------

    def verify_invocation(self, req: InvocationRequest) -> VerificationOutcome:
        """
        Verify that a subagent is authorized to invoke a specific tool,
        given its delegation token.
        """
        events: list[SecurityEvent] = []

        # Parse and verify signature
        valid, claims = _deserialize_token(req.delegation_token, self._secret)
        if not valid or claims is None:
            ev = self._make_event(
                req, Severity.CRITICAL, "Trust token signature invalid",
                "Agent presented a delegation token with an invalid signature. "
                "Possible token forgery or interception.",
            )
            events.append(ev)
            return VerificationOutcome(
                result=VerificationResult.INVALID_SIGNATURE,
                allowed=False,
                reason="Token signature is invalid",
                events=events,
            )

        # Check expiry
        if claims.is_expired():
            ev = self._make_event(
                req, Severity.HIGH, "Trust token expired",
                f"Delegation token {claims.token_id[:12]} has expired.",
            )
            events.append(ev)
            return VerificationOutcome(
                result=VerificationResult.EXPIRED,
                allowed=False,
                reason=f"Delegation token expired at {claims.expires_at:.0f}",
                claims=claims,
                events=events,
            )

        # Check revocation
        if self._tokens.get(claims.token_id, True):
            ev = self._make_event(
                req, Severity.CRITICAL, "Revoked trust token presented",
                f"Agent presented revoked delegation token {claims.token_id[:12]}.",
            )
            events.append(ev)
            return VerificationOutcome(
                result=VerificationResult.REVOKED,
                allowed=False,
                reason="Token has been revoked",
                claims=claims,
                events=events,
            )

        # Recipient check
        if claims.recipient_agent_id and claims.recipient_agent_id != req.agent_id:
            ev = self._make_event(
                req, Severity.CRITICAL, "Token presented by wrong agent",
                f"Token was issued for agent {claims.recipient_agent_id!r} but "
                f"presented by {req.agent_id!r}. Possible token theft.",
            )
            events.append(ev)
            return VerificationOutcome(
                result=VerificationResult.WRONG_RECIPIENT,
                allowed=False,
                reason=f"Token is not valid for agent {req.agent_id}",
                claims=claims,
                events=events,
            )

        # Tool scope check (wildcard "*" allows any tool)
        if claims.allowed_tools and "*" not in claims.allowed_tools:
            if req.tool_name not in claims.allowed_tools:
                ev = self._make_event(
                    req, Severity.HIGH, f"Tool not in delegation scope: {req.tool_name}",
                    f"Agent attempted to use {req.tool_name!r} but delegation only "
                    f"permits: {', '.join(claims.allowed_tools)}",
                )
                events.append(ev)
                return VerificationOutcome(
                    result=VerificationResult.TOOL_NOT_DELEGATED,
                    allowed=False,
                    reason=f"Tool {req.tool_name!r} is not in delegation scope",
                    claims=claims,
                    events=events,
                )

        # Orchestrator integrity check
        orch = self._agents.get(claims.orchestrator_id)
        if orch and orch.integrity_score < self.integrity_threshold:
            ev = self._make_event(
                req, Severity.CRITICAL, "Orchestrator goal integrity compromised",
                f"Orchestrator {claims.orchestrator_id} has goal integrity "
                f"{orch.integrity_score:.2f}, below threshold {self.integrity_threshold}. "
                f"Delegation is no longer trustworthy.",
            )
            events.append(ev)
            return VerificationOutcome(
                result=VerificationResult.ORCHESTRATOR_COMPROMISED,
                allowed=False,
                reason="Orchestrator goal integrity is below threshold",
                claims=claims,
                events=events,
            )

        # Depth check
        if claims.delegation_depth > DELEGATION_DEPTH_LIMIT:
            ev = self._make_event(
                req, Severity.HIGH, "Delegation depth limit exceeded",
                f"Token chain depth {claims.delegation_depth} exceeds limit "
                f"{DELEGATION_DEPTH_LIMIT}.",
            )
            events.append(ev)
            return VerificationOutcome(
                result=VerificationResult.DEPTH_EXCEEDED,
                allowed=False,
                reason="Delegation chain is too deep",
                claims=claims,
                events=events,
            )

        logger.debug(
            "invocation_authorized",
            agent_id=req.agent_id,
            tool=req.tool_name,
            token_id=claims.token_id[:12],
            depth=claims.delegation_depth,
        )

        return VerificationOutcome(
            result=VerificationResult.OK,
            allowed=True,
            reason="Invocation authorized",
            claims=claims,
            events=events,
        )

    # ------------------------------------------------------------------
    # Revocation
    # ------------------------------------------------------------------

    def revoke_agent(self, agent_id: str, reason: str = "") -> bool:
        """Revoke an agent and all its tokens."""
        agent = self._agents.get(agent_id)
        if not agent:
            return False
        agent.is_revoked = True
        agent.revoked_reason = reason
        if agent.token_id:
            self._tokens[agent.token_id] = True
            self._save_token_record(agent.token_id, True)
        self._save_agent(agent)
        logger.warning("agent_revoked", agent_id=agent_id, reason=reason)
        return True

    def revoke_token(self, token_id: str) -> bool:
        """Revoke a specific token (e.g., a delegation token)."""
        if token_id not in self._tokens:
            return False
        self._tokens[token_id] = True
        self._save_token_record(token_id, True)
        logger.warning("token_revoked", token_id=token_id[:12])
        return True

    # ------------------------------------------------------------------
    # Agent state updates
    # ------------------------------------------------------------------

    def update_integrity_score(self, agent_id: str, score: float) -> None:
        """Called by the goal integrity engine to push updated scores."""
        agent = self._agents.get(agent_id)
        if agent:
            agent.integrity_score = max(0.0, min(1.0, score))

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get_agent(self, agent_id: str) -> Optional[AgentIdentity]:
        return self._agents.get(agent_id)

    def get_agent_by_session(self, session_id: str) -> Optional[AgentIdentity]:
        for agent in self._agents.values():
            if agent.session_id == session_id:
                return agent
        return None

    def list_agents(self) -> list[AgentIdentity]:
        return list(self._agents.values())

    def is_token_valid(self, token_id: str) -> bool:
        """True if token exists and is not revoked."""
        return self._tokens.get(token_id, True) is False

    def stats(self) -> dict:
        active = sum(1 for a in self._agents.values() if not a.is_revoked)
        revoked = len(self._agents) - active
        return {
            "total_agents": len(self._agents),
            "active_agents": active,
            "revoked_agents": revoked,
            "total_tokens": len(self._tokens),
            "integrity_threshold": self.integrity_threshold,
        }

    # ------------------------------------------------------------------
    # Event helpers
    # ------------------------------------------------------------------

    def _make_event(
        self,
        req: InvocationRequest,
        severity: Severity,
        title: str,
        description: str,
    ) -> SecurityEvent:
        return SecurityEvent(
            session_id=req.session_id,
            event_type=EventType.TRUST_VIOLATION,
            severity=severity,
            title=title,
            description=description,
            details={
                "agent_id": req.agent_id,
                "tool_name": req.tool_name,
            },
            cmmc_controls=["3.1.1", "3.1.2", "3.5.1", "3.5.2", "3.13.1"],
            nist_controls=["AC-2", "AC-3", "IA-1", "IA-2", "SC-7"],
        )

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _ensure_tables(self) -> None:
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS trust_agents (
                        agent_id TEXT PRIMARY KEY,
                        agent_json TEXT NOT NULL,
                        updated_at REAL NOT NULL
                    )
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS trust_tokens (
                        token_id TEXT PRIMARY KEY,
                        is_revoked INTEGER NOT NULL DEFAULT 0,
                        updated_at REAL NOT NULL
                    )
                """)
                conn.commit()
        except Exception as e:
            logger.warning("trust_fabric_db_init_failed", error=str(e))

    def _load_state(self) -> None:
        try:
            with sqlite3.connect(self.db_path) as conn:
                for row in conn.execute("SELECT agent_json FROM trust_agents"):
                    try:
                        a = AgentIdentity.from_dict(json.loads(row[0]))
                        self._agents[a.agent_id] = a
                    except Exception:
                        pass
                for row in conn.execute("SELECT token_id, is_revoked FROM trust_tokens"):
                    self._tokens[row[0]] = bool(row[1])
        except Exception as e:
            logger.debug("trust_fabric_load_failed", error=str(e))

    def _save_agent(self, agent: AgentIdentity) -> None:
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute(
                    "INSERT OR REPLACE INTO trust_agents (agent_id, agent_json, updated_at)"
                    " VALUES (?, ?, ?)",
                    (agent.agent_id, json.dumps(agent.to_dict()), time.time()),
                )
                conn.commit()
        except Exception as e:
            logger.warning("trust_agent_save_failed", error=str(e))

    def _save_token_record(self, token_id: str, is_revoked: bool) -> None:
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute(
                    "INSERT OR REPLACE INTO trust_tokens (token_id, is_revoked, updated_at)"
                    " VALUES (?, ?, ?)",
                    (token_id, int(is_revoked), time.time()),
                )
                conn.commit()
        except Exception as e:
            logger.warning("trust_token_save_failed", error=str(e))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _generate_id(prefix: str) -> str:
    return f"{prefix}_{secrets.token_hex(8)}"


def _hash_goal(goal: str) -> str:
    return hashlib.sha256(goal.encode()).hexdigest()[:16]
