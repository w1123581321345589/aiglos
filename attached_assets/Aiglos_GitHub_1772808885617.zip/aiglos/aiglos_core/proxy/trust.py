"""
Aiglos MCP Server Trust Registry (T8).

The proxy intercepts tool calls. But before that, it needs to decide whether
it should connect to an upstream MCP server at all.

The Trust Registry solves a problem that no other AI security product addresses:
an agent can be instructed (via prompt injection or a malicious system prompt)
to connect to an attacker-controlled MCP server. That server presents a
legitimate-looking tool list, but its tool implementations exfiltrate data,
execute arbitrary code on the host, or manipulate the agent's behavior.

Without a trust registry, the proxy happily forwards everything to whatever
server the agent asks to connect to. With the trust registry, only explicitly
approved servers can receive traffic.

How it works
------------
Every MCP server has an identity: host + port + a fingerprint computed from
the server's declared tool manifest (tool names + schemas) at connection time.

The registry maintains three lists:
  - ALLOWED: these servers are explicitly trusted; connections proceed
  - BLOCKED: these servers are explicitly forbidden; connections are rejected
  - UNKNOWN: default behavior per policy (ALLOW_UNKNOWN, DENY_UNKNOWN, ALERT_UNKNOWN)

Server fingerprinting
---------------------
On first connection to an unknown server, Aiglos:
  1. Retrieves the server's tool manifest (tools/list)
  2. Computes SHA-256 of canonical JSON of the manifest
  3. Checks if the fingerprint matches a known entry
  4. If the manifest has changed since last connection, raises a TOOL_REDEFINITION event

This catches the attack where an attacker hijacks an MCP server and modifies
its tool definitions to include malicious implementations behind legitimate-
looking names.

Persistence
-----------
The registry is stored as a YAML file (aiglos_trust.yaml) that can be
committed to version control and audited. The fingerprint database is stored
in the audit SQLite database.

Deployment modes
----------------
STRICT:  Only ALLOWED servers. Unknown = rejected. Recommended for production.
AUDIT:   All servers allowed, but unknown/changed servers emit events.
PERMISSIVE: All servers allowed, events only on BLOCKED list.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any

import structlog

from aiglos_core.types import EventType, SecurityEvent, Severity

logger = structlog.get_logger("aiglos.trust")


# ---------------------------------------------------------------------------
# Enums and data structures
# ---------------------------------------------------------------------------

class TrustMode(str, Enum):
    STRICT = "strict"           # Unknown servers are blocked
    AUDIT = "audit"             # Unknown servers are allowed but flagged
    PERMISSIVE = "permissive"   # Only BLOCKED list is enforced


class TrustStatus(str, Enum):
    ALLOWED = "allowed"
    BLOCKED = "blocked"
    UNKNOWN = "unknown"


@dataclass
class ServerIdentity:
    """Uniquely identifies an MCP server."""
    host: str
    port: int
    alias: str = ""             # Human-readable name (optional)
    fingerprint: str = ""       # SHA-256 of tool manifest
    fingerprint_updated: float = 0.0
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    connection_count: int = 0
    blocked_reason: str = ""

    @property
    def address(self) -> str:
        return f"{self.host}:{self.port}"

    def to_dict(self) -> dict:
        return {
            "host": self.host,
            "port": self.port,
            "alias": self.alias,
            "fingerprint": self.fingerprint,
            "fingerprint_updated": self.fingerprint_updated,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
            "connection_count": self.connection_count,
        }


@dataclass
class TrustEntry:
    """A single entry in the trust registry."""
    status: TrustStatus
    identity: ServerIdentity
    added_by: str = "aiglos"
    added_at: float = field(default_factory=time.time)
    note: str = ""

    def to_dict(self) -> dict:
        return {
            "status": self.status.value,
            "host": self.identity.host,
            "port": self.identity.port,
            "alias": self.identity.alias,
            "fingerprint": self.identity.fingerprint,
            "added_by": self.added_by,
            "added_at": self.added_at,
            "note": self.note,
        }


@dataclass
class TrustDecision:
    """Result of a trust check."""
    allowed: bool
    status: TrustStatus
    reason: str
    events: list[SecurityEvent] = field(default_factory=list)
    fingerprint_changed: bool = False
    is_new_server: bool = False


# ---------------------------------------------------------------------------
# Manifest fingerprinting
# ---------------------------------------------------------------------------

def fingerprint_manifest(tools: list[dict]) -> str:
    """
    Compute a stable SHA-256 fingerprint of an MCP tool manifest.

    Only tool names and input schema shapes are included -- not descriptions,
    which can change legitimately. This ensures the fingerprint catches
    actual behavioral changes (new tools, changed schemas) without false
    positives on documentation updates.
    """
    canonical = []
    for tool in sorted(tools, key=lambda t: t.get("name", "")):
        entry = {
            "name": tool.get("name", ""),
            "schema": _normalize_schema(tool.get("inputSchema") or tool.get("input_schema", {})),
        }
        canonical.append(entry)
    serialized = json.dumps(canonical, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(serialized.encode()).hexdigest()


def _normalize_schema(schema: dict) -> dict:
    """Extract only structural information from a JSON Schema."""
    if not isinstance(schema, dict):
        return {}
    result = {}
    if "type" in schema:
        result["type"] = schema["type"]
    if "properties" in schema:
        result["properties"] = {
            k: _normalize_schema(v)
            for k, v in sorted(schema["properties"].items())
        }
    if "required" in schema:
        result["required"] = sorted(schema["required"])
    return result


# ---------------------------------------------------------------------------
# Trust Registry
# ---------------------------------------------------------------------------

class ServerTrustRegistry:
    """
    Manages trust relationships between Aiglos and upstream MCP servers.

    Persists to a YAML file for auditability and version control.
    Fingerprint history stored in SQLite via the audit log.
    """

    def __init__(
        self,
        trust_file: str = "aiglos_trust.yaml",
        mode: TrustMode = TrustMode.AUDIT,
    ) -> None:
        self.trust_file = Path(trust_file)
        self.mode = mode
        self._entries: dict[str, TrustEntry] = {}   # address -> TrustEntry
        self._fingerprint_history: dict[str, list[str]] = {}  # address -> [fp1, fp2, ...]
        self._load()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def check(
        self,
        host: str,
        port: int,
        manifest_tools: list[dict] | None = None,
    ) -> TrustDecision:
        """
        Check whether a connection to host:port is trusted.
        Optionally validates the tool manifest fingerprint.
        """
        address = f"{host}:{port}"
        now = time.time()
        events: list[SecurityEvent] = []
        fingerprint_changed = False
        is_new = address not in self._entries

        # Compute fingerprint if manifest provided
        new_fp = fingerprint_manifest(manifest_tools) if manifest_tools else ""

        if address in self._entries:
            entry = self._entries[address]
            entry.identity.last_seen = now
            entry.identity.connection_count += 1

            # Fingerprint change detection
            if new_fp and entry.identity.fingerprint and new_fp != entry.identity.fingerprint:
                fingerprint_changed = True
                old_fp = entry.identity.fingerprint
                entry.identity.fingerprint = new_fp
                entry.identity.fingerprint_updated = now
                self._record_fingerprint(address, new_fp)
                self._save()

                # Emit tool redefinition event
                events.append(SecurityEvent(
                    event_type=EventType.TOOL_REDEFINITION,
                    severity=Severity.CRITICAL,
                    title=f"MCP server tool manifest changed: {address}",
                    description=(
                        f"Server {address} ({entry.identity.alias or 'unnamed'}) has a different "
                        f"tool manifest than on last connection. This may indicate the server was "
                        f"compromised or replaced. Previous fingerprint: {old_fp[:16]}... "
                        f"New: {new_fp[:16]}..."
                    ),
                    details={
                        "address": address,
                        "alias": entry.identity.alias,
                        "old_fingerprint": old_fp,
                        "new_fingerprint": new_fp,
                        "connection_count": entry.identity.connection_count,
                    },
                    cmmc_controls=["3.13.1", "3.14.2", "3.1.1"],
                    nist_controls=["SC-7", "SI-3", "AC-3"],
                ))
                logger.warning(
                    "server_manifest_changed",
                    address=address,
                    old_fp=old_fp[:16],
                    new_fp=new_fp[:16],
                )

            if entry.status == TrustStatus.BLOCKED:
                events.append(SecurityEvent(
                    event_type=EventType.SERVER_UNTRUSTED,
                    severity=Severity.CRITICAL,
                    title=f"Connection to blocked MCP server rejected: {address}",
                    description=(
                        f"Agent attempted to connect to explicitly blocked server {address}. "
                        f"Block reason: {entry.identity.blocked_reason or 'No reason provided'}"
                    ),
                    details={"address": address, "alias": entry.identity.alias},
                    cmmc_controls=["3.13.1", "3.1.1", "3.1.2"],
                    nist_controls=["SC-7", "AC-3"],
                ))
                return TrustDecision(
                    allowed=False,
                    status=TrustStatus.BLOCKED,
                    reason=f"Server {address} is on the blocked list: {entry.identity.blocked_reason or 'no reason'}",
                    events=events,
                    fingerprint_changed=fingerprint_changed,
                )

            if entry.status == TrustStatus.ALLOWED:
                return TrustDecision(
                    allowed=True,
                    status=TrustStatus.ALLOWED,
                    reason=f"Server {address} is explicitly trusted",
                    events=events,
                    fingerprint_changed=fingerprint_changed,
                )

        # Unknown server
        if is_new:
            # Auto-register as unknown
            identity = ServerIdentity(
                host=host, port=port,
                fingerprint=new_fp,
                fingerprint_updated=now if new_fp else 0.0,
                first_seen=now, last_seen=now,
                connection_count=1,
            )
            entry = TrustEntry(
                status=TrustStatus.UNKNOWN,
                identity=identity,
                added_by="auto-discovery",
            )
            self._entries[address] = entry
            if new_fp:
                self._record_fingerprint(address, new_fp)
            self._save()

        events.append(SecurityEvent(
            event_type=EventType.SERVER_UNTRUSTED,
            severity=Severity.HIGH if self.mode == TrustMode.STRICT else Severity.MEDIUM,
            title=f"Unknown MCP server: {address}",
            description=(
                f"Agent is connecting to an MCP server not in the trust registry: {address}. "
                f"Mode: {self.mode.value}. "
                + ("Connection blocked." if self.mode == TrustMode.STRICT else "Connection allowed with warning.")
            ),
            details={
                "address": address,
                "mode": self.mode.value,
                "fingerprint": new_fp[:16] + "..." if new_fp else "not computed",
                "is_new": is_new,
            },
            cmmc_controls=["3.13.1", "3.1.1"],
            nist_controls=["SC-7", "AC-3"],
        ))

        if self.mode == TrustMode.STRICT:
            logger.warning("unknown_server_blocked", address=address, mode=self.mode.value)
            return TrustDecision(
                allowed=False,
                status=TrustStatus.UNKNOWN,
                reason=f"Server {address} is not in the trust registry and mode is STRICT",
                events=events,
                fingerprint_changed=fingerprint_changed,
                is_new_server=is_new,
            )

        # AUDIT or PERMISSIVE: allow but log
        logger.info("unknown_server_allowed", address=address, mode=self.mode.value)
        return TrustDecision(
            allowed=True,
            status=TrustStatus.UNKNOWN,
            reason=f"Server {address} is not in trust registry; allowed in {self.mode.value} mode",
            events=events,
            fingerprint_changed=fingerprint_changed,
            is_new_server=is_new,
        )

    def allow(
        self,
        host: str,
        port: int,
        alias: str = "",
        note: str = "",
        added_by: str = "user",
    ) -> TrustEntry:
        """Explicitly allow a server."""
        address = f"{host}:{port}"
        existing = self._entries.get(address)
        identity = existing.identity if existing else ServerIdentity(host=host, port=port, alias=alias)
        identity.alias = alias or identity.alias
        entry = TrustEntry(
            status=TrustStatus.ALLOWED,
            identity=identity,
            added_by=added_by,
            note=note,
        )
        self._entries[address] = entry
        self._save()
        logger.info("server_allowed", address=address, alias=alias)
        return entry

    def block(
        self,
        host: str,
        port: int,
        alias: str = "",
        reason: str = "",
        added_by: str = "user",
    ) -> TrustEntry:
        """Explicitly block a server."""
        address = f"{host}:{port}"
        existing = self._entries.get(address)
        identity = existing.identity if existing else ServerIdentity(host=host, port=port, alias=alias)
        identity.alias = alias or identity.alias
        identity.blocked_reason = reason
        entry = TrustEntry(
            status=TrustStatus.BLOCKED,
            identity=identity,
            added_by=added_by,
            note=reason,
        )
        self._entries[address] = entry
        self._save()
        logger.warning("server_blocked", address=address, reason=reason)
        return entry

    def remove(self, host: str, port: int) -> bool:
        """Remove a server from the registry (returns to UNKNOWN)."""
        address = f"{host}:{port}"
        if address in self._entries:
            del self._entries[address]
            self._save()
            return True
        return False

    def list_entries(self) -> list[TrustEntry]:
        return list(self._entries.values())

    def get_entry(self, host: str, port: int) -> TrustEntry | None:
        return self._entries.get(f"{host}:{port}")

    def get_fingerprint_history(self, host: str, port: int) -> list[str]:
        return self._fingerprint_history.get(f"{host}:{port}", [])

    def stats(self) -> dict:
        by_status: dict[str, int] = {}
        for e in self._entries.values():
            by_status[e.status.value] = by_status.get(e.status.value, 0) + 1
        return {
            "total": len(self._entries),
            "mode": self.mode.value,
            **by_status,
        }

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _record_fingerprint(self, address: str, fp: str) -> None:
        hist = self._fingerprint_history.setdefault(address, [])
        if not hist or hist[-1] != fp:
            hist.append(fp)
            # Keep last 10
            self._fingerprint_history[address] = hist[-10:]

    def _save(self) -> None:
        try:
            import yaml
            data = {
                "aiglos_trust": "1.0",
                "mode": self.mode.value,
                "servers": [e.to_dict() for e in self._entries.values()],
            }
            self.trust_file.write_text(
                yaml.dump(data, default_flow_style=False, sort_keys=True)
            )
        except Exception as e:
            logger.warning("trust_save_failed", error=str(e))

    def _load(self) -> None:
        if not self.trust_file.exists():
            return
        try:
            import yaml
            data = yaml.safe_load(self.trust_file.read_text()) or {}
            mode_str = data.get("mode", self.mode.value)
            try:
                self.mode = TrustMode(mode_str)
            except ValueError:
                pass
            for server in data.get("servers", []):
                host = server.get("host", "")
                port = server.get("port", 0)
                if not host or not port:
                    continue
                address = f"{host}:{port}"
                identity = ServerIdentity(
                    host=host,
                    port=port,
                    alias=server.get("alias", ""),
                    fingerprint=server.get("fingerprint", ""),
                    fingerprint_updated=server.get("fingerprint_updated", 0.0),
                )
                try:
                    status = TrustStatus(server.get("status", "unknown"))
                except ValueError:
                    status = TrustStatus.UNKNOWN
                identity.blocked_reason = server.get("note", "") if status == TrustStatus.BLOCKED else ""
                self._entries[address] = TrustEntry(
                    status=status,
                    identity=identity,
                    added_by=server.get("added_by", "file"),
                    added_at=server.get("added_at", 0.0),
                    note=server.get("note", ""),
                )
        except Exception as e:
            logger.warning("trust_load_failed", error=str(e))

    def generate_default_file(self, path: str | None = None) -> str:
        """Generate a starter trust registry YAML file."""
        target = path or str(self.trust_file)
        content = """# Aiglos MCP Server Trust Registry
# Generated by: aiglos init
#
# Mode options:
#   strict     - Only ALLOWED servers can receive traffic. Unknown = blocked.
#   audit      - All servers allowed, unknown/changed servers emit events.
#   permissive - Only BLOCKED list enforced, everything else allowed.
#
# For production DoD/CMMC environments: use strict mode.
# For development: use audit mode.

aiglos_trust: "1.0"
mode: audit

servers:
  # Add your trusted MCP servers below.
  # Example:
  #
  # - status: allowed
  #   host: localhost
  #   port: 18789
  #   alias: primary-dev-server
  #   note: Local development MCP server
  #
  # - status: blocked
  #   host: malicious-mcp.example.com
  #   port: 443
  #   alias: known-bad-server
  #   note: Reported exfiltration server - block all connections
"""
        Path(target).write_text(content)
        return target
