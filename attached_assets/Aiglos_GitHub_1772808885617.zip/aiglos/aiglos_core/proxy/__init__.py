"""
Aiglos MCP Security Proxy.

Transparent WebSocket proxy that sits between any MCP client and any MCP server.
Every tool call passes through this proxy for:
  - Argument sanitization and schema validation
  - Credential and secret scanning
  - Policy engine evaluation
  - Goal integrity checking
  - Audit logging

Architecture:
  [MCP Client] <--WebSocket--> [Aiglos Proxy :8765] <--WebSocket--> [MCP Server :18789]

The proxy is transparent: if all checks pass, the original call is forwarded
with zero modification to the upstream server. If checks fail, the call is
blocked and an error is returned to the client.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import time
import uuid
from typing import Any

import structlog
import websockets
from websockets.server import WebSocketServerProtocol
from websockets.client import WebSocketClientProtocol

from aiglos_core.types import (
    AgentIdentity,
    EventType,
    PolicyAction,
    ProxyConfig,
    SecurityEvent,
    SessionContext,
    Severity,
    ToolCall,
    ToolResponse,
)
from aiglos_core.audit import AuditLog
from aiglos_core.scanner import scan
from aiglos_core.policy import PolicyEngine
from aiglos_core.intelligence import GoalIntegrityEngine
from aiglos_core.proxy.trust import ServerTrustRegistry, TrustMode, fingerprint_manifest
from aiglos_core.intelligence.baseline import BehavioralBaselineEngine
from aiglos_core.intelligence.attestation import AttestationBuilder, attest_session
from aiglos_core.integrations import AlertDispatcher, dispatcher_from_config

logger = structlog.get_logger("aiglos.proxy")


# ---------------------------------------------------------------------------
# Session registry (in-memory, per proxy instance)
# ---------------------------------------------------------------------------

class SessionRegistry:
    def __init__(self) -> None:
        self._sessions: dict[str, SessionContext] = {}

    def create(self, identity: AgentIdentity | None = None) -> SessionContext:
        ctx = SessionContext()
        if identity:
            ctx.identity = identity
        self._sessions[ctx.identity.session_id] = ctx
        return ctx

    def get(self, session_id: str) -> SessionContext | None:
        return self._sessions.get(session_id)

    def get_by_connection(self, conn_id: str) -> SessionContext | None:
        """Find the session associated with a WebSocket connection."""
        return self._sessions.get(conn_id)

    def close(self, session_id: str) -> None:
        ctx = self._sessions.get(session_id)
        if ctx:
            ctx.is_active = False
            ctx.end_time = time.time()

    def all_active(self) -> list[SessionContext]:
        return [s for s in self._sessions.values() if s.is_active]


# ---------------------------------------------------------------------------
# Message interceptor
# ---------------------------------------------------------------------------

class MCPMessageInterceptor:
    """
    Parses MCP JSON-RPC messages, extracts tool calls,
    and routes them through the security pipeline.
    """

    def __init__(
        self,
        config: ProxyConfig,
        audit: AuditLog,
        policy: PolicyEngine,
        session: SessionContext,
        alert_callbacks: list,
        goal_engine: GoalIntegrityEngine | None = None,
    ) -> None:
        self.config = config
        self.audit = audit
        self.policy = policy
        self.session = session
        self.alert_callbacks = alert_callbacks
        self.goal_engine = goal_engine
        self._call_map: dict[str, ToolCall] = {}  # request_id -> ToolCall

    async def process_client_message(
        self, raw: str | bytes
    ) -> tuple[str | bytes | None, bool]:
        """
        Process a message from the MCP client before forwarding to server.
        Returns (message_to_forward, should_forward).
        If should_forward is False, the message was blocked.
        """
        try:
            msg = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            # Not JSON, pass through
            return raw, True

        method = msg.get("method", "")
        msg_id = msg.get("id")

        # Intercept tool use calls
        # MCP spec: tools/call method
        if method in ("tools/call", "tool_use"):
            call = self._build_tool_call(msg)
            self._call_map[str(msg_id)] = call

            # Run security pipeline
            blocked, reason, events = await self._run_security_pipeline(call)

            # Log everything
            for ev in events:
                ev.session_id = self.session.identity.session_id
                self.session.events.append(ev)
                self.audit.record_event(ev)
                await self._fire_alerts(ev)

            self.audit.record_tool_call(call)
            self.session.tool_calls.append(call)

            if blocked:
                # Return JSON-RPC error to client instead of forwarding
                error_response = json.dumps({
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "error": {
                        "code": -32600,
                        "message": f"Aiglos: Tool call blocked. {reason}",
                    }
                })
                logger.warning(
                    "tool_call_blocked",
                    tool=call.tool_name,
                    reason=reason,
                    session=self.session.identity.session_id,
                )
                return error_response, False

            # Forward (potentially with sanitized args)
            if call.sanitized_arguments is not None:
                msg["params"]["arguments"] = call.sanitized_arguments
                return json.dumps(msg), True

        return raw, True

    async def process_server_message(self, raw: str | bytes) -> str | bytes:
        """
        Process a response from the MCP server before returning to client.
        Scans for credentials in responses.
        """
        try:
            msg = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return raw

        msg_id = str(msg.get("id", ""))
        call = self._call_map.pop(msg_id, None)

        if call and "result" in msg:
            response = ToolResponse(
                call_id=call.id,
                session_id=self.session.identity.session_id,
                tool_name=call.tool_name,
                result=msg["result"],
                timestamp=time.time(),
            )

            # Scan the response for credentials
            if self.config.enable_credential_scanning:
                events = scan(msg["result"], path="response")
                response.secrets_detected = [e.title for e in events]
                for ev in events:
                    ev.session_id = self.session.identity.session_id
                    self.audit.record_event(ev)
                    await self._fire_alerts(ev)

            self.audit.record_tool_response(response)

        return raw

    def _build_tool_call(self, msg: dict) -> ToolCall:
        params = msg.get("params", {})
        tool_name = params.get("name", params.get("tool", "unknown"))
        arguments = params.get("arguments", params.get("input", {}))

        call = ToolCall(
            session_id=self.session.identity.session_id,
            server_id=params.get("server_id", "unknown"),
            tool_name=tool_name,
            arguments=arguments,
            raw_payload=msg,
        )
        return call

    async def _run_security_pipeline(
        self, call: ToolCall
    ) -> tuple[bool, str, list[SecurityEvent]]:
        """
        Run the full security pipeline against a tool call.
        Returns (is_blocked, block_reason, events).
        """
        events: list[SecurityEvent] = []
        blocked = False
        block_reason = ""

        # 1. Credential scanning on arguments
        if self.config.enable_credential_scanning:
            cred_events = scan(call.arguments, path="arguments")
            events.extend(cred_events)

            critical_creds = [e for e in cred_events if e.severity == Severity.CRITICAL]
            if critical_creds:
                blocked = True
                block_reason = f"Critical credential detected in arguments: {critical_creds[0].title}"
                call.allowed = False
                call.blocked_reason = block_reason
                return blocked, block_reason, events

        # 2. Policy engine evaluation
        if self.config.enable_policy_engine:
            result = self.policy.evaluate(call)

            if result.action == PolicyAction.BLOCK:
                blocked = True
                block_reason = f"Policy '{result.rule_name}': {result.reason}"
                call.allowed = False
                call.blocked_reason = block_reason
                events.append(SecurityEvent(
                    event_type=EventType.POLICY_VIOLATION,
                    severity=result.severity,
                    title=f"Policy violation: {result.rule_name}",
                    description=block_reason,
                    details={
                        "tool": call.tool_name,
                        "rule": result.rule_name,
                        "action": result.action.value,
                    },
                    cmmc_controls=["3.1.1", "3.1.2"],
                    nist_controls=["AC-2", "AC-3"],
                ))
                return blocked, block_reason, events

            elif result.action in (PolicyAction.ALERT, PolicyAction.LOG):
                sev = result.severity if result.action == PolicyAction.ALERT else Severity.INFO
                events.append(SecurityEvent(
                    event_type=EventType.POLICY_VIOLATION,
                    severity=sev,
                    title=f"Policy match: {result.rule_name}",
                    description=result.reason,
                    details={
                        "tool": call.tool_name,
                        "rule": result.rule_name,
                        "action": result.action.value,
                    },
                    cmmc_controls=["3.3.1", "3.3.2"],
                    nist_controls=["AU-2", "AU-12"],
                ))

        # 3. Behavioral baseline anomaly scoring
        if self.config.enable_behavioral_baseline and hasattr(self, "_baseline_engine_ref"):
            bl_result = self._baseline_engine_ref.record_tool_call(
                session_id=self.session.identity.session_id,
                tool_name=call.tool_name,
                arguments=call.arguments,
            )
            for bl_ev in bl_result.events:
                bl_ev.session_id = self.session.identity.session_id
            events.extend(bl_result.events)

        # 4. Goal integrity evaluation
        if self.config.enable_goal_integrity and self.goal_engine and self.session.authorized_goal:
            gi_score, gi_events = await self.goal_engine.evaluate(self.session, call)
            for gi_ev in gi_events:
                gi_ev.session_id = self.session.identity.session_id
            events.extend(gi_events)
            if gi_score.score < 0.15 and self.session.authorized_goal:
                blocked = True
                block_reason = (
                    f"Goal integrity critically low ({gi_score.score:.2f}). "
                    "Agent actions no longer align with authorized objective."
                )
                call.allowed = False
                call.blocked_reason = block_reason

        return blocked, block_reason, events

    async def _fire_alerts(self, event: SecurityEvent) -> None:
        for cb in self.alert_callbacks:
            try:
                await cb(event)
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Core Proxy
# ---------------------------------------------------------------------------

class MCPSecurityProxy:
    """
    The Aiglos MCP Security Proxy.

    Starts a WebSocket server. For each client connection, opens a
    corresponding connection to the upstream MCP server and bidirectionally
    proxies all messages through the security pipeline.
    """

    def __init__(self, config: ProxyConfig | None = None) -> None:
        self.config = config or ProxyConfig()
        self.audit = AuditLog(self.config.audit_db_path)
        self.policy = PolicyEngine(
            policy_file=self.config.policy_file,
            profile="defense" if self.config.deployment_tier.value in ("on_prem", "gov") else "default",
        )
        self.registry = SessionRegistry()
        self.goal_engine = GoalIntegrityEngine(
            anthropic_api_key=self.config.anthropic_api_key,
            drift_threshold=self.config.goal_drift_threshold,
            enable_semantic=self.config.enable_goal_integrity,
        )
        self.trust_registry = ServerTrustRegistry(
            trust_file=self.config.trust_file,
            mode=TrustMode(self.config.trust_mode),
        )
        self.baseline_engine = BehavioralBaselineEngine(
            db_path=self.config.audit_db_path,
        )
        self.alert_callbacks: list = []
        self.dispatcher = AlertDispatcher()
        # Wire dispatcher as a primary alert callback
        self.alert_callbacks.append(self.dispatcher)
        self._server = None
        self._running = False

    def add_alert_callback(self, cb) -> None:
        self.alert_callbacks.append(cb)

    async def start(self) -> None:
        self._running = True
        logger.info(
            "proxy_starting",
            listen=f"{self.config.listen_host}:{self.config.listen_port}",
            upstream=f"{self.config.upstream_host}:{self.config.upstream_port}",
            tier=self.config.deployment_tier.value,
        )

        self._server = await websockets.serve(
            self._handle_client,
            self.config.listen_host,
            self.config.listen_port,
        )
        await self._server.wait_closed()

    async def stop(self) -> None:
        self._running = False
        if self._server:
            self._server.close()
            await self._server.wait_closed()

    async def _handle_client(self, client_ws: WebSocketServerProtocol) -> None:
        """Handle one client connection through its full lifecycle."""
        session_id = str(uuid.uuid4())
        identity = AgentIdentity(session_id=session_id)
        identity.compute_attestation()

        ctx = self.registry.create(identity)
        self.audit.record_session_start(ctx)

        # Fire session start event
        start_event = SecurityEvent(
            session_id=session_id,
            event_type=EventType.SESSION_START,
            severity=Severity.INFO,
            title="Agent session started",
            description=f"New MCP agent session initiated. ID: {session_id}",
            details={"attestation_hash": identity.attestation_hash},
            cmmc_controls=["3.3.1"],
            nist_controls=["AU-2"],
        )
        self.audit.record_event(start_event)

        logger.info("session_started", session_id=session_id)

        # Start behavioral baseline tracking for this session
        if self.config.enable_behavioral_baseline:
            self.baseline_engine.start_session(
                session_id=session_id,
                model=ctx.model_id or "unknown",
                goal=ctx.authorized_goal or "",
            )

        upstream_uri = f"ws://{self.config.upstream_host}:{self.config.upstream_port}"

        # Trust registry check before connecting to upstream
        if self.config.enable_trust_registry:
            trust_decision = self.trust_registry.check(
                host=self.config.upstream_host,
                port=self.config.upstream_port,
            )
            for ev in trust_decision.events:
                ev.session_id = session_id
                self.audit.record_event(ev)
                for cb in self.alert_callbacks:
                    try:
                        await cb(ev)
                    except Exception:
                        pass
            if not trust_decision.allowed:
                logger.warning(
                    "upstream_blocked_by_trust_registry",
                    address=f"{self.config.upstream_host}:{self.config.upstream_port}",
                    reason=trust_decision.reason,
                )
                # Close client with error
                await client_ws.close(1008, trust_decision.reason[:100])
                return

        try:
            async with websockets.connect(upstream_uri) as upstream_ws:
                interceptor = MCPMessageInterceptor(
                    config=self.config,
                    audit=self.audit,
                    policy=self.policy,
                    session=ctx,
                    alert_callbacks=self.alert_callbacks,
                    goal_engine=self.goal_engine,
                )

                # Bidirectional proxy with interception
                await asyncio.gather(
                    self._client_to_server(client_ws, upstream_ws, interceptor),
                    self._server_to_client(upstream_ws, client_ws, interceptor),
                    return_exceptions=True,
                )

        except (websockets.exceptions.WebSocketException, OSError, ConnectionRefusedError) as e:
            logger.warning("upstream_connection_failed", error=str(e))
        finally:
            self.registry.close(session_id)
            self.audit.close_session(session_id)

            end_event = SecurityEvent(
                session_id=session_id,
                event_type=EventType.SESSION_END,
                severity=Severity.INFO,
                title="Agent session ended",
                description=f"Session closed. Tool calls: {len(ctx.tool_calls)}. "
                            f"Events: {len(ctx.events)}.",
                details={
                    "tool_call_count": len(ctx.tool_calls),
                    "event_count": len(ctx.events),
                    "goal_integrity_score": ctx.goal_integrity_score,
                    "anomaly_score": ctx.anomaly_score,
                },
                cmmc_controls=["3.3.1"],
                nist_controls=["AU-2"],
            )
            self.audit.record_event(end_event)
            ctx.events.append(end_event)

            # Produce signed attestation document for this session
            try:
                attestation = attest_session(ctx)
                self.audit.record_event(SecurityEvent(
                    session_id=session_id,
                    event_type=EventType.AGENT_ATTESTED,
                    severity=Severity.INFO,
                    title="Session attestation produced",
                    description=f"Signed attestation document issued. Hash: {attestation.document_hash[:16]}...",
                    details={
                        "document_hash": attestation.document_hash,
                        "issuer": attestation.issuer,
                        "cmmc_controls_count": len(attestation.cmmc_controls_active),
                        "event_manifest_count": len(attestation.event_manifest),
                    },
                    cmmc_controls=["3.3.1", "3.3.2"],
                    nist_controls=["AU-2", "AU-9"],
                ))
                logger.info(
                    "attestation_issued",
                    session_id=session_id,
                    document_hash=attestation.document_hash[:16],
                    events_in_manifest=len(attestation.event_manifest),
                )
            except Exception as e:
                logger.warning("attestation_failed", error=str(e))

            logger.info(
                "session_ended",
                session_id=session_id,
                tool_calls=len(ctx.tool_calls),
                events=len(ctx.events),
            )

    async def _client_to_server(
        self,
        client: WebSocketServerProtocol,
        server: WebSocketClientProtocol,
        interceptor: MCPMessageInterceptor,
    ) -> None:
        async for message in client:
            processed, should_forward = await interceptor.process_client_message(message)
            if should_forward and processed is not None:
                await server.send(processed)
            elif not should_forward and processed is not None:
                # Send blocked response back to client
                await client.send(processed)

    async def _server_to_client(
        self,
        server: WebSocketClientProtocol,
        client: WebSocketServerProtocol,
        interceptor: MCPMessageInterceptor,
    ) -> None:
        async for message in server:
            processed = await interceptor.process_server_message(message)
            await client.send(processed)


# ---------------------------------------------------------------------------
# Convenience runner
# ---------------------------------------------------------------------------

async def run_proxy(config: ProxyConfig | None = None) -> None:
    proxy = MCPSecurityProxy(config)
    try:
        await proxy.start()
    except KeyboardInterrupt:
        await proxy.stop()
