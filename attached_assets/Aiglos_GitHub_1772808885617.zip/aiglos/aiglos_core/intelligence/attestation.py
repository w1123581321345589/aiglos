"""
Aiglos Agent Identity Attestation (T7).

Every agent session that passes through Aiglos produces a signed,
tamper-evident attestation record. This is the chain-of-custody primitive
that classified and defense environments require.

What gets attested
------------------
- Model identity (which model, which version)
- System prompt integrity (SHA-256 of the system prompt -- proves it wasn't tampered)
- Tool permission grant (what tools were authorized and by whom)
- Session initiator (who or what started the session)
- Session timeline (start, end, duration)
- Security posture at session close (integrity score, anomaly score, event counts)
- Full event manifest (hashes of every security event, in order)

How signing works
-----------------
Aiglos generates an RSA-2048 keypair on first run (stored in ~/.aiglos/keys/).
The attestation document is serialized to canonical JSON and signed with the private key.
The signature and public key are embedded in the document.
Any downstream system (SIEM, auditor, CMMC assessor) can verify the document
hasn't been modified since Aiglos produced it.

For air-gapped / Gov tier deployments, the keypair is injected via environment
variables or a hardware security module (HSM) integration point.

Document format
---------------
{
  "aiglos_attestation": "1.0",
  "session_id": "...",
  "model_identity": { ... },
  "system_prompt": { "hash": "...", "hash_algorithm": "sha256" },
  "tool_permissions": [ ... ],
  "session_initiator": "...",
  "timeline": { "start": ..., "end": ..., "duration_seconds": ... },
  "security_posture": {
    "goal_integrity_score": ...,
    "anomaly_score": ...,
    "total_tool_calls": ...,
    "blocked_calls": ...,
    "critical_events": ...,
    "high_events": ...,
  },
  "event_manifest": [
    { "sequence": 0, "event_id": "...", "hash": "...", "type": "...", "severity": "..." }
  ],
  "authorized_goal_hash": "...",
  "cmmc_controls_active": [ ... ],
  "nist_controls_active": [ ... ],
  "issued_at": "...",
  "issuer": "aiglos/0.1.0",
  "signature": "...",
  "public_key_pem": "..."
}

Defense use
-----------
This document can be:
- Handed to a C3PAO assessor as evidence of CMMC-compliant AI monitoring
- Fed into Splunk/SIEM as a structured event
- Stored in an immutable audit log (S3, Azure Blob, classified storage)
- Used for incident response to reconstruct exactly what an agent did and when
- Submitted as evidence under Section 1513 NDAA FY2026 reporting
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import structlog

from aiglos_core.types import SecurityEvent, SessionContext, Severity

logger = structlog.get_logger("aiglos.attestation")

ATTESTATION_VERSION = "1.0"
ISSUER = "aiglos/0.1.0"


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class ModelIdentity:
    model_id: str
    model_version: str
    system_prompt_hash: str
    system_prompt_hash_algorithm: str = "sha256"


@dataclass
class SessionTimeline:
    start_iso: str
    end_iso: str | None
    start_unix: float
    end_unix: float | None
    duration_seconds: float | None


@dataclass
class SecurityPosture:
    goal_integrity_score: float
    anomaly_score: float
    total_tool_calls: int
    blocked_calls: int
    critical_events: int
    high_events: int
    medium_events: int
    goal_drift_events: int
    credential_events: int
    policy_violations: int


@dataclass
class EventManifestEntry:
    sequence: int
    event_id: str
    event_hash: str          # SHA-256 of canonical event JSON
    event_type: str
    severity: str
    timestamp_unix: float


@dataclass
class AttestationDocument:
    """
    The full, signed attestation record for one agent session.
    Produced at session close or on-demand during an active session.
    """
    aiglos_attestation: str
    session_id: str
    model_identity: dict
    system_prompt: dict
    tool_permissions: list[str]
    session_initiator: str
    timeline: dict
    security_posture: dict
    event_manifest: list[dict]
    authorized_goal_hash: str
    cmmc_controls_active: list[str]
    nist_controls_active: list[str]
    issued_at: str
    issuer: str
    # Set after signing
    document_hash: str = ""
    signature: str = ""          # Base64-encoded RSA-PSS signature
    public_key_pem: str = ""     # Verification key, embedded for portability

    def to_dict(self) -> dict:
        return {
            "aiglos_attestation": self.aiglos_attestation,
            "session_id": self.session_id,
            "model_identity": self.model_identity,
            "system_prompt": self.system_prompt,
            "tool_permissions": self.tool_permissions,
            "session_initiator": self.session_initiator,
            "timeline": self.timeline,
            "security_posture": self.security_posture,
            "event_manifest": self.event_manifest,
            "authorized_goal_hash": self.authorized_goal_hash,
            "cmmc_controls_active": self.cmmc_controls_active,
            "nist_controls_active": self.nist_controls_active,
            "issued_at": self.issued_at,
            "issuer": self.issuer,
            "document_hash": self.document_hash,
            "signature": self.signature,
            "public_key_pem": self.public_key_pem,
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, sort_keys=True)


# ---------------------------------------------------------------------------
# Key management
# ---------------------------------------------------------------------------

class AttestationKeyManager:
    """
    Manages the RSA keypair used to sign attestation documents.

    Key storage:
    - Default: ~/.aiglos/keys/attestation_{key_id}.pem
    - Gov/air-gap: inject via AIGLOS_SIGNING_KEY env var (PEM)
    - HSM: subclass and override sign() / get_public_key_pem()
    """

    def __init__(self, keys_dir: str | None = None) -> None:
        self.keys_dir = Path(keys_dir) if keys_dir else Path.home() / ".aiglos" / "keys"
        self._private_key = None
        self._public_key = None
        self._key_id: str = "default"
        self._initialized = False

    def initialize(self) -> None:
        """Load or generate the signing keypair."""
        if self._initialized:
            return

        # Check env var first (Gov/air-gap deployment)
        env_key = os.environ.get("AIGLOS_SIGNING_KEY")
        if env_key:
            self._load_from_pem(env_key.encode())
            logger.info("attestation_key_loaded", source="env")
            self._initialized = True
            return

        # Try to load from disk
        key_path = self.keys_dir / f"attestation_{self._key_id}.pem"
        if key_path.exists():
            self._load_from_file(key_path)
            logger.info("attestation_key_loaded", source=str(key_path))
        else:
            # Generate new keypair
            self._generate_keypair(key_path)
            logger.info("attestation_key_generated", path=str(key_path))

        self._initialized = True

    def _generate_keypair(self, save_path: Path) -> None:
        try:
            from cryptography.hazmat.primitives.asymmetric import rsa
            from cryptography.hazmat.primitives import serialization

            private_key = rsa.generate_private_key(
                public_exponent=65537,
                key_size=2048,
            )
            self._private_key = private_key
            self._public_key = private_key.public_key()

            # Save private key
            save_path.parent.mkdir(parents=True, exist_ok=True)
            save_path.parent.chmod(0o700)
            pem = private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption(),
            )
            save_path.write_bytes(pem)
            save_path.chmod(0o600)
        except ImportError:
            logger.warning("cryptography_not_available", msg="Attestation will use hash-only mode")
            self._private_key = None
            self._public_key = None

    def _load_from_file(self, path: Path) -> None:
        self._load_from_pem(path.read_bytes())

    def _load_from_pem(self, pem_data: bytes) -> None:
        try:
            from cryptography.hazmat.primitives import serialization
            self._private_key = serialization.load_pem_private_key(pem_data, password=None)
            self._public_key = self._private_key.public_key()
        except Exception as e:
            logger.warning("key_load_failed", error=str(e))
            self._private_key = None
            self._public_key = None

    def sign(self, data: bytes) -> str:
        """Sign data with the private key. Returns base64-encoded signature."""
        if self._private_key is None:
            # Hash-only fallback (no cryptography lib or key)
            return hashlib.sha256(data).hexdigest()

        try:
            from cryptography.hazmat.primitives import hashes
            from cryptography.hazmat.primitives.asymmetric import padding
            signature = self._private_key.sign(
                data,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH,
                ),
                hashes.SHA256(),
            )
            return base64.b64encode(signature).decode()
        except Exception as e:
            logger.warning("signing_failed", error=str(e))
            return hashlib.sha256(data).hexdigest()

    def get_public_key_pem(self) -> str:
        """Return the public key as PEM string for embedding in the document."""
        if self._public_key is None:
            return ""
        try:
            from cryptography.hazmat.primitives import serialization
            return self._public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo,
            ).decode()
        except Exception:
            return ""

    def verify(self, data: bytes, signature_b64: str, public_key_pem: str) -> bool:
        """Verify a signature against data and a PEM public key."""
        if not public_key_pem or not signature_b64:
            return False
        try:
            from cryptography.hazmat.primitives import hashes, serialization
            from cryptography.hazmat.primitives.asymmetric import padding

            pub_key = serialization.load_pem_public_key(public_key_pem.encode())
            sig = base64.b64decode(signature_b64)
            pub_key.verify(
                sig,
                data,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH,
                ),
                hashes.SHA256(),
            )
            return True
        except Exception:
            return False


# ---------------------------------------------------------------------------
# Attestation builder
# ---------------------------------------------------------------------------

class AttestationBuilder:
    """
    Builds and signs attestation documents from session contexts.
    One instance per Aiglos deployment.
    """

    def __init__(self, keys_dir: str | None = None) -> None:
        self.key_manager = AttestationKeyManager(keys_dir)
        self.key_manager.initialize()

    def build(
        self,
        session: SessionContext,
        events: list[SecurityEvent] | None = None,
    ) -> AttestationDocument:
        """
        Build a complete attestation document for a session.
        Optionally accepts the full event list (if not embedded in session).
        """
        all_events = events or session.events
        now = datetime.now(timezone.utc)

        # Model identity
        model_identity = {
            "model_id": session.identity.model_id,
            "model_version": session.identity.model_version,
            "system_prompt_hash": session.identity.system_prompt_hash,
            "hash_algorithm": "sha256",
        }

        # System prompt record
        system_prompt_record = {
            "hash": session.identity.system_prompt_hash,
            "hash_algorithm": "sha256",
            "note": "Hash of system prompt at session initialization. "
                    "Verify against known-good prompt to detect tampering.",
        }

        # Timeline
        start_dt = datetime.fromtimestamp(session.identity.timestamp, tz=timezone.utc)
        end_dt = (
            datetime.fromtimestamp(session.end_time, tz=timezone.utc)
            if session.end_time else None
        )
        duration = (
            session.end_time - session.identity.timestamp
            if session.end_time else None
        )
        timeline = {
            "start_iso": start_dt.isoformat(),
            "end_iso": end_dt.isoformat() if end_dt else None,
            "start_unix": session.identity.timestamp,
            "end_unix": session.end_time,
            "duration_seconds": round(duration, 3) if duration else None,
        }

        # Security posture
        blocked_calls = sum(1 for c in session.tool_calls if not c.allowed)
        ev_by_sev: dict[str, int] = {}
        ev_by_type: dict[str, int] = {}
        for ev in all_events:
            ev_by_sev[ev.severity.value] = ev_by_sev.get(ev.severity.value, 0) + 1
            ev_by_type[ev.event_type.value] = ev_by_type.get(ev.event_type.value, 0) + 1

        security_posture = {
            "goal_integrity_score": round(session.goal_integrity_score, 4),
            "anomaly_score": round(session.anomaly_score, 4),
            "total_tool_calls": len(session.tool_calls),
            "blocked_calls": blocked_calls,
            "critical_events": ev_by_sev.get("critical", 0),
            "high_events": ev_by_sev.get("high", 0),
            "medium_events": ev_by_sev.get("medium", 0),
            "low_events": ev_by_sev.get("low", 0),
            "goal_drift_events": ev_by_type.get("goal_drift", 0),
            "credential_events": ev_by_type.get("credential_detected", 0),
            "policy_violations": ev_by_type.get("policy_violation", 0),
        }

        # Event manifest -- hash each event for tamper detection
        event_manifest = []
        for i, ev in enumerate(all_events):
            ev_canonical = json.dumps({
                "id": ev.id,
                "type": ev.event_type.value,
                "severity": ev.severity.value,
                "title": ev.title,
                "timestamp": ev.timestamp,
                "session_id": ev.session_id,
            }, sort_keys=True)
            ev_hash = hashlib.sha256(ev_canonical.encode()).hexdigest()
            event_manifest.append({
                "sequence": i,
                "event_id": ev.id,
                "event_hash": ev_hash,
                "event_type": ev.event_type.value,
                "severity": ev.severity.value,
                "timestamp_unix": ev.timestamp,
                "timestamp_iso": datetime.fromtimestamp(
                    ev.timestamp, tz=timezone.utc
                ).isoformat(),
            })

        # Collect CMMC/NIST controls across all events
        cmmc_controls: set[str] = set()
        nist_controls: set[str] = set()
        for ev in all_events:
            cmmc_controls.update(ev.cmmc_controls)
            nist_controls.update(ev.nist_controls)

        doc = AttestationDocument(
            aiglos_attestation=ATTESTATION_VERSION,
            session_id=session.identity.session_id,
            model_identity=model_identity,
            system_prompt=system_prompt_record,
            tool_permissions=sorted(session.identity.tool_permissions),
            session_initiator=session.identity.initiated_by,
            timeline=timeline,
            security_posture=security_posture,
            event_manifest=event_manifest,
            authorized_goal_hash=session.authorized_goal_hash,
            cmmc_controls_active=sorted(cmmc_controls),
            nist_controls_active=sorted(nist_controls),
            issued_at=now.isoformat(),
            issuer=ISSUER,
        )

        # Sign the document
        self._sign(doc)
        return doc

    def _sign(self, doc: AttestationDocument) -> None:
        """Compute document hash and sign it."""
        # Canonical form excludes signature fields
        canonical = json.dumps({
            k: v for k, v in doc.to_dict().items()
            if k not in ("document_hash", "signature", "public_key_pem")
        }, sort_keys=True, separators=(",", ":"))

        doc.document_hash = hashlib.sha256(canonical.encode()).hexdigest()
        doc.signature = self.key_manager.sign(canonical.encode())
        doc.public_key_pem = self.key_manager.get_public_key_pem()

    def verify(self, doc: AttestationDocument) -> tuple[bool, str]:
        """
        Verify the integrity of an attestation document.
        Returns (is_valid, reason).
        """
        try:
            # Recompute canonical form
            canonical = json.dumps({
                k: v for k, v in doc.to_dict().items()
                if k not in ("document_hash", "signature", "public_key_pem")
            }, sort_keys=True, separators=(",", ":"))

            recomputed_hash = hashlib.sha256(canonical.encode()).hexdigest()
            if recomputed_hash != doc.document_hash:
                return False, f"Document hash mismatch: document has been tampered with"

            # Verify cryptographic signature if public key is present
            if doc.public_key_pem and doc.signature:
                sig_valid = self.key_manager.verify(
                    canonical.encode(),
                    doc.signature,
                    doc.public_key_pem,
                )
                if not sig_valid:
                    # Could be hash-only mode (sig is just a hex digest)
                    if doc.signature == recomputed_hash:
                        return True, "Valid (hash-only mode -- no signing key present at issue time)"
                    return False, "Cryptographic signature verification failed"

            return True, "Valid"

        except Exception as e:
            return False, f"Verification error: {e}"

    def verify_json(self, json_str: str) -> tuple[bool, str]:
        """Verify an attestation document from its JSON representation."""
        try:
            data = json.loads(json_str)
            doc = AttestationDocument(**{
                k: data.get(k, "" if isinstance(v, str) else [] if isinstance(v, list) else {})
                for k, v in AttestationDocument.__dataclass_fields__.items()
            })
            return self.verify(doc)
        except Exception as e:
            return False, f"Parse error: {e}"


# ---------------------------------------------------------------------------
# Convenience functions
# ---------------------------------------------------------------------------

_default_builder: AttestationBuilder | None = None


def get_builder(keys_dir: str | None = None) -> AttestationBuilder:
    global _default_builder
    if _default_builder is None:
        _default_builder = AttestationBuilder(keys_dir)
    return _default_builder


def attest_session(
    session: SessionContext,
    events: list[SecurityEvent] | None = None,
    keys_dir: str | None = None,
) -> AttestationDocument:
    """Produce a signed attestation document for a session."""
    return get_builder(keys_dir).build(session, events)


def verify_document(doc_json: str, keys_dir: str | None = None) -> tuple[bool, str]:
    """Verify an attestation document from JSON."""
    return get_builder(keys_dir).verify_json(doc_json)
