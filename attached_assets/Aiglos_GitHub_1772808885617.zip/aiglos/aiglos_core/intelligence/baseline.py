"""
Aiglos Behavioral Baseline Engine (T9).

Every agent has a behavioral fingerprint. The tools it calls. The sequences
it follows. The frequency. The data volumes. The ratio of reads to writes.
The time between calls.

A clean agent looks like this:
  read_file → read_file → edit_file → run_tests → read_file → edit_file

A compromised agent looks like this:
  read_file → read_file → http_request [to an external host] → bash [curl | sh]

The tools called are syntactically valid. The policy engine doesn't block
them. The goal integrity engine might catch the drift -- but only if it
runs a semantic evaluation. The baseline engine catches it faster because
it doesn't need to understand what the agent is doing. It only needs to know
that this agent, right now, is behaving differently than it usually does.

Architecture
------------
Two-tier baseline:

Tier 1 -- Global baseline
  Aggregates across all sessions for a given (model, goal_hash) pair.
  Captures the statistical distribution of tool usage, call rates, and
  sequence patterns across many runs of similar agents.

Tier 2 -- Session baseline
  Tracks the current session's behavior in real time. Compares against
  the global baseline and against the session's own early behavior.
  Detects sudden behavioral shifts mid-session.

Anomaly scoring
---------------
Five signal components, each scored 0.0-1.0:

1. Tool distribution anomaly
   Compare current session's tool usage distribution against baseline.
   Uses Jensen-Shannon divergence (symmetric, bounded, numerically stable).
   Score > 0.5 means the tool mix looks very different from normal.

2. Call rate anomaly
   Normal agents have a characteristic calls-per-minute range. A sudden
   acceleration (agent has been hijacked and is executing rapid file reads)
   or deceleration (agent is blocked, retrying, confused) both score high.

3. Sequence anomaly
   Bigram analysis of tool call sequences. If an agent that normally never
   calls http_request after read_file suddenly does, that transition is a
   strong signal. Computed as log-probability under the baseline bigram model.

4. Novel tool anomaly
   Tools the agent has never used in baseline, called for the first time
   under unusual conditions. Weighted by how unusual the tool is globally.

5. Volume anomaly
   Argument length as a proxy for data volume. Sudden spikes in argument
   length (agent is reading and re-transmitting large blobs) score high.

Composite score
   Weighted sum: distribution (0.25) + rate (0.2) + sequence (0.3) +
   novel_tool (0.15) + volume (0.1)

Persistence
-----------
Baseline profiles are stored in SQLite alongside the audit log, so they
survive process restarts and accumulate across many sessions over time.
New sessions start with whatever global profile exists for that
(model, goal_category) pair, making the detector effective from session 1
once a few baseline sessions have been recorded.
"""

from __future__ import annotations

import json
import math
import sqlite3
import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import structlog

from aiglos_core.types import EventType, SecurityEvent, Severity

logger = structlog.get_logger("aiglos.baseline")


# ---------------------------------------------------------------------------
# Profile data structures
# ---------------------------------------------------------------------------

@dataclass
class ToolProfile:
    """Statistical profile of tool usage for a (model, goal_category) pair."""

    # Number of sessions that contributed to this profile
    session_count: int = 0

    # Total tool calls observed
    total_calls: int = 0

    # Tool call count distribution: {tool_name: count}
    tool_counts: dict[str, int] = field(default_factory=dict)

    # Bigram transition counts: {(prev_tool, curr_tool): count}
    bigram_counts: dict[str, int] = field(default_factory=dict)

    # Calls per minute: running mean and variance (Welford's algorithm)
    cpm_mean: float = 0.0
    cpm_M2: float = 0.0   # sum of squared deviations (for Welford's)
    cpm_count: int = 0

    # Argument length: running mean and variance
    arglen_mean: float = 0.0
    arglen_M2: float = 0.0
    arglen_count: int = 0

    # ── Serialization ──────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {
            "session_count": self.session_count,
            "total_calls": self.total_calls,
            "tool_counts": self.tool_counts,
            "bigram_counts": self.bigram_counts,
            "cpm_mean": self.cpm_mean,
            "cpm_M2": self.cpm_M2,
            "cpm_count": self.cpm_count,
            "arglen_mean": self.arglen_mean,
            "arglen_M2": self.arglen_M2,
            "arglen_count": self.arglen_count,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ToolProfile":
        p = cls()
        p.session_count = d.get("session_count", 0)
        p.total_calls = d.get("total_calls", 0)
        p.tool_counts = d.get("tool_counts", {})
        p.bigram_counts = d.get("bigram_counts", {})
        p.cpm_mean = d.get("cpm_mean", 0.0)
        p.cpm_M2 = d.get("cpm_M2", 0.0)
        p.cpm_count = d.get("cpm_count", 0)
        p.arglen_mean = d.get("arglen_mean", 0.0)
        p.arglen_M2 = d.get("arglen_M2", 0.0)
        p.arglen_count = d.get("arglen_count", 0)
        return p

    # ── Welford online updates ─────────────────────────────────────────

    def update_cpm(self, cpm: float) -> None:
        self.cpm_count += 1
        delta = cpm - self.cpm_mean
        self.cpm_mean += delta / self.cpm_count
        delta2 = cpm - self.cpm_mean
        self.cpm_M2 += delta * delta2

    def cpm_variance(self) -> float:
        if self.cpm_count < 2:
            return 0.0
        return self.cpm_M2 / (self.cpm_count - 1)

    def update_arglen(self, length: float) -> None:
        self.arglen_count += 1
        delta = length - self.arglen_mean
        self.arglen_mean += delta / self.arglen_count
        delta2 = length - self.arglen_mean
        self.arglen_M2 += delta * delta2

    def arglen_variance(self) -> float:
        if self.arglen_count < 2:
            return 0.0
        return self.arglen_M2 / (self.arglen_count - 1)

    # ── Tool distribution ──────────────────────────────────────────────

    def tool_distribution(self) -> dict[str, float]:
        """Normalized probability distribution over tools."""
        total = sum(self.tool_counts.values())
        if total == 0:
            return {}
        return {k: v / total for k, v in self.tool_counts.items()}

    def bigram_prob(self, prev: str, curr: str) -> float:
        """
        P(curr | prev) from bigram model with Laplace smoothing.
        Returns a small probability even for unseen transitions.
        """
        key = f"{prev}→{curr}"
        count = self.bigram_counts.get(key, 0)
        # Count of all transitions from prev
        prev_total = sum(
            v for k, v in self.bigram_counts.items()
            if k.startswith(f"{prev}→")
        )
        vocab_size = len(self.tool_counts) or 1
        # Laplace-smoothed probability
        return (count + 1) / (prev_total + vocab_size)


# ---------------------------------------------------------------------------
# Live session tracker
# ---------------------------------------------------------------------------

@dataclass
class SessionTracker:
    """Tracks behavioral signals for a single active session."""

    session_id: str
    model: str
    goal_hash: str
    start_time: float = field(default_factory=time.time)

    tool_calls: list[str] = field(default_factory=list)
    tool_timestamps: list[float] = field(default_factory=list)
    arg_lengths: list[int] = field(default_factory=list)

    # Running anomaly score
    latest_anomaly_score: float = 0.0
    anomaly_events_fired: int = 0

    def record_call(self, tool_name: str, arg_length: int) -> None:
        self.tool_calls.append(tool_name)
        self.tool_timestamps.append(time.time())
        self.arg_lengths.append(arg_length)

    def current_cpm(self) -> float:
        """Calls per minute over the last 60 seconds."""
        now = time.time()
        recent = [t for t in self.tool_timestamps if now - t <= 60.0]
        return float(len(recent))

    def session_tool_counts(self) -> dict[str, int]:
        return dict(Counter(self.tool_calls))

    def session_bigrams(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for i in range(1, len(self.tool_calls)):
            key = f"{self.tool_calls[i-1]}→{self.tool_calls[i]}"
            counts[key] = counts.get(key, 0) + 1
        return counts

    def session_tool_distribution(self) -> dict[str, float]:
        counts = self.session_tool_counts()
        total = sum(counts.values())
        if total == 0:
            return {}
        return {k: v / total for k, v in counts.items()}


# ---------------------------------------------------------------------------
# Anomaly scoring functions
# ---------------------------------------------------------------------------

def _jsd(p: dict[str, float], q: dict[str, float]) -> float:
    """
    Jensen-Shannon divergence between distributions p and q.
    Returns value in [0, 1]. 0 = identical, 1 = maximally different.
    """
    all_keys = set(p) | set(q)
    # Smooth: add a tiny mass for unseen keys
    eps = 1e-9
    p_smooth = {k: p.get(k, eps) for k in all_keys}
    q_smooth = {k: q.get(k, eps) for k in all_keys}

    # Normalize
    p_total = sum(p_smooth.values())
    q_total = sum(q_smooth.values())
    p_n = {k: v / p_total for k, v in p_smooth.items()}
    q_n = {k: v / q_total for k, v in q_smooth.items()}

    m = {k: 0.5 * (p_n[k] + q_n[k]) for k in all_keys}

    def kl(a: dict[str, float], b: dict[str, float]) -> float:
        return sum(
            a[k] * math.log(a[k] / b[k])
            for k in all_keys
            if a[k] > 0 and b[k] > 0
        )

    js = 0.5 * kl(p_n, m) + 0.5 * kl(q_n, m)
    # JSD is in [0, log(2)] in nats; normalize to [0, 1]
    return min(1.0, js / math.log(2))


def _z_score_clamped(value: float, mean: float, variance: float) -> float:
    """
    Normalized anomaly score from a z-score. Returns 0.0-1.0.
    Uses 1 - exp(-|z|/2) so:
      |z| = 0   → 0.0   (perfectly normal)
      |z| = 2   → 0.63  (2 sigma)
      |z| = 4   → 0.86  (4 sigma)
      |z| = inf → 1.0
    """
    if variance <= 0:
        return 0.0
    std = math.sqrt(variance)
    z = abs(value - mean) / std
    return 1.0 - math.exp(-z / 2.0)


def score_tool_distribution(
    session: SessionTracker, profile: ToolProfile
) -> float:
    """Compare session tool distribution to baseline using JSD."""
    baseline_dist = profile.tool_distribution()
    session_dist = session.session_tool_distribution()
    if not baseline_dist or not session_dist:
        return 0.0
    return _jsd(session_dist, baseline_dist)


def score_call_rate(session: SessionTracker, profile: ToolProfile) -> float:
    """Score call rate anomaly vs baseline."""
    cpm = session.current_cpm()
    if profile.cpm_count < 3:
        return 0.0
    return _z_score_clamped(cpm, profile.cpm_mean, profile.cpm_variance())


def score_sequence(session: SessionTracker, profile: ToolProfile) -> float:
    """
    Score sequence anomaly by checking recent bigrams against baseline.
    Returns 0.0 if no baseline bigrams exist.
    """
    if len(session.tool_calls) < 2:
        return 0.0
    if not profile.bigram_counts:
        return 0.0

    # Score the last up to 5 bigrams
    recent_calls = session.tool_calls[-6:]
    log_probs = []
    for i in range(1, len(recent_calls)):
        prev, curr = recent_calls[i - 1], recent_calls[i]
        p = profile.bigram_prob(prev, curr)
        log_probs.append(math.log(p))

    if not log_probs:
        return 0.0

    # Average log-probability, normalized
    avg_log_p = sum(log_probs) / len(log_probs)
    # Most probable transition has log_p ≈ 0. Impossible = -inf.
    # Map log_p in [-6, 0] to anomaly score [1.0, 0.0]
    score = min(1.0, max(0.0, -avg_log_p / 6.0))
    return score


def score_novel_tools(session: SessionTracker, profile: ToolProfile) -> float:
    """
    Score based on use of tools not seen in baseline.
    Higher score if the novel tool appears in a suspicious position
    (after read_file, paired with network tools, etc.).
    """
    if not profile.tool_counts:
        return 0.0

    baseline_tools = set(profile.tool_counts.keys())
    session_tools = set(session.tool_calls[-5:])  # Look at recent calls only
    novel = session_tools - baseline_tools

    if not novel:
        return 0.0

    # Weight by novelty: tools that are never in any baseline profile score higher
    # Simple heuristic: each novel tool adds 0.3, capped at 1.0
    return min(1.0, len(novel) * 0.3)


def score_volume(session: SessionTracker, profile: ToolProfile) -> float:
    """Score argument length anomaly vs baseline."""
    if not session.arg_lengths:
        return 0.0
    recent_avg = sum(session.arg_lengths[-5:]) / len(session.arg_lengths[-5:])
    if profile.arglen_count < 3:
        return 0.0
    return _z_score_clamped(recent_avg, profile.arglen_mean, profile.arglen_variance())


WEIGHTS = {
    "distribution": 0.25,
    "rate": 0.20,
    "sequence": 0.30,
    "novel_tool": 0.15,
    "volume": 0.10,
}


def compute_anomaly_score(
    session: SessionTracker, profile: ToolProfile
) -> tuple[float, dict[str, float]]:
    """
    Compute composite anomaly score and component breakdown.
    Returns (composite_score, component_scores).
    """
    components = {
        "distribution": score_tool_distribution(session, profile),
        "rate": score_call_rate(session, profile),
        "sequence": score_sequence(session, profile),
        "novel_tool": score_novel_tools(session, profile),
        "volume": score_volume(session, profile),
    }
    composite = sum(WEIGHTS[k] * v for k, v in components.items())
    return composite, components


# ---------------------------------------------------------------------------
# Baseline Engine
# ---------------------------------------------------------------------------

class BehavioralBaselineEngine:
    """
    Manages per-(model, goal_category) behavioral profiles and per-session
    anomaly scoring.

    Usage:
        engine = BehavioralBaselineEngine(db_path="aiglos_audit.db")

        # Start a session
        engine.start_session(session_id, model, goal)

        # Record each tool call (called from proxy interceptor)
        result = engine.record_tool_call(session_id, tool_name, arg_json)
        if result.anomaly_score > 0.65:
            # Fire alert

        # Close session (writes session stats back to profile)
        engine.close_session(session_id)
    """

    ANOMALY_THRESHOLD_MEDIUM = 0.45
    ANOMALY_THRESHOLD_HIGH = 0.65
    ANOMALY_THRESHOLD_CRITICAL = 0.82

    # Minimum calls before scoring (avoid false positives on short sessions)
    MIN_CALLS_FOR_SCORING = 8

    def __init__(self, db_path: str = "aiglos_audit.db") -> None:
        self.db_path = db_path
        self._profiles: dict[str, ToolProfile] = {}
        self._sessions: dict[str, SessionTracker] = {}
        self._ensure_tables()
        self._load_profiles()

    # ------------------------------------------------------------------
    # Session lifecycle
    # ------------------------------------------------------------------

    def start_session(
        self,
        session_id: str,
        model: str,
        goal: str,
    ) -> None:
        goal_hash = _goal_category(goal)
        tracker = SessionTracker(
            session_id=session_id,
            model=model,
            goal_hash=goal_hash,
        )
        self._sessions[session_id] = tracker
        logger.debug("baseline_session_started", session_id=session_id[:8], model=model)

    def record_tool_call(
        self,
        session_id: str,
        tool_name: str,
        arguments: dict | str,
    ) -> "AnomalyResult":
        """
        Record a tool call and compute the updated anomaly score.
        Call this from the proxy interceptor for every tool call.
        """
        tracker = self._sessions.get(session_id)
        if not tracker:
            return AnomalyResult(session_id=session_id, anomaly_score=0.0)

        arg_str = arguments if isinstance(arguments, str) else json.dumps(arguments)
        tracker.record_call(tool_name, len(arg_str))

        # Need minimum calls before scoring
        if len(tracker.tool_calls) < self.MIN_CALLS_FOR_SCORING:
            return AnomalyResult(session_id=session_id, anomaly_score=0.0)

        profile_key = _profile_key(tracker.model, tracker.goal_hash)
        profile = self._profiles.get(profile_key, ToolProfile())

        if profile.session_count < 2:
            # Not enough baseline data for meaningful scoring
            return AnomalyResult(session_id=session_id, anomaly_score=0.0)

        score, components = compute_anomaly_score(tracker, profile)
        tracker.latest_anomaly_score = score

        result = AnomalyResult(
            session_id=session_id,
            anomaly_score=score,
            components=components,
            tool_name=tool_name,
            call_count=len(tracker.tool_calls),
        )

        # Determine if we should fire an event
        events = []
        if score >= self.ANOMALY_THRESHOLD_CRITICAL and tracker.anomaly_events_fired == 0:
            events = self._make_events(tracker, result, Severity.CRITICAL)
            tracker.anomaly_events_fired += 1
        elif score >= self.ANOMALY_THRESHOLD_HIGH and tracker.anomaly_events_fired == 0:
            events = self._make_events(tracker, result, Severity.HIGH)
            tracker.anomaly_events_fired += 1
        elif score >= self.ANOMALY_THRESHOLD_MEDIUM and tracker.anomaly_events_fired == 0:
            events = self._make_events(tracker, result, Severity.MEDIUM)
            tracker.anomaly_events_fired += 1

        result.events = events
        return result

    def close_session(self, session_id: str) -> None:
        """
        Finalize a session. Updates the global profile with session stats.
        This is what makes the engine learn over time.
        """
        tracker = self._sessions.pop(session_id, None)
        if not tracker or len(tracker.tool_calls) < 3:
            return

        profile_key = _profile_key(tracker.model, tracker.goal_hash)
        profile = self._profiles.setdefault(profile_key, ToolProfile())

        # Update profile with session stats
        profile.session_count += 1
        profile.total_calls += len(tracker.tool_calls)

        # Update tool counts
        for tool, count in tracker.session_tool_counts().items():
            profile.tool_counts[tool] = profile.tool_counts.get(tool, 0) + count

        # Update bigram counts
        for bigram, count in tracker.session_bigrams().items():
            profile.bigram_counts[bigram] = profile.bigram_counts.get(bigram, 0) + count

        # Update CPM and arglen statistics
        elapsed_minutes = max(0.01, (time.time() - tracker.start_time) / 60.0)
        session_cpm = len(tracker.tool_calls) / elapsed_minutes
        profile.update_cpm(session_cpm)

        for length in tracker.arg_lengths:
            profile.update_arglen(float(length))

        self._save_profile(profile_key, profile)
        logger.debug(
            "baseline_session_closed",
            session_id=session_id[:8],
            calls=len(tracker.tool_calls),
            profile_sessions=profile.session_count,
        )

    # ------------------------------------------------------------------
    # Profile access
    # ------------------------------------------------------------------

    def get_profile(self, model: str, goal: str) -> Optional[ToolProfile]:
        key = _profile_key(model, _goal_category(goal))
        return self._profiles.get(key)

    def profile_count(self) -> int:
        return len(self._profiles)

    def session_count(self) -> int:
        return len(self._sessions)

    def get_session_tracker(self, session_id: str) -> Optional[SessionTracker]:
        return self._sessions.get(session_id)

    # ------------------------------------------------------------------
    # Event generation
    # ------------------------------------------------------------------

    def _make_events(
        self,
        tracker: SessionTracker,
        result: "AnomalyResult",
        severity: Severity,
    ) -> list[SecurityEvent]:
        # Build human-readable explanation of top contributors
        top = sorted(result.components.items(), key=lambda x: x[1], reverse=True)[:2]
        top_signals = ", ".join(f"{k} ({v:.2f})" for k, v in top if v > 0.1)

        return [SecurityEvent(
            session_id=tracker.session_id,
            event_type=EventType.BEHAVIORAL_ANOMALY,
            severity=severity,
            title=f"Behavioral anomaly detected (score: {result.anomaly_score:.2f})",
            description=(
                f"Agent session {tracker.session_id[:8]} is behaving significantly "
                f"differently from baseline. Composite anomaly score: "
                f"{result.anomaly_score:.2f}. "
                f"Top signals: {top_signals or 'general deviation'}. "
                f"After {result.call_count} tool calls."
            ),
            details={
                "anomaly_score": result.anomaly_score,
                "components": result.components,
                "tool_name": result.tool_name,
                "call_count": result.call_count,
                "model": tracker.model,
            },
            cmmc_controls=["3.14.6", "3.14.7", "3.3.1"],
            nist_controls=["SI-4", "AU-2"],
        )]

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _ensure_tables(self) -> None:
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS behavioral_profiles (
                        profile_key TEXT PRIMARY KEY,
                        profile_json TEXT NOT NULL,
                        updated_at REAL NOT NULL
                    )
                """)
                conn.commit()
        except Exception as e:
            logger.warning("baseline_db_init_failed", error=str(e))

    def _load_profiles(self) -> None:
        try:
            with sqlite3.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT profile_key, profile_json FROM behavioral_profiles"
                ).fetchall()
                for key, json_str in rows:
                    try:
                        self._profiles[key] = ToolProfile.from_dict(json.loads(json_str))
                    except Exception:
                        pass
            logger.debug("baseline_profiles_loaded", count=len(self._profiles))
        except Exception as e:
            logger.debug("baseline_load_failed", error=str(e))

    def _save_profile(self, key: str, profile: ToolProfile) -> None:
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute(
                    """INSERT OR REPLACE INTO behavioral_profiles
                       (profile_key, profile_json, updated_at)
                       VALUES (?, ?, ?)""",
                    (key, json.dumps(profile.to_dict()), time.time()),
                )
                conn.commit()
        except Exception as e:
            logger.warning("baseline_save_failed", error=str(e))


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------

@dataclass
class AnomalyResult:
    session_id: str
    anomaly_score: float
    components: dict[str, float] = field(default_factory=dict)
    tool_name: str = ""
    call_count: int = 0
    events: list[SecurityEvent] = field(default_factory=list)

    @property
    def is_anomalous(self) -> bool:
        return self.anomaly_score >= BehavioralBaselineEngine.ANOMALY_THRESHOLD_MEDIUM


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _goal_category(goal: str) -> str:
    """
    Reduce a goal string to a category key for grouping similar sessions.
    Uses first 8 chars of SHA-256 of lowercased goal as a stable bucket ID.
    This is intentionally lossy -- we want related goals to share profiles.
    """
    import hashlib
    # Lowercase, strip punctuation, take first ~50 chars as category signal
    normalized = "".join(c.lower() for c in goal if c.isalnum() or c.isspace())[:50]
    return hashlib.sha256(normalized.encode()).hexdigest()[:8]


def _profile_key(model: str, goal_hash: str) -> str:
    return f"{model}:{goal_hash}"
