"""
Aiglos SIEM Integration and Alert Dispatch (T15).

The distribution layer. Every security event Aiglos produces can be
routed to enterprise security tooling in real time.

Supported destinations
-----------------------
- Splunk / Splunk Gov  (HTTP Event Collector -- the defense standard)
- Generic SIEM         (Syslog CEF format over TCP/UDP -- covers QRadar, ArcSight, Sentinel)
- Slack                (Webhook with severity-aware formatting)
- Generic Webhook      (JSON POST -- covers PagerDuty, Opsgenie, custom SOAR)
- Microsoft Teams      (Adaptive Card via webhook)
- File sink            (Structured JSONL -- for air-gapped environments)

Routing rules
--------------
Destinations can be filtered by severity threshold. Common pattern:

  Slack    <- CRITICAL, HIGH        (ops team gets paged)
  Splunk   <- all severities        (full audit ingest)
  Webhook  <- CRITICAL only         (PagerDuty alert)
  File     <- all severities        (air-gap backup)

Rate limiting
--------------
Alert fatigue is real. Each destination has a configurable rate limit
(default: max 10 alerts per minute for CRITICAL, 3 for others).
A token bucket is used per destination per severity bucket.

Defense context
----------------
Splunk Gov is the dominant SIEM in DoD environments. The HTTP Event
Collector (HEC) format used here is identical between commercial Splunk
and Splunk Gov, so the same connector works in both environments.

For IL4/IL5 air-gapped deployments, the File sink writes structured
JSONL that can be transferred to the classified network and ingested
by whatever SIEM is present there.
"""

from __future__ import annotations

import asyncio
import json
import socket
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any

import structlog

from aiglos_core.types import SecurityEvent, Severity

logger = structlog.get_logger("aiglos.siem")


# ---------------------------------------------------------------------------
# Severity routing
# ---------------------------------------------------------------------------

SEVERITY_ORDER = {
    Severity.CRITICAL: 0,
    Severity.HIGH: 1,
    Severity.MEDIUM: 2,
    Severity.LOW: 3,
    Severity.INFO: 4,
}

SEVERITY_COLORS = {
    Severity.CRITICAL: "#FF0000",
    Severity.HIGH: "#FF6600",
    Severity.MEDIUM: "#FFB300",
    Severity.LOW: "#0099FF",
    Severity.INFO: "#808080",
}

SEVERITY_EMOJI = {
    Severity.CRITICAL: ":red_circle:",
    Severity.HIGH: ":orange_circle:",
    Severity.MEDIUM: ":yellow_circle:",
    Severity.LOW: ":blue_circle:",
    Severity.INFO: ":white_circle:",
}


def severity_at_least(event_severity: Severity, threshold: Severity) -> bool:
    return SEVERITY_ORDER[event_severity] <= SEVERITY_ORDER[threshold]


# ---------------------------------------------------------------------------
# Rate limiter (token bucket)
# ---------------------------------------------------------------------------

class TokenBucket:
    """Simple token bucket rate limiter."""

    def __init__(self, rate: float, burst: int) -> None:
        self.rate = rate          # tokens per second
        self.burst = burst        # max tokens
        self._tokens = float(burst)
        self._last_refill = time.monotonic()

    def consume(self, tokens: int = 1) -> bool:
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._tokens = min(self.burst, self._tokens + elapsed * self.rate)
        self._last_refill = now
        if self._tokens >= tokens:
            self._tokens -= tokens
            return True
        return False


# ---------------------------------------------------------------------------
# Base destination
# ---------------------------------------------------------------------------

@dataclass
class DestinationConfig:
    name: str
    enabled: bool = True
    min_severity: Severity = Severity.HIGH
    rate_per_minute: int = 60
    timeout_seconds: float = 5.0
    # Optional: filter to specific event types
    event_type_filter: list[str] = field(default_factory=list)


class AlertDestination(ABC):
    """Base class for all alert destinations."""

    def __init__(self, config: DestinationConfig) -> None:
        self.config = config
        self._bucket = TokenBucket(
            rate=config.rate_per_minute / 60.0,
            burst=max(config.rate_per_minute, 5),
        )
        self._sent_count = 0
        self._dropped_count = 0
        self._error_count = 0

    def should_send(self, event: SecurityEvent) -> bool:
        if not self.config.enabled:
            return False
        if not severity_at_least(event.severity, self.config.min_severity):
            return False
        if self.config.event_type_filter:
            if event.event_type.value not in self.config.event_type_filter:
                return False
        return True

    async def dispatch(self, event: SecurityEvent) -> bool:
        if not self.should_send(event):
            return False
        if not self._bucket.consume():
            self._dropped_count += 1
            logger.debug(
                "alert_rate_limited",
                destination=self.config.name,
                event_type=event.event_type.value,
            )
            return False
        try:
            await self._send(event)
            self._sent_count += 1
            return True
        except Exception as e:
            self._error_count += 1
            logger.warning(
                "alert_dispatch_failed",
                destination=self.config.name,
                error=str(e),
                event_type=event.event_type.value,
            )
            return False

    @abstractmethod
    async def _send(self, event: SecurityEvent) -> None:
        ...

    def stats(self) -> dict:
        return {
            "destination": self.config.name,
            "sent": self._sent_count,
            "dropped_rate_limit": self._dropped_count,
            "errors": self._error_count,
        }


# ---------------------------------------------------------------------------
# Splunk HEC destination
# ---------------------------------------------------------------------------

@dataclass
class SplunkConfig(DestinationConfig):
    hec_url: str = ""                  # e.g. https://splunk.example.com:8088/services/collector
    hec_token: str = ""
    index: str = "aiglos"
    source: str = "aiglos:proxy"
    sourcetype: str = "aiglos:event"
    verify_ssl: bool = True


class SplunkHECDestination(AlertDestination):
    """
    Splunk HTTP Event Collector destination.
    Works with Splunk Enterprise, Splunk Cloud, and Splunk Gov (same API).
    """

    def __init__(self, config: SplunkConfig) -> None:
        super().__init__(config)
        self.splunk_config = config

    def _build_hec_event(self, event: SecurityEvent) -> dict:
        return {
            "time": event.timestamp,
            "host": socket.gethostname(),
            "source": self.splunk_config.source,
            "sourcetype": self.splunk_config.sourcetype,
            "index": self.splunk_config.index,
            "event": {
                "aiglos_version": "1.0",
                "session_id": event.session_id,
                "event_id": event.id,
                "event_type": event.event_type.value,
                "severity": event.severity.value,
                "title": event.title,
                "description": event.description,
                "details": event.details,
                "cmmc_controls": event.cmmc_controls,
                "nist_controls": event.nist_controls,
                "timestamp_iso": datetime.fromtimestamp(
                    event.timestamp, tz=timezone.utc
                ).isoformat(),
            },
        }

    async def _send(self, event: SecurityEvent) -> None:
        import httpx
        hec_event = self._build_hec_event(event)
        async with httpx.AsyncClient(
            timeout=self.config.timeout_seconds,
            verify=self.splunk_config.verify_ssl,
        ) as client:
            response = await client.post(
                self.splunk_config.hec_url,
                headers={
                    "Authorization": f"Splunk {self.splunk_config.hec_token}",
                    "Content-Type": "application/json",
                },
                json=hec_event,
            )
            response.raise_for_status()
            logger.debug(
                "splunk_hec_sent",
                event_id=event.id,
                status=response.status_code,
            )


# ---------------------------------------------------------------------------
# Syslog CEF destination (QRadar, ArcSight, Microsoft Sentinel)
# ---------------------------------------------------------------------------

@dataclass
class SyslogConfig(DestinationConfig):
    host: str = "127.0.0.1"
    port: int = 514
    protocol: str = "udp"        # "udp" or "tcp"
    facility: int = 16           # LOCAL0
    vendor: str = "Aiglos"
    product: str = "AIAgentSecurityRuntime"
    version: str = "1.0"


class SyslogCEFDestination(AlertDestination):
    """
    Syslog with CEF (Common Event Format) payload.
    CEF is the lingua franca of enterprise SIEMs.
    """

    SEVERITY_MAP = {
        Severity.CRITICAL: 10,
        Severity.HIGH: 8,
        Severity.MEDIUM: 5,
        Severity.LOW: 3,
        Severity.INFO: 1,
    }

    def __init__(self, config: SyslogConfig) -> None:
        super().__init__(config)
        self.syslog_config = config

    def _build_cef(self, event: SecurityEvent) -> str:
        """Build a CEF-formatted syslog message."""
        cef_severity = self.SEVERITY_MAP.get(event.severity, 1)
        # CEF header: CEF:Version|Device Vendor|Device Product|Device Version|
        #             Signature ID|Name|Severity|Extension
        cef_id = event.event_type.value.upper()
        cef_name = event.title.replace("|", "/").replace("\\", "/")[:50]

        # CEF extension fields
        ext_parts = [
            f"rt={int(event.timestamp * 1000)}",      # receipt time in ms
            f"src={socket.gethostname()}",
            f"suser={event.session_id[:8]}",           # truncated session as user
            f"cs1={event.session_id}",
            f"cs1Label=sessionId",
            f"cs2={','.join(event.cmmc_controls[:3])}",
            f"cs2Label=cmmcControls",
            f"msg={event.description[:150].replace('=', '-')}",
        ]
        if event.details:
            drift = event.details.get("integrity_score")
            if drift is not None:
                ext_parts.append(f"cs3={drift:.3f}")
                ext_parts.append("cs3Label=goalIntegrityScore")

        ext = " ".join(ext_parts)
        cef = (
            f"CEF:0|{self.syslog_config.vendor}|{self.syslog_config.product}|"
            f"{self.syslog_config.version}|{cef_id}|{cef_name}|{cef_severity}|{ext}"
        )

        # Syslog priority: facility * 8 + severity (0=Emergency, 6=Informational)
        syslog_sev = max(0, min(6, 6 - cef_severity // 2))
        priority = self.syslog_config.facility * 8 + syslog_sev
        ts = datetime.fromtimestamp(event.timestamp, tz=timezone.utc).strftime(
            "%b %d %H:%M:%S"
        )
        hostname = socket.gethostname()
        return f"<{priority}>{ts} {hostname} aiglos: {cef}"

    async def _send(self, event: SecurityEvent) -> None:
        message = self._build_cef(event).encode("utf-8")
        if self.syslog_config.protocol == "udp":
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None, self._send_udp, message
            )
        else:
            await self._send_tcp(message)

    def _send_udp(self, message: bytes) -> None:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.settimeout(self.config.timeout_seconds)
            s.sendto(message, (self.syslog_config.host, self.syslog_config.port))

    async def _send_tcp(self, message: bytes) -> None:
        reader, writer = await asyncio.wait_for(
            asyncio.open_connection(self.syslog_config.host, self.syslog_config.port),
            timeout=self.config.timeout_seconds,
        )
        try:
            writer.write(message + b"\n")
            await writer.drain()
        finally:
            writer.close()
            await writer.wait_closed()


# ---------------------------------------------------------------------------
# Slack webhook destination
# ---------------------------------------------------------------------------

@dataclass
class SlackConfig(DestinationConfig):
    webhook_url: str = ""
    channel: str | None = None         # Override channel if needed
    username: str = "Aiglos"
    icon_emoji: str = ":shield:"


class SlackDestination(AlertDestination):
    """
    Slack incoming webhook with severity-aware rich formatting.
    """

    def __init__(self, config: SlackConfig) -> None:
        super().__init__(config)
        self.slack_config = config

    def _build_message(self, event: SecurityEvent) -> dict:
        sev = event.severity
        color = SEVERITY_COLORS[sev]
        emoji = SEVERITY_EMOJI[sev]

        ts = datetime.fromtimestamp(event.timestamp, tz=timezone.utc).strftime(
            "%Y-%m-%d %H:%M:%S UTC"
        )

        fields = [
            {"title": "Severity", "value": sev.value.upper(), "short": True},
            {"title": "Event Type", "value": event.event_type.value, "short": True},
            {"title": "Time", "value": ts, "short": True},
        ]

        if event.session_id:
            fields.append({
                "title": "Session ID",
                "value": event.session_id[:16] + "...",
                "short": True,
            })

        if event.cmmc_controls:
            fields.append({
                "title": "CMMC Controls",
                "value": ", ".join(event.cmmc_controls[:4]),
                "short": False,
            })

        if event.details:
            gi = event.details.get("integrity_score")
            if gi is not None:
                fields.append({
                    "title": "Goal Integrity Score",
                    "value": f"{gi:.2f}",
                    "short": True,
                })

        attachment = {
            "color": color,
            "title": f"{emoji} {event.title}",
            "text": event.description[:300] if event.description else "",
            "fields": fields,
            "footer": "Aiglos AI Security Runtime",
            "footer_icon": "https://aiglos.io/favicon.ico",
            "ts": int(event.timestamp),
        }

        payload: dict[str, Any] = {
            "username": self.slack_config.username,
            "icon_emoji": self.slack_config.icon_emoji,
            "attachments": [attachment],
        }
        if self.slack_config.channel:
            payload["channel"] = self.slack_config.channel

        return payload

    async def _send(self, event: SecurityEvent) -> None:
        import httpx
        payload = self._build_message(event)
        async with httpx.AsyncClient(timeout=self.config.timeout_seconds) as client:
            response = await client.post(
                self.slack_config.webhook_url,
                json=payload,
            )
            response.raise_for_status()


# ---------------------------------------------------------------------------
# Generic webhook destination (PagerDuty, Opsgenie, custom SOAR)
# ---------------------------------------------------------------------------

@dataclass
class WebhookConfig(DestinationConfig):
    url: str = ""
    method: str = "POST"
    headers: dict[str, str] = field(default_factory=dict)
    # Optional: wrap payload in a custom envelope
    payload_template: str | None = None    # JSON template with {event_json} placeholder


class WebhookDestination(AlertDestination):
    """Generic JSON webhook. Works with PagerDuty, Opsgenie, Tines, and custom SOAR."""

    def __init__(self, config: WebhookConfig) -> None:
        super().__init__(config)
        self.webhook_config = config

    def _build_payload(self, event: SecurityEvent) -> dict:
        base = {
            "aiglos": {
                "version": "1.0",
                "event_id": event.id,
                "session_id": event.session_id,
                "event_type": event.event_type.value,
                "severity": event.severity.value,
                "title": event.title,
                "description": event.description,
                "timestamp": event.timestamp,
                "timestamp_iso": datetime.fromtimestamp(
                    event.timestamp, tz=timezone.utc
                ).isoformat(),
                "cmmc_controls": event.cmmc_controls,
                "nist_controls": event.nist_controls,
                "details": event.details,
            }
        }

        if self.webhook_config.payload_template:
            try:
                raw = self.webhook_config.payload_template.replace(
                    "{event_json}", json.dumps(base["aiglos"])
                )
                return json.loads(raw)
            except Exception:
                pass  # Fall through to base payload

        return base

    async def _send(self, event: SecurityEvent) -> None:
        import httpx
        payload = self._build_payload(event)
        async with httpx.AsyncClient(timeout=self.config.timeout_seconds) as client:
            response = await client.request(
                method=self.webhook_config.method,
                url=self.webhook_config.url,
                json=payload,
                headers=self.webhook_config.headers,
            )
            response.raise_for_status()


# ---------------------------------------------------------------------------
# File sink (air-gapped / JSONL backup)
# ---------------------------------------------------------------------------

@dataclass
class FileSinkConfig(DestinationConfig):
    path: str = "aiglos_events.jsonl"
    rotate_size_mb: float = 100.0
    include_all_severities: bool = True    # Override min_severity for file sink


class FileSinkDestination(AlertDestination):
    """
    Structured JSONL file sink.
    Air-gap safe. Import to any SIEM after transfer.
    Supports size-based rotation.
    """

    def __init__(self, config: FileSinkConfig) -> None:
        if config.include_all_severities:
            config.min_severity = Severity.INFO
        super().__init__(config)
        self.file_config = config
        self._lock = asyncio.Lock()

    async def _send(self, event: SecurityEvent) -> None:
        record = {
            "timestamp": event.timestamp,
            "timestamp_iso": datetime.fromtimestamp(
                event.timestamp, tz=timezone.utc
            ).isoformat(),
            "event_id": event.id,
            "session_id": event.session_id,
            "event_type": event.event_type.value,
            "severity": event.severity.value,
            "title": event.title,
            "description": event.description,
            "details": event.details,
            "cmmc_controls": event.cmmc_controls,
            "nist_controls": event.nist_controls,
        }
        line = json.dumps(record, separators=(",", ":")) + "\n"

        async with self._lock:
            path = Path(self.file_config.path)
            # Rotate if needed
            if path.exists():
                size_mb = path.stat().st_size / (1024 * 1024)
                if size_mb >= self.file_config.rotate_size_mb:
                    rotated = path.with_suffix(
                        f".{int(time.time())}.jsonl"
                    )
                    path.rename(rotated)

            with open(path, "a", encoding="utf-8") as f:
                f.write(line)


# ---------------------------------------------------------------------------
# Microsoft Teams destination
# ---------------------------------------------------------------------------

@dataclass
class TeamsConfig(DestinationConfig):
    webhook_url: str = ""


class TeamsDestination(AlertDestination):
    """Microsoft Teams Adaptive Card via incoming webhook."""

    def __init__(self, config: TeamsConfig) -> None:
        super().__init__(config)
        self.teams_config = config

    def _build_card(self, event: SecurityEvent) -> dict:
        sev = event.severity
        color = SEVERITY_COLORS[sev].lstrip("#")
        ts = datetime.fromtimestamp(event.timestamp, tz=timezone.utc).strftime(
            "%Y-%m-%d %H:%M:%S UTC"
        )
        facts = [
            {"name": "Severity", "value": sev.value.upper()},
            {"name": "Type", "value": event.event_type.value},
            {"name": "Time", "value": ts},
        ]
        if event.session_id:
            facts.append({"name": "Session", "value": event.session_id[:16] + "..."})
        if event.cmmc_controls:
            facts.append({"name": "CMMC Controls", "value": ", ".join(event.cmmc_controls[:3])})

        return {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": color,
            "summary": event.title,
            "sections": [{
                "activityTitle": f"**Aiglos Security Alert**",
                "activitySubtitle": event.title,
                "activityText": event.description[:300] if event.description else "",
                "facts": facts,
            }],
        }

    async def _send(self, event: SecurityEvent) -> None:
        import httpx
        card = self._build_card(event)
        async with httpx.AsyncClient(timeout=self.config.timeout_seconds) as client:
            response = await client.post(self.teams_config.webhook_url, json=card)
            response.raise_for_status()


# ---------------------------------------------------------------------------
# Dispatcher -- the fan-out engine
# ---------------------------------------------------------------------------

class AlertDispatcher:
    """
    Receives security events and fans them out to all configured destinations
    concurrently with per-destination error isolation.

    This is registered as the alert callback on MCPSecurityProxy.
    """

    def __init__(self) -> None:
        self._destinations: list[AlertDestination] = []
        self._total_dispatched = 0
        self._total_dropped = 0

    def add_destination(self, dest: AlertDestination) -> None:
        self._destinations.append(dest)
        logger.info(
            "alert_destination_added",
            name=dest.config.name,
            min_severity=dest.config.min_severity.value,
        )

    def add_splunk(
        self,
        hec_url: str,
        hec_token: str,
        min_severity: Severity = Severity.INFO,
        index: str = "aiglos",
        verify_ssl: bool = True,
    ) -> None:
        self.add_destination(SplunkHECDestination(SplunkConfig(
            name="splunk",
            hec_url=hec_url,
            hec_token=hec_token,
            min_severity=min_severity,
            index=index,
            verify_ssl=verify_ssl,
        )))

    def add_slack(
        self,
        webhook_url: str,
        min_severity: Severity = Severity.HIGH,
        channel: str | None = None,
    ) -> None:
        self.add_destination(SlackDestination(SlackConfig(
            name="slack",
            webhook_url=webhook_url,
            min_severity=min_severity,
            channel=channel,
        )))

    def add_webhook(
        self,
        url: str,
        min_severity: Severity = Severity.CRITICAL,
        headers: dict | None = None,
        name: str = "webhook",
    ) -> None:
        self.add_destination(WebhookDestination(WebhookConfig(
            name=name,
            url=url,
            min_severity=min_severity,
            headers=headers or {},
        )))

    def add_syslog(
        self,
        host: str,
        port: int = 514,
        protocol: str = "udp",
        min_severity: Severity = Severity.MEDIUM,
    ) -> None:
        self.add_destination(SyslogCEFDestination(SyslogConfig(
            name=f"syslog:{host}:{port}",
            host=host,
            port=port,
            protocol=protocol,
            min_severity=min_severity,
        )))

    def add_file_sink(
        self,
        path: str = "aiglos_events.jsonl",
        min_severity: Severity = Severity.INFO,
    ) -> None:
        self.add_destination(FileSinkDestination(FileSinkConfig(
            name="file_sink",
            path=path,
            min_severity=min_severity,
            include_all_severities=(min_severity == Severity.INFO),
        )))

    def add_teams(
        self,
        webhook_url: str,
        min_severity: Severity = Severity.HIGH,
    ) -> None:
        self.add_destination(TeamsDestination(TeamsConfig(
            name="teams",
            webhook_url=webhook_url,
            min_severity=min_severity,
        )))

    async def dispatch(self, event: SecurityEvent) -> None:
        """
        Fan out event to all destinations concurrently.
        Errors in one destination never affect others.
        """
        if not self._destinations:
            return

        self._total_dispatched += 1

        results = await asyncio.gather(
            *[dest.dispatch(event) for dest in self._destinations],
            return_exceptions=True,
        )

        sent = sum(1 for r in results if r is True)
        if sent == 0 and any(
            dest.should_send(event) for dest in self._destinations
        ):
            self._total_dropped += 1

    async def __call__(self, event: SecurityEvent) -> None:
        """Makes dispatcher directly usable as a callback."""
        await self.dispatch(event)

    def all_stats(self) -> list[dict]:
        return [d.stats() for d in self._destinations]

    def summary(self) -> dict:
        return {
            "destinations": len(self._destinations),
            "total_dispatched": self._total_dispatched,
            "total_dropped": self._total_dropped,
            "destination_stats": self.all_stats(),
        }


# ---------------------------------------------------------------------------
# Factory: build dispatcher from config dict / YAML
# ---------------------------------------------------------------------------

def dispatcher_from_config(config: dict) -> AlertDispatcher:
    """
    Build an AlertDispatcher from a config dict.

    Expected format:
    {
      "alerts": {
        "splunk": {"hec_url": "...", "hec_token": "...", "min_severity": "info"},
        "slack": {"webhook_url": "...", "min_severity": "high"},
        "webhook": {"url": "...", "min_severity": "critical"},
        "syslog": {"host": "...", "port": 514, "protocol": "udp"},
        "file_sink": {"path": "events.jsonl"},
        "teams": {"webhook_url": "..."},
      }
    }
    """
    dispatcher = AlertDispatcher()
    alerts = config.get("alerts", {})

    if splunk := alerts.get("splunk"):
        if splunk.get("hec_url") and splunk.get("hec_token"):
            dispatcher.add_splunk(
                hec_url=splunk["hec_url"],
                hec_token=splunk["hec_token"],
                min_severity=Severity(splunk.get("min_severity", "info")),
                index=splunk.get("index", "aiglos"),
                verify_ssl=splunk.get("verify_ssl", True),
            )

    if slack := alerts.get("slack"):
        if slack.get("webhook_url"):
            dispatcher.add_slack(
                webhook_url=slack["webhook_url"],
                min_severity=Severity(slack.get("min_severity", "high")),
                channel=slack.get("channel"),
            )

    if webhook := alerts.get("webhook"):
        if webhook.get("url"):
            dispatcher.add_webhook(
                url=webhook["url"],
                min_severity=Severity(webhook.get("min_severity", "critical")),
                headers=webhook.get("headers", {}),
            )

    if syslog := alerts.get("syslog"):
        if syslog.get("host"):
            dispatcher.add_syslog(
                host=syslog["host"],
                port=syslog.get("port", 514),
                protocol=syslog.get("protocol", "udp"),
                min_severity=Severity(syslog.get("min_severity", "medium")),
            )

    if file_sink := alerts.get("file_sink"):
        path = file_sink.get("path", "aiglos_events.jsonl")
        dispatcher.add_file_sink(
            path=path,
            min_severity=Severity(file_sink.get("min_severity", "info")),
        )

    if teams := alerts.get("teams"):
        if teams.get("webhook_url"):
            dispatcher.add_teams(
                webhook_url=teams["webhook_url"],
                min_severity=Severity(teams.get("min_severity", "high")),
            )

    return dispatcher
