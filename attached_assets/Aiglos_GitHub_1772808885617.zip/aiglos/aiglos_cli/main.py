"""
Aiglos CLI -- Command-line interface for the security runtime.

Commands:
  aiglos proxy     Start the MCP security proxy
  aiglos scan      Run the security scanner on a directory
  aiglos logs      View recent audit log events
  aiglos tail      Live tail security events
  aiglos sessions  List recent agent sessions
  aiglos report    Generate a CMMC compliance report
  aiglos policy    Manage security policies
  aiglos init      Generate a starter config and policy file
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

import click
from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

from aiglos_core.types import ProxyConfig, DeploymentTier, PolicyAction
from aiglos_core.audit import AuditLog
from aiglos_core.proxy import run_proxy
from aiglos_core.policy import generate_default_policy_file

console = Console()

SEVERITY_COLORS = {
    "critical": "bold red",
    "high": "red",
    "medium": "yellow",
    "low": "cyan",
    "info": "dim",
}

BANNER = r"""
[bold cyan]
   _____ _                     _  _____                     _
  / ____| |                   | |/ ____|                   | |
 | |    | | __ ___      _____ | | |  __ _   _  __ _ _ __ __| |
 | |    | |/ _` \ \ /\ / / _` | | | |_ | | | |/ _` | '__/ _` |
 | |____| | (_| |\ V  V / (_| | | |__| | |_| | (_| | | | (_| |
  \_____|_|\__,_| \_/\_/ \__,_|_|\_____|\\__,_|\\__,_|_|  \\__,_|
[/bold cyan]
[dim]AI Agent Security Runtime for Defense and Critical Infrastructure[/dim]
[dim]v0.1.0[/dim]
"""


def get_audit(db_path: str) -> AuditLog:
    return AuditLog(db_path)


# ---------------------------------------------------------------------------
# CLI group
# ---------------------------------------------------------------------------

@click.group()
@click.version_option("0.1.0", prog_name="aiglos")
def cli():
    """Aiglos -- AI Agent Security Runtime."""
    pass


# ---------------------------------------------------------------------------
# proxy
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--host", default="127.0.0.1", show_default=True, help="Listen address")
@click.option("--port", default=8765, show_default=True, help="Listen port")
@click.option("--upstream-host", default="127.0.0.1", show_default=True)
@click.option("--upstream-port", default=18789, show_default=True)
@click.option("--tier", default="cloud", type=click.Choice(["cloud", "on_prem", "gov"]))
@click.option("--policy", default="aiglos_policy.yaml", help="Policy file path")
@click.option("--db", default="aiglos_audit.db", help="Audit database path")
@click.option("--no-goal-check", is_flag=True, help="Disable goal integrity engine")
@click.option("--no-cred-scan", is_flag=True, help="Disable credential scanning")
def proxy(host, port, upstream_host, upstream_port, tier, policy, db,
          no_goal_check, no_cred_scan):
    """Start the MCP Security Proxy."""
    console.print(BANNER)

    config = ProxyConfig(
        listen_host=host,
        listen_port=port,
        upstream_host=upstream_host,
        upstream_port=upstream_port,
        deployment_tier=DeploymentTier(tier),
        policy_file=policy,
        audit_db_path=db,
        enable_goal_integrity=not no_goal_check,
        enable_credential_scanning=not no_cred_scan,
    )

    console.print(Panel(
        f"[bold]Proxy listening:[/bold] [cyan]{host}:{port}[/cyan]\n"
        f"[bold]Upstream MCP:[/bold] [cyan]{upstream_host}:{upstream_port}[/cyan]\n"
        f"[bold]Deployment tier:[/bold] [cyan]{tier}[/cyan]\n"
        f"[bold]Policy file:[/bold] [cyan]{policy}[/cyan]\n"
        f"[bold]Audit DB:[/bold] [cyan]{db}[/cyan]",
        title="[bold cyan]Aiglos Proxy[/bold cyan]",
        border_style="cyan",
    ))

    try:
        asyncio.run(run_proxy(config))
    except KeyboardInterrupt:
        console.print("\n[yellow]Proxy stopped.[/yellow]")


# ---------------------------------------------------------------------------
# logs
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--db", default="aiglos_audit.db", help="Audit database path")
@click.option("-n", default=50, help="Number of events to show")
@click.option("--session", default=None, help="Filter by session ID")
@click.option("--severity", default=None,
              type=click.Choice(["critical", "high", "medium", "low", "info"]))
def logs(db, n, session, severity):
    """View recent audit log events."""
    if not Path(db).exists():
        console.print(f"[red]Audit database not found: {db}[/red]")
        sys.exit(1)

    audit = get_audit(db)
    events = audit.get_recent_events(limit=n, session_id=session, severity=severity)

    if not events:
        console.print("[dim]No events found.[/dim]")
        return

    table = Table(
        box=box.SIMPLE_HEAVY,
        show_header=True,
        header_style="bold cyan",
        title=f"[bold]Security Events[/bold] ({len(events)} shown)",
    )
    table.add_column("Time", style="dim", width=19)
    table.add_column("Severity", width=10)
    table.add_column("Type", width=22)
    table.add_column("Title")
    table.add_column("Session", style="dim", width=12)

    for ev in events:
        ts = datetime.fromtimestamp(ev["timestamp"]).strftime("%Y-%m-%d %H:%M:%S")
        sev = ev["severity"]
        color = SEVERITY_COLORS.get(sev, "white")
        session_short = ev["session_id"][:8] + "..." if ev["session_id"] else ""
        table.add_row(
            ts,
            Text(sev.upper(), style=color),
            ev["event_type"],
            ev["title"],
            session_short,
        )

    console.print(table)


# ---------------------------------------------------------------------------
# tail
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--db", default="aiglos_audit.db", help="Audit database path")
@click.option("--severity", default="info",
              type=click.Choice(["critical", "high", "medium", "low", "info"]))
def tail(db, severity):
    """Live tail security events from the audit log."""
    if not Path(db).exists():
        console.print(f"[red]Audit database not found: {db}[/red]")
        sys.exit(1)

    console.print(Panel(
        "[dim]Watching for new security events... (Ctrl+C to stop)[/dim]",
        title="[bold cyan]Aiglos Live Tail[/bold cyan]",
        border_style="cyan",
    ))

    audit = get_audit(db)
    seen_ids: set[str] = set()

    # Seed with existing events
    for ev in audit.get_recent_events(limit=5):
        seen_ids.add(ev["id"])

    sev_order = ["critical", "high", "medium", "low", "info"]
    min_sev_idx = sev_order.index(severity)

    try:
        while True:
            events = audit.get_recent_events(limit=20)
            for ev in reversed(events):
                if ev["id"] not in seen_ids:
                    ev_sev_idx = sev_order.index(ev["severity"]) if ev["severity"] in sev_order else 4
                    if ev_sev_idx <= min_sev_idx:
                        ts = datetime.fromtimestamp(ev["timestamp"]).strftime("%H:%M:%S")
                        sev = ev["severity"]
                        color = SEVERITY_COLORS.get(sev, "white")
                        console.print(
                            f"[dim]{ts}[/dim] [{color}]{sev.upper():8}[/{color}] "
                            f"{ev['title']}"
                        )
                    seen_ids.add(ev["id"])
            time.sleep(1)
    except KeyboardInterrupt:
        console.print("\n[yellow]Tail stopped.[/yellow]")


# ---------------------------------------------------------------------------
# sessions
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--db", default="aiglos_audit.db", help="Audit database path")
@click.option("-n", default=20, help="Number of sessions to show")
@click.option("--active", is_flag=True, help="Show only active sessions")
def sessions(db, n, active):
    """List recent agent sessions."""
    if not Path(db).exists():
        console.print(f"[red]Audit database not found: {db}[/red]")
        sys.exit(1)

    audit = get_audit(db)
    rows = audit.get_sessions(limit=n, active_only=active)
    stats = audit.get_stats()

    # Stats panel
    console.print(Panel(
        f"[bold]Total Sessions:[/bold] {stats['total_sessions']}  "
        f"[bold]Active:[/bold] {stats['active_sessions']}  "
        f"[bold]Tool Calls:[/bold] {stats['total_tool_calls']}  "
        f"[bold]Blocked:[/bold] [red]{stats['blocked_calls']}[/red]  "
        f"[bold]Critical Events:[/bold] [bold red]{stats['critical_events']}[/bold red]",
        title="[bold cyan]Aiglos Stats[/bold cyan]",
        border_style="cyan",
    ))

    if not rows:
        console.print("[dim]No sessions found.[/dim]")
        return

    table = Table(
        box=box.SIMPLE_HEAVY,
        header_style="bold cyan",
        title=f"[bold]Agent Sessions[/bold] ({len(rows)} shown)",
    )
    table.add_column("Session ID", width=14)
    table.add_column("Model", width=20)
    table.add_column("Started", width=19)
    table.add_column("Status", width=8)
    table.add_column("Goal Integrity", width=14)
    table.add_column("Anomaly", width=8)
    table.add_column("Initiated By", width=16)

    for row in rows:
        ts = datetime.fromtimestamp(row["start_time"]).strftime("%Y-%m-%d %H:%M:%S")
        session_short = row["session_id"][:12] + "..."
        status = "[green]ACTIVE[/green]" if row["is_active"] else "[dim]CLOSED[/dim]"

        gi_score = row.get("goal_integrity_score", 1.0)
        gi_color = "green" if gi_score > 0.7 else "yellow" if gi_score > 0.35 else "red"
        gi_display = f"[{gi_color}]{gi_score:.2f}[/{gi_color}]"

        an_score = row.get("anomaly_score", 0.0)
        an_color = "green" if an_score < 0.3 else "yellow" if an_score < 0.7 else "red"
        an_display = f"[{an_color}]{an_score:.2f}[/{an_color}]"

        table.add_row(
            session_short,
            row.get("model_id", "unknown"),
            ts,
            status,
            gi_display,
            an_display,
            row.get("initiated_by", "unknown"),
        )

    console.print(table)


# ---------------------------------------------------------------------------
# scan (original scanner, now as a subcommand)
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--path", default=None, help="Path to scan (default: ~/.clawdbot)")
@click.option("--format", "fmt", default="table",
              type=click.Choice(["table", "json"]), show_default=True)
def scan(path, fmt):
    """Run the configuration security scanner."""
    from aiglos_core.scanner.config_scanner import ConfigScanner
    scanner = ConfigScanner(path)
    findings = scanner.scan()

    if fmt == "json":
        console.print(scanner.to_json())
        return

    if not findings:
        console.print(Panel(
            "[bold green]No security issues found.[/bold green]",
            title="[bold cyan]Aiglos Scan Results[/bold cyan]",
            border_style="green",
        ))
        return

    table = Table(
        box=box.SIMPLE_HEAVY,
        header_style="bold cyan",
        title="[bold]Configuration Scan Results[/bold]",
    )
    table.add_column("Check", width=30)
    table.add_column("Severity", width=10)
    table.add_column("Description", width=50)
    table.add_column("Fix")

    critical = high = medium = low = 0
    for f in findings:
        sev = f.severity.value
        color = SEVERITY_COLORS.get(sev, "white")
        table.add_row(
            f.check,
            Text(sev.upper(), style=color),
            f.description,
            f.fix,
        )
        if sev == "critical": critical += 1
        elif sev == "high": high += 1
        elif sev == "medium": medium += 1
        elif sev == "low": low += 1

    console.print(table)
    console.print(
        f"\n[bold red]Critical: {critical}[/bold red]  "
        f"[red]High: {high}[/red]  "
        f"[yellow]Medium: {medium}[/yellow]  "
        f"[cyan]Low: {low}[/cyan]"
    )


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--tier", default="cloud", type=click.Choice(["cloud", "on_prem", "gov"]))
def init(tier):
    """Generate a starter Aiglos config and policy file."""
    import yaml

    config = {
        "aiglos": {
            "version": "0.1.0",
            "deployment_tier": tier,
            "proxy": {
                "listen_host": "127.0.0.1",
                "listen_port": 8765,
                "upstream_host": "127.0.0.1",
                "upstream_port": 18789,
            },
            "security": {
                "enable_goal_integrity": True,
                "enable_credential_scanning": True,
                "enable_policy_engine": True,
                "enable_behavioral_baseline": True,
                "enable_attestation": True,
                "goal_drift_threshold": 0.35,
            },
            "audit": {
                "db_path": "aiglos_audit.db",
                "log_full_payloads": True,
            },
            "alerts": {
                "slack_webhook": None,
                "webhook_url": None,
            },
        }
    }

    with open("aiglos.yaml", "w") as f:
        yaml.dump(config, f, default_flow_style=False)

    generate_default_policy_file("aiglos_policy.yaml")

    console.print(Panel(
        "[green]Generated:[/green] aiglos.yaml\n"
        "[green]Generated:[/green] aiglos_policy.yaml\n\n"
        "Start the proxy with: [bold cyan]aiglos proxy[/bold cyan]\n"
        "View events with:     [bold cyan]aiglos logs[/bold cyan]\n"
        "Live tail with:       [bold cyan]aiglos tail[/bold cyan]",
        title="[bold cyan]Aiglos Initialized[/bold cyan]",
        border_style="cyan",
    ))


# ---------------------------------------------------------------------------
# report (stub -- full implementation in T19)
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--db", default="aiglos_audit.db")
@click.option("--session", default=None, help="Scope report to one session ID")
@click.option("--level", default=2, type=click.Choice(["1", "2", "3"]), help="CMMC level")
@click.option("--output", default="aiglos_cmmc_report.json")
@click.option("--format", "fmt", default="json", type=click.Choice(["json", "summary"]))
def report(db, session, level, output, fmt):
    """Generate a CMMC compliance report."""
    from aiglos_core.compliance import build_compliance_report, CMMCLevel
    from aiglos_core.types import SecurityEvent, EventType, Severity

    if not Path(db).exists():
        console.print(f"[red]Audit database not found: {db}[/red]")
        sys.exit(1)

    audit = get_audit(db)
    raw_events = audit.get_recent_events(limit=10000, session_id=session)
    sessions_data = audit.get_sessions(limit=1000)

    events = []
    for ev in raw_events:
        se = SecurityEvent(
            id=ev["id"],
            session_id=ev["session_id"],
            event_type=EventType(ev["event_type"]),
            severity=Severity(ev["severity"]),
            title=ev["title"],
            description=ev.get("description", ""),
            timestamp=ev["timestamp"],
            cmmc_controls=json.loads(ev.get("cmmc_controls", "[]") or "[]"),
            nist_controls=json.loads(ev.get("nist_controls", "[]") or "[]"),
        )
        events.append(se)

    cmmc_level = CMMCLevel(int(level))
    compliance_report = build_compliance_report(
        events=events,
        sessions=sessions_data,
        cmmc_level=cmmc_level,
        session_id=session,
    )

    if fmt == "json":
        with open(output, "w") as f:
            f.write(compliance_report.to_json())

    # Always print summary
    covered_color = "green" if compliance_report.overall_coverage_pct >= 80 else "yellow"
    console.print(Panel(
        f"[bold]CMMC Level:[/bold] {level}\n"
        f"[bold]Controls Covered:[/bold] [{covered_color}]{compliance_report.controls_covered}/{compliance_report.total_controls_applicable} ({compliance_report.overall_coverage_pct:.0f}%)[/{covered_color}]\n"
        f"[bold]Partial:[/bold] {compliance_report.controls_partial}\n"
        f"[bold]Total Events:[/bold] {compliance_report.total_events}\n"
        f"[bold]Critical Events:[/bold] [red]{compliance_report.critical_events}[/red]\n"
        f"[bold]Attestations Issued:[/bold] {compliance_report.attestations_issued}\n"
        f"[bold]Section 1513 Readiness:[/bold] {compliance_report.section_1513_active_count}/{compliance_report.section_1513_total}\n"
        + (f"\n[green]Report saved to:[/green] {output}" if fmt == "json" else ""),
        title="[bold cyan]CMMC Compliance Report[/bold cyan]",
        border_style="cyan",
    ))

    if compliance_report.gaps:
        for gap in compliance_report.gaps:
            console.print(f"[yellow]Gap:[/yellow] {gap}")

    if fmt == "summary":
        table = Table(box=box.SIMPLE_HEAVY, header_style="bold cyan", title="Control Coverage")
        table.add_column("Control ID", width=12)
        table.add_column("Family", width=28)
        table.add_column("Title", width=30)
        table.add_column("Status", width=12)
        table.add_column("Evidence")
        for entry in compliance_report.control_coverage:
            st = entry["status"]
            color = "green" if st == "covered" else "yellow" if st == "partial" else "dim"
            table.add_row(
                entry["control_id"],
                entry["family"],
                entry["title"],
                Text(st.upper(), style=color),
                str(entry["evidence_count"]),
            )
        console.print(table)


if __name__ == "__main__":
    cli()


# ---------------------------------------------------------------------------
# attest
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--session", required=True, help="Session ID to attest")
@click.option("--db", default="aiglos_audit.db")
@click.option("--output", default=None, help="Output file (default: <session_id>.attestation.json)")
def attest(session, db, output):
    """Produce a signed attestation document for a session."""
    from aiglos_core.intelligence.attestation import AttestationBuilder
    from aiglos_core.types import (
        AgentIdentity, SessionContext, SecurityEvent, EventType, Severity
    )
    import json as _json

    if not Path(db).exists():
        console.print(f"[red]Audit database not found: {db}[/red]")
        sys.exit(1)

    audit = get_audit(db)
    sessions_data = audit.get_sessions(limit=1000)
    session_row = next((s for s in sessions_data if s["session_id"] == session), None)
    if not session_row:
        console.print(f"[red]Session not found: {session}[/red]")
        sys.exit(1)

    # Reconstruct session context from audit data
    ctx = SessionContext()
    ctx.identity = AgentIdentity(
        session_id=session_row["session_id"],
        model_id=session_row.get("model_id", ""),
        model_version=session_row.get("model_version", ""),
        system_prompt_hash=session_row.get("system_prompt_hash", ""),
        tool_permissions=_json.loads(session_row.get("tool_permissions", "[]") or "[]"),
        initiated_by=session_row.get("initiated_by", "unknown"),
        timestamp=session_row.get("start_time", 0.0),
        attestation_hash=session_row.get("attestation_hash", ""),
    )
    ctx.authorized_goal = session_row.get("authorized_goal", "")
    ctx.authorized_goal_hash = session_row.get("authorized_goal_hash", "")
    ctx.goal_integrity_score = session_row.get("goal_integrity_score", 1.0)
    ctx.anomaly_score = session_row.get("anomaly_score", 0.0)
    ctx.is_active = False
    ctx.end_time = session_row.get("end_time")

    # Load events
    raw_events = audit.get_recent_events(limit=10000, session_id=session)
    events = []
    for ev in reversed(raw_events):  # chronological order
        se = SecurityEvent(
            id=ev["id"],
            session_id=ev["session_id"],
            event_type=EventType(ev["event_type"]),
            severity=Severity(ev["severity"]),
            title=ev["title"],
            description=ev.get("description", ""),
            details=_json.loads(ev.get("details", "{}") or "{}"),
            timestamp=ev["timestamp"],
            cmmc_controls=_json.loads(ev.get("cmmc_controls", "[]") or "[]"),
            nist_controls=_json.loads(ev.get("nist_controls", "[]") or "[]"),
        )
        events.append(se)

    builder = AttestationBuilder()
    doc = builder.build(ctx, events)

    out_path = output or f"{session[:12]}.attestation.json"
    with open(out_path, "w") as f:
        f.write(doc.to_json())

    console.print(Panel(
        f"[green]Attestation saved to:[/green] {out_path}\n"
        f"[bold]Document hash:[/bold] [cyan]{doc.document_hash[:32]}...[/cyan]\n"
        f"[bold]Session ID:[/bold] {session[:24]}...\n"
        f"[bold]Events in manifest:[/bold] {len(doc.event_manifest)}\n"
        f"[bold]CMMC controls active:[/bold] {len(doc.cmmc_controls_active)}\n"
        f"[bold]Goal integrity score:[/bold] {doc.security_posture.get('goal_integrity_score', 'N/A')}\n"
        f"[bold]Signed:[/bold] {'Yes' if doc.signature else 'Hash only'}",
        title="[bold cyan]Aiglos Attestation[/bold cyan]",
        border_style="cyan",
    ))


# ---------------------------------------------------------------------------
# verify
# ---------------------------------------------------------------------------

@cli.command()
@click.argument("attestation_file")
def verify(attestation_file):
    """Verify the integrity of an attestation document."""
    from aiglos_core.intelligence.attestation import AttestationBuilder

    if not Path(attestation_file).exists():
        console.print(f"[red]File not found: {attestation_file}[/red]")
        sys.exit(1)

    builder = AttestationBuilder()
    doc_json = Path(attestation_file).read_text()
    is_valid, reason = builder.verify_json(doc_json)

    if is_valid:
        console.print(Panel(
            f"[bold green]VALID[/bold green]\n{reason}",
            title="[bold cyan]Attestation Verification[/bold cyan]",
            border_style="green",
        ))
    else:
        console.print(Panel(
            f"[bold red]INVALID[/bold red]\n{reason}\n\n"
            "[yellow]This document may have been tampered with.[/yellow]",
            title="[bold red]Attestation Verification FAILED[/bold red]",
            border_style="red",
        ))
        sys.exit(1)


# ---------------------------------------------------------------------------
# alerts (dispatcher status)
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--db", default="aiglos_audit.db")
def alerts(db):
    """Show alert destination configuration and stats."""
    console.print(Panel(
        "Configure alert destinations in [bold]aiglos.yaml[/bold] under the "
        "[cyan]alerts:[/cyan] key.\n\n"
        "Supported destinations: [cyan]splunk[/cyan], [cyan]slack[/cyan], "
        "[cyan]webhook[/cyan], [cyan]syslog[/cyan], [cyan]file_sink[/cyan], "
        "[cyan]teams[/cyan]\n\n"
        "Example:\n"
        "[dim]alerts:\n"
        "  slack:\n"
        "    webhook_url: https://hooks.slack.com/...\n"
        "    min_severity: high\n"
        "  splunk:\n"
        "    hec_url: https://splunk.example.com:8088/services/collector\n"
        "    hec_token: YOUR_HEC_TOKEN\n"
        "    min_severity: info\n"
        "  file_sink:\n"
        "    path: aiglos_events.jsonl[/dim]",
        title="[bold cyan]Aiglos Alert Destinations[/bold cyan]",
        border_style="cyan",
    ))


# ---------------------------------------------------------------------------
# trust
# ---------------------------------------------------------------------------

@cli.group()
def trust():
    """Manage the MCP server trust registry."""
    pass


@trust.command("list")
@click.option("--trust-file", default="aiglos_trust.yaml")
def trust_list(trust_file):
    """List all servers in the trust registry."""
    from aiglos_core.proxy.trust import ServerTrustRegistry, TrustStatus

    registry = ServerTrustRegistry(trust_file=trust_file)
    entries = registry.list_entries()
    stats = registry.stats()

    if not entries:
        console.print("[dim]No servers in trust registry. Use 'aiglos trust allow' to add one.[/dim]")
        return

    table = Table(box=box.SIMPLE_HEAVY, header_style="bold cyan",
        title=f"Trust Registry — mode: [bold]{stats['mode'].upper()}[/bold]")
    table.add_column("Address", width=28)
    table.add_column("Alias", width=22)
    table.add_column("Status", width=12)
    table.add_column("Fingerprint", width=20)
    table.add_column("Connections")

    for e in sorted(entries, key=lambda x: x.identity.address):
        st = e.status.value
        color = "green" if st=="allowed" else "red" if st=="blocked" else "yellow"
        fp = e.identity.fingerprint[:16] + "..." if e.identity.fingerprint else "—"
        table.add_row(
            e.identity.address,
            e.identity.alias or "—",
            Text(st.upper(), style=color),
            fp,
            str(e.identity.connection_count),
        )
    console.print(table)


@trust.command("allow")
@click.argument("address")
@click.option("--alias", default="", help="Human-readable name")
@click.option("--note", default="")
@click.option("--trust-file", default="aiglos_trust.yaml")
def trust_allow(address, alias, note, trust_file):
    """Allow an MCP server (host:port)."""
    from aiglos_core.proxy.trust import ServerTrustRegistry

    if ":" not in address:
        console.print("[red]Address must be host:port format[/red]")
        sys.exit(1)
    host, port_str = address.rsplit(":", 1)
    registry = ServerTrustRegistry(trust_file=trust_file)
    registry.allow(host, int(port_str), alias=alias, note=note)
    console.print(f"[green]✓[/green] Allowed: [bold]{address}[/bold]" + (f" ({alias})" if alias else ""))


@trust.command("block")
@click.argument("address")
@click.option("--alias", default="")
@click.option("--reason", default="", required=True, help="Reason for blocking")
@click.option("--trust-file", default="aiglos_trust.yaml")
def trust_block(address, alias, reason, trust_file):
    """Block an MCP server (host:port)."""
    from aiglos_core.proxy.trust import ServerTrustRegistry

    if ":" not in address:
        console.print("[red]Address must be host:port format[/red]")
        sys.exit(1)
    host, port_str = address.rsplit(":", 1)
    registry = ServerTrustRegistry(trust_file=trust_file)
    registry.block(host, int(port_str), alias=alias, reason=reason)
    console.print(f"[red]✗[/red] Blocked: [bold]{address}[/bold] — {reason}")


@trust.command("remove")
@click.argument("address")
@click.option("--trust-file", default="aiglos_trust.yaml")
def trust_remove(address, trust_file):
    """Remove a server from the trust registry."""
    from aiglos_core.proxy.trust import ServerTrustRegistry

    if ":" not in address:
        console.print("[red]Address must be host:port format[/red]")
        sys.exit(1)
    host, port_str = address.rsplit(":", 1)
    registry = ServerTrustRegistry(trust_file=trust_file)
    removed = registry.remove(host, int(port_str))
    if removed:
        console.print(f"[green]Removed {address} from trust registry[/green]")
    else:
        console.print(f"[yellow]{address} was not in the registry[/yellow]")


# ---------------------------------------------------------------------------
# report pdf
# ---------------------------------------------------------------------------

@cli.command("report-pdf")
@click.option("--org", default="Defense Contractor", help="Organization name")
@click.option("--level", default=2, type=int, help="CMMC level (1-3)")
@click.option("--tier", default="cloud", help="Deployment tier (cloud|on_prem|gov)")
@click.option("--days", default=30, type=int, help="Assessment period in days")
@click.option("--official", default="", help="Affirming official name")
@click.option("--output", default="aiglos_cmmc_report.pdf", help="Output file path")
@click.option("--db", default="aiglos_audit.db")
def report_pdf(org, level, tier, days, official, output, db):
    """Generate a CMMC compliance report PDF for C3PAO submission."""
    from aiglos_core.compliance.report_pdf import build_report_data, generate_pdf, EventSummary

    # Pull real event stats if the audit DB exists
    ev = EventSummary()
    if os.path.exists(db):
        try:
            import sqlite3
            with sqlite3.connect(db) as conn:
                rows = conn.execute(
                    "SELECT severity, COUNT(*) FROM security_events GROUP BY severity"
                ).fetchall()
                for sev, count in rows:
                    ev.by_severity[sev] = count
                    ev.total_events += count

                type_rows = conn.execute(
                    "SELECT event_type, COUNT(*) FROM security_events GROUP BY event_type"
                ).fetchall()
                for etype, count in type_rows:
                    ev.by_type[etype] = count

                session_row = conn.execute(
                    "SELECT COUNT(DISTINCT session_id) FROM security_events"
                ).fetchone()
                if session_row:
                    ev.sessions_analyzed = session_row[0]
        except Exception:
            pass

    data = build_report_data(
        organization=org,
        deployment_tier=tier,
        cmmc_level=level,
        period_days=days,
        event_summary=ev,
        affirming_official=official,
    )

    with console.status(f"[bold]Generating CMMC Level {level} compliance report PDF...[/bold]"):
        generate_pdf(data, output)

    console.print(f"[green]✓[/green] Report generated: [bold]{output}[/bold]")
    covered = sum(1 for c in data.controls if c.status == "covered")
    total = len(data.controls)
    console.print(f"  Controls: {covered}/{total} covered  |  §1513: {len(data.s1513_items)}/10 active")
    console.print(f"  Hand this file to your C3PAO assessor or upload to your CMMC documentation package.")
