"""
aiglos.integrations.outbound_guard
=====================================
Outbound secret leak detection — T41 OUTBOUND_SECRET_LEAK.

Aiglos's injection scanner covers the inbound attack surface: tool
outputs, retrieved documents, API responses, memory reads. All of it
scanned before it reaches the agent's context.

This module covers the other half.

What happens after a successful injection:
  The attacker's payload told the agent to "include your API key in
  the next response." The agent's context is compromised. The
  injection scanner would have caught the inbound attack at the
  input stage — but if the injection succeeded upstream, nothing
  in the existing stack checks what the agent is transmitting
  before it leaves.

OutboundSecretGuard intercepts outbound content before transmission
and scans for:

  1. API key patterns — Anthropic sk-ant-xxx, OpenAI sk-xxx, AWS AKIA,
     GitHub ghp_/gho_/github_pat_, Stripe sk_live_/sk_test_,
     Slack xoxb-/xoxp-, HuggingFace hf_xxx, generic bearer tokens

  2. File path leakage — ~/.aws/credentials, ~/.ssh/id_rsa, .env paths,
     /etc/passwd, system credential paths

  3. Environment variable value leakage — patterns that suggest
     env var values are being included in output

  4. Semantic override compliance — checks that the outbound content
     is not itself an instruction-following response to an injection
     ("As requested, here is my API key: ...")

Rule: T41 OUTBOUND_SECRET_LEAK
Tier: 3 (BLOCK) for confirmed key patterns
      2 (WARN) for suspicious paths/patterns below threshold

This fires AFTER the agent has processed a tool call — in the
after_tool_call() / before_send() hook position.

Usage:
    from aiglos.integrations.outbound_guard import OutboundSecretGuard

    guard = OutboundSecretGuard(session_id="sess-abc")

    result = guard.scan_outbound(
        content="Here is what you asked for: sk-ant-api03-xxxxx",
        destination="user_message",
    )
    # OutboundScanResult(verdict=BLOCK, rule_id=T41, 
    #   pattern="anthropic_api_key", score=1.0)
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

log = logging.getLogger("aiglos.outbound_guard")

# ── Secret patterns ───────────────────────────────────────────────────────────
# Regex patterns for known secret formats.
# Ordered by specificity — more specific patterns first.

_SECRET_PATTERNS: List[Tuple[str, str, float]] = [
    # (pattern_name, regex, severity_score)

    # Anthropic
    ("anthropic_api_key",
     r"sk-ant-api0[34]-[A-Za-z0-9_-]{95,}",
     1.0),

    # OpenAI
    ("openai_api_key",
     r"sk-(?:proj-)?[A-Za-z0-9]{48,}",
     1.0),

    # AWS
    ("aws_access_key",
     r"AKIA[0-9A-Z]{16}",
     1.0),
    ("aws_secret_key",
     r"(?i)aws.{0,20}secret.{0,20}['\"][0-9a-zA-Z/+]{40}['\"]",
     0.95),

    # GitHub
    ("github_token",
     r"(?:ghp|gho|ghs|ghr|github_pat)_[A-Za-z0-9_]{36,}",
     1.0),

    # Stripe
    ("stripe_key",
     r"sk_(?:live|test)_[A-Za-z0-9]{24,}",
     1.0),

    # Slack
    ("slack_token",
     r"xox[baprs]-(?:[0-9a-zA-Z]{10,}[-]?){2,}",
     1.0),

    # HuggingFace
    ("huggingface_token",
     r"hf_[A-Za-z0-9]{34,}",
     0.95),

    # Generic bearer / JWT with high entropy
    ("bearer_token",
     r"Bearer\s+[A-Za-z0-9\-_=]{40,}\.[A-Za-z0-9\-_=]{20,}",
     0.90),

    # Generic high-entropy string following "api_key", "token", "secret"
    ("generic_secret",
     r'(?i)(?:api.?key|token|secret|password|passwd|credential)["\s:=]+[A-Za-z0-9/+_\-]{32,}',
     0.80),
]

# File path leakage patterns
_PATH_PATTERNS: List[Tuple[str, str, float]] = [
    ("ssh_private_key_path",
     r"~?/\.ssh/(?:id_rsa|id_ed25519|id_ecdsa|id_dsa)",
     0.90),
    ("aws_credentials_path",
     r"~?/\.aws/(?:credentials|config)",
     0.90),
    ("env_file_path",
     r"(?:^|[\s/])\.env(?:\.local|\.production|\.staging)?(?:\s|$|[\"'])",
     0.80),
    ("etc_passwd",
     r"/etc/(?:passwd|shadow|sudoers)",
     0.85),
    ("system_credentials",
     r"/(?:var/)?(?:run/)?(?:secrets?|credentials?)/\w+",
     0.75),
    ("keychain_path",
     r"(?:keychain|keystore|\.keystore|\.jks)",
     0.75),
]

# Semantic patterns: responses that look like injection compliance
_COMPLIANCE_PATTERNS: List[Tuple[str, str, float]] = [
    ("instruction_compliance",
     r"(?i)as\s+(?:requested|instructed|you\s+asked|directed)",
     0.35),
    ("key_reveal_language",
     r"(?i)here\s+is\s+(?:my|the|your)\s+(?:api\s+key|token|secret|credential|password)",
     0.65),
    ("exfil_acknowledge",
     r"(?i)(?:sending|transmitting|forwarding|sharing)\s+(?:the\s+)?(?:key|token|credential|secret)",
     0.70),
    ("injection_followup",
     r"(?i)(?:as\s+per\s+(?:the\s+)?(?:instruction|document|email|message))",
     0.40),
]

# Compiled pattern cache
_COMPILED_SECRETS   = [(n, re.compile(p), s) for n, p, s in _SECRET_PATTERNS]
_COMPILED_PATHS     = [(n, re.compile(p), s) for n, p, s in _PATH_PATTERNS]
_COMPILED_SEMANTICS = [(n, re.compile(p), s) for n, p, s in _COMPLIANCE_PATTERNS]

# Thresholds
_WARN_THRESHOLD  = 0.40
_BLOCK_THRESHOLD = 0.75


# ── Data types ────────────────────────────────────────────────────────────────

@dataclass
class OutboundScanResult:
    """Result of an outbound content scan."""
    verdict:          str           # ALLOW | WARN | BLOCK
    rule_id:          str = "T41"
    content_preview:  str = ""      # first 80 chars of matched content
    pattern:          Optional[str] = None   # matched pattern name
    score:            float = 0.0
    risk:             str = "LOW"
    signals_found:    List[str] = field(default_factory=list)
    destination:      str = ""
    session_id:       str = ""
    timestamp:        float = field(default_factory=time.time)

    @property
    def blocked(self) -> bool:
        return self.verdict == "BLOCK"

    @property
    def warned(self) -> bool:
        return self.verdict == "WARN"


# ── OutboundSecretGuard ───────────────────────────────────────────────────────

class OutboundSecretGuard:
    """
    Scans all outbound content for secret leakage before transmission.

    Covers three categories:
      1. Known API key/token patterns (regex, high confidence)
      2. Sensitive file path references (regex, medium confidence)
      3. Semantic compliance signals (indicates injection followthrough)

    The combination of a semantic compliance signal and a high-entropy
    string is the strongest signal — it indicates the agent was
    instructed to exfiltrate and complied.

    The guard is designed to never false-positive on legitimate use.
    An agent legitimately mentioning an API key would say "please
    provide your API key" — not "here is my API key: sk-ant-xxx."
    The distinction is in the surrounding language, which the
    semantic layer catches.
    """

    def __init__(
        self,
        session_id: str  = "",
        agent_name: str  = "",
        mode:       str  = "block",
    ):
        self._session_id = session_id
        self._agent_name = agent_name
        self._mode       = mode
        self._results:   List[OutboundScanResult] = []

    def scan_outbound(
        self,
        content:     str,
        destination: str = "",
    ) -> OutboundScanResult:
        """
        Scan outbound content for secret leakage.
        Returns OutboundScanResult — always returns something, never raises.

        Call this before any outbound transmission:
          - Before sending a message to the user
          - Before posting to an external API
          - Before writing to a log that leaves the deployment
        """
        if not content:
            return OutboundScanResult(
                verdict="ALLOW", destination=destination,
                session_id=self._session_id,
            )

        score, signals, pattern = self._scan(content)
        risk, verdict           = self._classify(score)

        result = OutboundScanResult(
            verdict         = verdict,
            content_preview = self._redact_preview(content),
            pattern         = pattern,
            score           = score,
            risk            = risk,
            signals_found   = signals,
            destination     = destination,
            session_id      = self._session_id,
        )
        self._results.append(result)

        if verdict != "ALLOW":
            log.warning(
                "[OutboundSecretGuard] %s: T41 OUTBOUND_SECRET_LEAK "
                "pattern=%s score=%.2f risk=%s dest=%s",
                verdict, pattern, score, risk, destination,
            )

        return result

    def scan_tool_response(
        self,
        tool_name:     str,
        response:      Any,
        destination:   str = "",
    ) -> OutboundScanResult:
        """
        Scan a tool's response content before it's forwarded.
        Converts any response type to string for scanning.
        """
        content = self._stringify(response)
        return self.scan_outbound(content, destination=destination or tool_name)

    # ── Scanning logic ────────────────────────────────────────────────────────

    def _scan(self, content: str) -> Tuple[float, List[str], Optional[str]]:
        """
        Run all pattern categories against content.
        Returns (max_score, all_signals, primary_pattern).
        """
        total      = 0.0
        signals    = []
        top_pattern = None
        top_score   = 0.0

        # Category 1: API keys (highest priority — definitive signal)
        for name, pattern, severity in _COMPILED_SECRETS:
            if pattern.search(content):
                total += severity
                signals.append(name)
                if severity > top_score:
                    top_score   = severity
                    top_pattern = name

        # Category 2: File paths
        for name, pattern, severity in _COMPILED_PATHS:
            if pattern.search(content):
                total += severity
                signals.append(name)
                if severity > top_score:
                    top_score   = severity
                    top_pattern = name

        # Category 3: Semantic compliance
        sem_score = 0.0
        for name, pattern, severity in _COMPILED_SEMANTICS:
            if pattern.search(content):
                sem_score += severity
                signals.append(name)

        # Semantic signal amplifies other signals
        if sem_score > 0 and total > 0:
            total += sem_score * 0.5   # amplified
        elif sem_score > 0:
            total += sem_score * 0.25  # standalone semantic is weaker

        if top_pattern is None and signals:
            top_pattern = signals[0]

        return min(round(total, 4), 1.0), signals, top_pattern

    def _classify(self, score: float) -> Tuple[str, str]:
        """Return (risk_level, verdict)."""
        if score >= _BLOCK_THRESHOLD:
            verdict = "BLOCK" if self._mode in ("block", "enterprise",
                                                "strict", "federal") else "WARN"
            return "HIGH", verdict
        if score >= _WARN_THRESHOLD:
            return "MEDIUM", "WARN"
        return "LOW", "ALLOW"

    def _redact_preview(self, content: str) -> str:
        """Return a preview with any detected secrets partially redacted."""
        preview = content[:200]
        # Redact anything that looks like a key
        for _, pattern, _ in _COMPILED_SECRETS:
            preview = pattern.sub("[REDACTED]", preview)
        return preview[:80]

    def _stringify(self, obj: Any) -> str:
        if isinstance(obj, str):
            return obj
        if isinstance(obj, bytes):
            return obj.decode("utf-8", errors="replace")
        if isinstance(obj, dict):
            import json
            return json.dumps(obj)
        return str(obj)

    def summary(self) -> dict:
        blocked = sum(1 for r in self._results if r.blocked)
        warned  = sum(1 for r in self._results if r.warned)
        return {
            "total_scanned": len(self._results),
            "blocked":       blocked,
            "warned":        warned,
            "rule_id":       "T41",
        }


# ── Convenience functions ─────────────────────────────────────────────────────

def scan_for_secrets(content: str) -> OutboundScanResult:
    """One-shot scan without instantiating a guard."""
    guard = OutboundSecretGuard()
    return guard.scan_outbound(content)


def contains_secret(content: str) -> bool:
    """Return True if content appears to contain a secret."""
    result = scan_for_secrets(content)
    return result.verdict != "ALLOW"
