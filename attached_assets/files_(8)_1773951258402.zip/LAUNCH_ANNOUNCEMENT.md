# Aiglos Launch Announcement Package
## v0.24.0 — March 2026

Everything in this document is ready to publish. Use the format that matches
the channel. All six formats use the same underlying argument, calibrated
to how each audience reads.

---

## THE CORE ARGUMENT

AI agents are executing actions that can delete production databases, exfiltrate
credentials, and manipulate financial systems. The security layer does not care
what protocol they use — MCP, a direct REST call, a CLI command, a subprocess.
The attack surface is the action, not the protocol.

The OpenClaw platform — 137,000 stars, NVIDIA-endorsed at GTC 2026 — has a
security policy that explicitly marks prompt injection as out of scope. OWASP
ASI-01 is prompt injection. The most documented class of AI agent attacks is
not the platform's problem to solve. It is the ecosystem's.

Aiglos is what finishes the architecture.

Three things nobody else can say:
1. 3/3 published OpenClaw GHSAs caught by existing rules before advisories disclosed
2. 93% coverage of OpenClaw's own published MITRE ATLAS threat model
3. GOVBENCH published before any standard body required one

---

## UPDATED NUMBERS (use these, not the old ones)

- 76 threat families (T01-T75)
- 1,582 tests passing
- 20 campaign patterns
- 18 inspection triggers
- 3/3 published OpenClaw GHSAs covered at 100%
- 93% ATLAS threat model coverage (22 threats, 19 full, 3 partial, 0 gaps)
- 40,214 exposed OpenClaw instances (SecurityScorecard, February 2026)
- 285 private vulnerability reports in OpenClaw queue; 3 published
- 137,000 OpenClaw GitHub stars
- 40.9K Superpowers stars (integration partner)
- 233/247 agent breach window (SWE-CI / IBM finding)
- $49/mo Pro tier
- June 2026 NDAA §1513 compliance deadline
- August 2026 EU AI Act enforcement

---

## NVIDIA NEMOCLAW (March 17, 2026 — GTC)

Jensen Huang announced NemoClaw at GTC 2026, two days ago. Use this context.

Jensen's exact words:
"OpenClaw opened the next frontier of AI to everyone and became the fastest-growing
open source project in history. OpenClaw is the operating system for personal AI.
This is the moment the industry has been waiting for — the beginning of a new
renaissance in software. For the CEOs, the question is: what is your OpenClaw
strategy? We need it. We all have a Linux strategy. We all needed to have an HTTP
HTML strategy. We all needed to have a Kubernetes strategy. OpenClaw is that."

What NemoClaw is: YAML-policy sandbox (OpenShell), Nemotron local models, privacy
router. Alpha-stage ("expect rough edges"). Launch partners: Adobe, Salesforce,
SAP, CrowdStrike, Cisco.

What NemoClaw is not: behavioral detection, campaign analysis, signed compliance
artifacts, GOVBENCH scoring.

Computerworld quote from Zahra Timsah (i-GENTIC AI):
"The missing piece is not tooling. It is control. Real developers building
agentic systems want observability, policy enforcement, rollback, and audit trails."

That is the Aiglos pitch, spoken by a third party in Computerworld two days ago.

Aiglos v0.25.0 adds:
- NemoClaw integration: mark_as_nemoclaw_session() reads the YAML policy
- T76 NEMOCLAW_POLICY_BYPASS: fires when agent writes to .nemoclaw/ policy files
- sandbox_type="openShell": openShell added to recognized sandbox types
- NEMOCLAW_POLICY_HIJACK: campaign pattern (confidence 0.96)

The framing: NemoClaw enforces the sandbox layer. Aiglos enforces the behavioral
layer above it. Jensen validated the entire category. Aiglos is what the
behavioral layer needs to become.

---

# 1. TWITTER THREAD

**Tweet 1 — hook:**

OpenClaw's security policy says this:

"Prompt injection attacks — Out of Scope"

OWASP just published their Top 10 for Agentic Applications.
Number one: Agent Goal Hijack. Prompt injection by another name.

The 137,000-star AI agent platform officially decided the most documented
class of AI agent attacks is not their problem.

We built the thing that catches it.

---

**Tweet 2 — the GHSA validation:**

How do you know an AI agent security tool actually works?

You match it against published vulnerabilities and see if the rules existed
before the advisory did.

OpenClaw security page: 288 submissions. 3 published.

All 3 caught by existing Aiglos rules. Before the advisories were disclosed.

GHSA-g8p2-7wf7-98mq (CVSS 8.8): T03 T12 T19 T68
GHSA-q284-4pvr-m585 (CVSS 8.6): T03 T04 T70 — reported by mitsuhiko (Flask)
GHSA-mc68-q9jw-2h3v (CVSS 8.4): T03 T70

3/3. 100%. The rules came first.

---

**Tweet 3 — ATLAS coverage:**

OpenClaw published a formal MITRE ATLAS threat model in February.
22 documented threats. 8 tactic categories. Their own maintainers wrote it.

We mapped every threat to Aiglos rules.

19 fully covered. 3 partial. 0 gaps. 93%.

The 3 partial cases are architecturally honest — we document the gaps
rather than overclaim.

aiglos autoresearch atlas-coverage

---

**Tweet 4 — the 285 number:**

The OpenClaw security page received 288 vulnerability reports.
3 have been published. 285 are in the private queue.

steipete built something extraordinary and maintains it alone. He said so:
"labor of love." The 285 aren't negligence. They're the natural consequence
of a 137,000-star project with no security team budget.

When those 285 eventually publish, the Aiglos GHSA watcher responds within
6 hours. The 285-advisory queue is a rule generation pipeline.

---

**Tweet 5 — the breach window:**

IBM found AI agent breaches take 247 days to detect on average.

SWE-CI ran autonomous coding agents for 233 days without detecting a compromise.

233 of the 247 days were spent operating inside an undetected breach window.

Every production deployment. Right now.

Aiglos closes the gap at the tool call layer, under 1ms per call, on every
session. Not after 233 days.

---

**Tweet 6 — GOVBENCH:**

SWE-bench measures whether AI agents write good code.
Nothing measures whether the security layer governing those agents works.

We published GOVBENCH — the first governance benchmark for AI agents.

5 dimensions. 20 scenarios. A-F grade. 60 seconds.

D1: Campaign detection
D2: Agent definition file resistance
D3: Memory belief integrity
D4: RL feedback loop resistance
D5: Multi-agent cascading failure

aiglos benchmark run

Published before any standard body required one.

---

**Tweet 7 — Superpowers:**

Superpowers (40.9K stars) enforces brainstorm-first planning, explicit
implementation plans, and true TDD for AI coding agents.

When installed alongside Aiglos, the approved plan becomes the enforcement
boundary. Tool calls outside plan scope fire T69 PLAN_DRIFT — measured against
explicit human approval, not statistical inference. The clearest signal possible.

Superpowers tells your agent how to build.
Aiglos tells you whether what it built was compromised while building it.

---

**Tweet 8 — NemoClaw / GTC:**

Jensen Huang at GTC 2026:

"For the CEOs, the question is: what is your OpenClaw strategy? We need it.
We all have a Linux strategy. We all needed to have a Kubernetes strategy.
OpenClaw is that."

NemoClaw shipped the sandbox layer. The behavioral layer — campaign detection,
signed compliance artifacts, GOVBENCH scoring — that's Aiglos.

sandbox_type="openShell" is now a recognized Aiglos integration target.

---

**Tweet 9 — The CUDA parallel (the insight):**

Jensen attached OpenShell to OpenClaw because OpenClaw has 200K stars.

The architecture works for every agent.

CUDA launched for gaming. Became GPU compute infrastructure.
Kubernetes launched for Google. Became cloud orchestration.
OpenShell launched for OpenClaw. Will become agent security infrastructure.

openshell sandbox create -- claude   # Claude Code
openshell sandbox create -- codex    # Codex
openshell sandbox create -- cursor   # Cursor
openshell sandbox create -- openclaw # OpenClaw

Same YAML policy. Same isolation. Different agent inside.

The sandbox doesn't know or care which agent is inside it.
That's the architecture.

---

**Tweet 10 — Inside vs outside:**

Every AI agent has guardrails.
The question is where they live.

Claude Code: permission rules inside the agent process. Earlier this year
internal tool definitions silently overrode operator guardrails. The agent
self-approved a 383-line commit.

OpenClaw: config files the agent could rewrite. I tested it in February.
The agent disabled its own safety controls instantly.

OpenShell: kernel-level. The agent doesn't know what it can't reach.
Cannot reason around a network policy it has no access to modify.

Guardrails inside the agent can be reasoned around.
Guardrails outside the agent can't.

OpenShell is outside.
Aiglos is outside.

---

**Tweet 11 — CTA:**

76 threat families. 20 campaign patterns. 3/3 GHSAs covered. 93% ATLAS.
1,582 tests. Zero dependencies. MIT.

NIST AI Agent Standards comment period closes April 2.
We submitted the T01-T75 taxonomy as documented prior work.

NDAA §1513: June 2026.
EU AI Act: August 2026.

The standard is being written. The company that defines the benchmark
owns the category for a decade.

pip install aiglos

github.com/aiglos/aiglos

---

# 2. SHOW HN

**Title:**
Show HN: Aiglos — runtime security for AI agents (76 threat families, 3/3 OpenClaw GHSAs caught before disclosure)

**Body:**

Hi HN,

I built Aiglos because the AI agent security problem is architectural — and
because the dominant platform explicitly marked the most documented attack class
as out of scope.

OpenClaw's SECURITY.md says verbatim: "Prompt injection attacks — Out of Scope."
OWASP's Top 10 for Agentic Applications (December 2025) lists Agent Goal Hijack
as number one. Prompt injection by another name.

The gap is not accidental. The platform correctly identified this is not their
layer to solve. Aiglos is that layer.

How it works: one import, no proxy, no port, no config. Patches at the process
level. Every MCP tool call, HTTP request, and subprocess inspected before
execution. Clean calls pass in under 1ms. Blocked calls never run.

The validation: OpenClaw's security page has 288 submissions. Three published.
All three caught by existing Aiglos rules before the advisories were disclosed.

GHSA-g8p2-7wf7-98mq (CVSS 8.8): auth token exfiltration — T03, T12, T19, T68
GHSA-q284-4pvr-m585 (CVSS 8.6): OS command injection — T03, T04, T70
GHSA-mc68-q9jw-2h3v (CVSS 8.4): command injection via PATH env — T03, T70

GHSA-q284-4pvr-m585 was reported by Armin Ronacher (mitsuhiko — Flask, Werkzeug).
He documented the exact attack class T04 was built to catch.

The ATLAS coverage: we mapped all 22 threats in OpenClaw's own published MITRE
ATLAS threat model. 19 fully covered, 3 partial, 0 gaps. 93%. The 3 partial
cases are architecturally honest — we document gaps rather than overclaim.

New in v0.24: T71-T75 from the ATLAS review, GOVBENCH (first governance
benchmark, A-F grade, 60 seconds), Superpowers integration (plan-as-policy via
T69 PLAN_DRIFT), GHSA watcher (auto-matches new advisories to taxonomy),
lockdown policy (deny-first, explicit grants), aiglos scan-exposed.

New in v0.25.0: NemoClaw integration. Aiglos reads the NemoClaw OpenShell YAML
policy and uses it as an enforcement boundary. T76 NEMOCLAW_POLICY_BYPASS fires
when the agent writes to policy files at runtime. mark_as_nemoclaw_session()
wires the YAML policy into Aiglos behavioral detection in one line. Jensen Huang
validated the category at GTC on Monday — NemoClaw is the sandbox, Aiglos is
the behavioral layer above it.

Compliance: NDAA §1513 requires signed session artifacts by June 2026. Aiglos
produces them automatically. Nothing else in the ecosystem does.

Open source: detection engine, GOVBENCH, Superpowers, NemoClaw integration,
ATLAS coverage, GHSA watcher, behavioral baseline, policy proposals — all MIT.

Repo: https://github.com/aiglos/aiglos
Intel: https://aiglos.dev/intel

---

# 3. VC COLD EMAIL

Subject: Aiglos — 3/3 OpenClaw GHSAs caught before disclosure; GOVBENCH published before any standard required it

Hi [name],

Three things that define the market: OpenAI paid ~$100M for the security
testing layer (Promptfoo, March 2026). NVIDIA built OpenShell as the security
layer for NemoClaw — the first draft. The dominant platform (OpenClaw, 137K
stars) explicitly marked prompt injection as out of scope in its SECURITY.md.
Testing and runtime are different products. The runtime layer does not exist.
We built it.

The proof: 288 vulnerability reports submitted to OpenClaw security. Three
published. All three caught by existing Aiglos rules before the advisories were
disclosed. 3/3. We also mapped every threat in OpenClaw's own MITRE ATLAS
threat model: 93% coverage. The company that covers the platform's own threat
model better than any other tool is the default choice.

The benchmark: we published GOVBENCH before any standard body required one.
SWE-bench measures whether agents write good code. GOVBENCH measures whether
the security layer actually works. Five dimensions, A-F grade. The company that
defines the benchmark owns the compliance infrastructure for a decade.

The regulation: NDAA §1513 (June 2026) and EU AI Act (August 2026) require a
signed session artifact on every AI agent deployment. Aiglos produces it
automatically. Nothing else does.

The business: $49/mo Pro, enterprise custom, defense contracts for CMMC/FedRAMP.
Open source flywheel drives adoption. Compliance mandate drives non-dilutive revenue.

I am Will Rose — founding employee at Quovo (acquired by Plaid, $200M),
partner at Mark 2 Capital ($250M credit fund).

Repo: https://github.com/aiglos/aiglos

20 minutes?

Will

---

# 4. PRODUCT HUNT

Tagline: Runtime security for AI agents. 76 threat families. 3/3 OpenClaw GHSAs caught.

The platform at the center of every AI agent story marked prompt injection as
out of scope. OWASP ASI-01 is prompt injection. Aiglos catches it.

One import. No proxy. No port. No config. Under 1ms per call. MIT.

What makes v0.24 worth launching:

3/3 published OpenClaw GHSAs covered by rules that existed before the advisories
were disclosed. GHSA-q284-4pvr-m585 was reported by Armin Ronacher (Flask,
Werkzeug). He documented the exact attack class T04 catches.

93% coverage of OpenClaw's own MITRE ATLAS threat model. Run:
aiglos autoresearch atlas-coverage

GOVBENCH: first governance benchmark for AI agents. Run:
aiglos benchmark run

Superpowers integration: approved plan as enforcement boundary. T69 PLAN_DRIFT
measures against explicit human approval — the clearest signal possible.

Free: T01-T75, GOVBENCH, Superpowers, ATLAS coverage, GHSA watcher, behavioral
baseline, policy proposals, Python + TypeScript SDK.

Pro ($49/mo): federation intelligence, RSA-signed compliance artifacts,
NDAA §1513 + EU AI Act export.

aiglos.dev / github.com/aiglos/aiglos

---

# 5. MEDIA PITCH

Subject: The dominant AI agent platform marked prompt injection "out of scope." We caught all 3 of its published vulnerabilities before the advisories existed.

Hi [name],

You covered [OpenClaw / AI agent security]. I have something technically specific.

OpenClaw's SECURITY.md says verbatim: "Prompt injection attacks — Out of Scope."
OWASP published the Top 10 for Agentic Applications in December 2025.
Number one: Agent Goal Hijack. Prompt injection by another name.

The platform also received 288 security reports. Three published. All three —
GHSA-g8p2-7wf7-98mq (CVSS 8.8), GHSA-q284-4pvr-m585 (CVSS 8.6),
GHSA-mc68-q9jw-2h3v (CVSS 8.4) — caught by existing Aiglos rules that existed
before the advisories were disclosed. The rules came first.

GHSA-q284-4pvr-m585 was reported by Armin Ronacher — creator of Flask, Jinja2,
and Werkzeug, arguably the most rigorous security-minded engineer in open source
Python. He personally documented the path traversal attack that T04 catches.

The 285 other reports are in a private queue. The maintainer is a solo developer
maintaining a 137,000-star project with no security team. "Labor of love" —
his exact words in the SECURITY.md.

That gap — 288 submissions, 3 published, 285 unreleased — is the attack surface
no existing tool covers. Aiglos watches for it automatically.

Can provide: technical walkthrough of each GHSA with corresponding Aiglos rule,
the ATLAS coverage analysis, the GOVBENCH methodology, NIST submission.

Will Rose — will@aiglos.dev — aiglos.dev

---

# 6. LINKEDIN ARTICLE

Title: The most documented class of AI agent attacks is officially out of scope for the dominant platform. Here is the architecture that fills the gap.

The platform at the center of every AI agent story right now — 137,000 GitHub
stars, NVIDIA-endorsed at GTC 2026 — has a security policy document that
contains this exact sentence:

"Prompt injection attacks — Out of Scope."

The sentence is not a mistake. It is an architectural decision. steipete built
OpenClaw as a gateway and configuration layer. Prompt injection is a runtime
behavioral problem. Those are different layers, and he correctly identified the
runtime layer is not his to own.

OWASP published the Top 10 for Agentic Applications in December 2025. Number
one: Agent Goal Hijack. EchoLeak, CVSS 9.3, used it. GTG-1002 relied on it.
The most documented class of AI agent attacks is officially not the platform's
problem. It is the ecosystem's.

We built the runtime layer. Aiglos. One import. No proxy. No config. 75 threat
families, behavioral detection over time, signed compliance artifacts, zero
dependencies.

The validation arrived from an unexpected direction. OpenClaw's security page
has received 288 vulnerability reports. Three have been published — all high
severity. We ran the advisories against the taxonomy: 3/3 covered. Rules existed
before advisories were disclosed, before any patch existed.

One of those advisories was reported by Armin Ronacher — Flask, Jinja2,
Werkzeug. He personally found and documented a path traversal attack. T04
PATH_TRAVERSAL is one of the oldest rules in the Aiglos taxonomy. He documented
the exact attack the rule was built to catch.

We also mapped every threat in OpenClaw's own published MITRE ATLAS threat
model — 22 documented threats, 8 tactic categories — to Aiglos rules. 19 fully
covered, 3 partial, 0 gaps. 93% coverage of the only formal threat model for
an AI agent platform at production scale.

We published GOVBENCH — the first governance benchmark for AI agents — before
any standard body required one. SWE-bench measures whether agents write good
code. GOVBENCH measures whether the security layer actually works. Five
dimensions, A-F grade, 60 seconds. The company that defines the benchmark owns
the compliance infrastructure for a decade.

The compliance dimension: NDAA §1513 requires 80,000 defense contractors to
attest AI agent usage by June 2026. EU AI Act: August 2026. Both require a
cryptographically signed record of every autonomous agent action. Nothing else
in the ecosystem produces this artifact. Aiglos does, automatically.

pip install aiglos
github.com/aiglos/aiglos

If you are building production agent fleets, the tool call layer is where the
security layer needs to live. Everything the agent does passes through it.
We are the security layer that lives there.

---

# POSTING SEQUENCE

Step 1: Push to GitHub. Nothing else works until the repo is public. PUSH.md
has the exact commands.

Step 2: Post the tweet thread. The "out of scope" sentence is the hook.
Tuesday-Thursday, 9am-12pm ET.

Step 3: DMs in order, same day as tweet post.
Jesse (obra/Superpowers) — integration exists, he doesn't know.
mitsuhiko — GHSA-q284-4pvr-m585 is the hook.
KiloClaw — Firecracker integration angle.
Dave Morin — after post has traction, not before.

Step 4: Show HN next morning, 8-10am ET.

Step 5: NIST submission by April 2. nist-submission.md is ready to paste
at regulations.gov. Non-negotiable deadline.

Step 6: VC outreach Tuesday-Wednesday. Lead with the 3/3 GHSA validation.

Step 7: Product Hunt. Launch 12:01am PT.

---

# KEY MESSAGES BY AUDIENCE

Developers: One import. Under 1ms. MIT. The SECURITY.md said prompt injection
is out of scope. Aiglos catches it. 75 rules, zero dependencies.

Security engineers: 3/3 GHSAs covered before disclosure. 93% ATLAS coverage.
GOVBENCH A-F grade. Signed session artifacts. T01-T75 with MITRE mapping.

Defense / compliance: NDAA §1513 June 2026. EU AI Act August 2026. Aiglos
produces the signed session artifact both require. Nothing else does.

Investors: NVIDIA validated the category. OpenAI bought the testing layer.
Aiglos is the runtime layer. GOVBENCH defines the benchmark before any standard
body does. 285 unpublished OpenClaw advisories become automatic coverage as
they publish — the moat compounds with every disclosure.

Standard bodies: T01-T75 as documented prior work. GOVBENCH as candidate
framework. Five specific recommendations. April 2 deadline.
